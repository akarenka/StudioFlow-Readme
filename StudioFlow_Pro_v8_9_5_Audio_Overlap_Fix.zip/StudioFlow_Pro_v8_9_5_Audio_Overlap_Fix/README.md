# StudioFlow Pro v8.9.5 — Audio Overlap Fix

本版保留 v8.9.4 的全部功能，修正 Split 後聲音重疊。

## 修正內容

- 同一個來源音訊在同一時間只允許一個 Audio Clip 發聲
- 重複的 Split Audio Clip 會自動靜音
- Video 原始聲音永遠靜音，由 Audio 1～5 統一輸出
- Separate Audio 後不再同時播放影片原聲與分離音訊
- Clip 邊界加入約 25ms 淡入／淡出，降低爆音與雙聲
- 不同來源、不同 Audio 軌且使用者刻意重疊的素材仍可混音
- Timeline Preview 與 FFmpeg 匯出都使用相同去重規則

## 匯出修正

MP4／MP3 重組匯出時：

- 同來源且時間重疊的 Audio Clip 只保留一個
- Split 邊界加入短淡入／淡出
- Audio 1～5 的 Volume、Mute 與 Timeline start 仍會生效

## 保留功能

- Video 1～5
- Audio 1～5
- 上下左右 Clip 移動
- Split Clip／Split AV
- Separate Audio／Unlink AV
- Clip Swap／Pack Sequence
- Preview 移動／縮放／透明度
- 綠幕／藍幕／自訂 Chroma
- MoviePy／FFmpeg
- 重組後 MP4／GIF／MP3 匯出
