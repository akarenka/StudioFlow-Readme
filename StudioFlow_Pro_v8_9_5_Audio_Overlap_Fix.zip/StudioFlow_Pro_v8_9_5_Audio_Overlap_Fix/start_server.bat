@echo off
echo This version uses the MoviePy backend.
echo Run install_and_start.bat for first setup.
echo Run start_moviepy_server.bat after installation.
pause
