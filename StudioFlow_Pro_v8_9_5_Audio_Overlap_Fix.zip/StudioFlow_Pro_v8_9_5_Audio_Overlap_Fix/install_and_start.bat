@echo off
setlocal
title StudioFlow Pro v7.6 - Install and Start
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  set PY=py
) else (
  set PY=python
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 goto :error
)

echo Upgrading pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip

echo Installing MoviePy, Flask, Pillow and bundled FFmpeg provider...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo Starting StudioFlow at http://127.0.0.1:8000
start "" "http://127.0.0.1:8000"
".venv\Scripts\python.exe" backend\server.py
goto :eof

:error
echo.
echo Installation failed. Check Python 3.10+ and internet connection for the first installation.
pause
exit /b 1
