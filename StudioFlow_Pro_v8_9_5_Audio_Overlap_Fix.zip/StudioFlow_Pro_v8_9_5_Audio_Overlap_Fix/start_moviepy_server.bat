@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo MoviePy environment is not installed.
  echo Run install_and_start.bat first.
  pause
  exit /b 1
)
start "" "http://127.0.0.1:8000"
".venv\Scripts\python.exe" backend\server.py
pause
