# StudioFlow Real Canvas Engine - Audio Fixed

This version fixes local video/audio playback on the Canvas editor.

## What changed

- Added **🔊 Enable/Test Audio** button to unlock browser audio permission.
- Separated audio tracks are no longer muted after splitting from video.
- Audio clips always play independently from video clips.
- Video clips keep their original sound unless you use **Separate A/V**.
- Audio/video elements are attached to a hidden media bin for more reliable browser playback.
- Delete and clear actions also stop and remove hidden media elements.

## How to hear sound

1. Import a video or audio file.
2. Add it to the timeline.
3. Click **🔊 Enable/Test Audio** once.
4. Click **▶ Play**.
5. Make sure the browser tab and Windows speaker are not muted.

## Important notes

- Browser codec support still matters. If MOV/AVI audio does not play, convert to MP4 H.264 + AAC or WAV/MP3.
- Local files are connected through browser Blob URLs. Your original computer files are not modified or deleted.
