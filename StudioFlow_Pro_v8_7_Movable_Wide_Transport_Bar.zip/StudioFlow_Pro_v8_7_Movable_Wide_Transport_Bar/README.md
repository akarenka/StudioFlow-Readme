# StudioFlow Pro v8.7 — Movable Wide Transport Bar

v8.7 保留 v8.6 的全部功能，這次修改的是最中間那一整條最寬的播放控制列。

## 最寬播放控制列

包含：

- Play
- Pause
- Stop
- -5s / +5s
- Speed
- Volume
- Current time / Duration
- Playback status

## 新增功能

- 用 `Transport Bar` 標題列拖曳整條控制列
- 可調整控制列寬度
- 拖拉左右邊緣 Resize
- `Top`：停靠畫面頂端
- `Bottom`：停靠畫面底端
- `Float`：變成可自由移動浮動列
- `−`：收合成細工具列
- `+`：重新展開
- 自動記住位置、寬度、停靠與收合狀態

## 保留

- Preview 內的小型浮動播放面板
- Preview 中央 Play
- Space 播放／暫停
- Fallback Clock
- Video 1～5
- Audio 1～5
- Separate Audio
- Split Clip / Split AV
- Unlink AV
- 手動拖曳紅色播放頭
- 雙擊素材預覽
- Preview 內拖曳圖片 / GIF / TIF / 文字
- Audio Volume / Mute / Solo
- 單獨刪除 Clip / Effects
- MoviePy / FFmpeg
- MP4 / GIF / MP3 / WebM
