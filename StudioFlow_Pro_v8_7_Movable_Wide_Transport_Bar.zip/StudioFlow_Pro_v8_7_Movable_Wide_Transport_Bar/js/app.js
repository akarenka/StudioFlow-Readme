(() => {
"use strict";
const $ = id => document.getElementById(id);
const canvas = $("canvas");
const ctx = canvas.getContext("2d");

const DB_NAME = "StudioFlow_v73_NoText_AVSplit_DB";
const STORE = "files";
let dbp = null;

let assets = [];
let layers = [];
let selected = null;
let selectedAsset = null;
let current = 0;
let duration = 20;
let playing = false;
let speed = 1;
let filter = "all";
let undoStack = [];

const secPerPx = 1 / 90;

const rows = [
  {label:"▦ Video 1", type:"video"},
  {label:"▦ Video 2", type:"video"},
  {label:"▦ Video 3", type:"video"},
  {label:"▦ Video 4", type:"video"},
  {label:"▦ Video 5", type:"video"},
  {label:"♫ Audio 1", type:"audio"},
  {label:"♫ Audio 2", type:"audio"},
  {label:"♫ Audio 3", type:"audio"},
  {label:"♫ Audio 4", type:"audio"},
  {label:"♫ Audio 5", type:"audio"}
];

function uid(){return"sf_"+Math.random().toString(36).slice(2)+Date.now().toString(36)}
function ext(n){return(n||"").split(".").pop().toLowerCase()}
function fmt(t){t=Math.max(0,t||0);let m=Math.floor(t/60),s=Math.floor(t%60),h=Math.floor((t%1)*100);return`00:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(h).padStart(2,"0")}`}
function clipEnd(l){return(+l.start||0)+(+l.duration||0)}
function calcDuration(){return Math.max(20,...layers.map(clipEnd))}
function kindOf(file){let e=ext(file.name);if(file.type.startsWith("video/")||["mp4","avi","mov","webm","mkv","m4v"].includes(e))return"video";if(file.type.startsWith("audio/")||["mp3","wav","m4a","aac","ogg","flac"].includes(e))return"audio";return"image"}
function icon(k){return k==="video"?"🎞":k==="audio"?"♫":"🖼"}
function rowForKind(k){return k==="audio"?5:k==="image"?0:0}
function validRow(k,row){return rows[row]?.type===k || (k==="image"&&rows[row]?.type==="video")}
function snapTime(t){return $("snapToggle")?.checked?Math.round(t*10)/10:t}
function pushUndo(){try{undoStack.push(JSON.stringify({layers,current,duration}));if(undoStack.length>80)undoStack.shift()}catch(e){}}

function openDB(){if(dbp)return dbp;dbp=new Promise((res,rej)=>{let r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{let db=r.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:"id"})};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});return dbp}
async function putRec(rec){let db=await openDB();return new Promise((res,rej)=>{let tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).put(rec);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
async function getRec(id){let db=await openDB();return new Promise((res,rej)=>{let tx=db.transaction(STORE,"readonly"),r=tx.objectStore(STORE).get(id);r.onsuccess=()=>res(r.result||null);r.onerror=()=>rej(r.error)})}
async function clearDB(){let db=await openDB();return new Promise((res,rej)=>{let tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).clear();tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}

async function hydrate(a){
  if(a.el&&a.url)return a;
  if(!a.dbId)return a;
  let rec=await getRec(a.dbId);
  if(!rec)return a;
  let url=URL.createObjectURL(rec.blob);
  a.url=url;
  if(a.kind==="video"){
    let v=document.createElement("video");v.src=url;v.preload="auto";v.playsInline=true;v.volume=+$("volume").value;a.el=v;
    await new Promise(r=>{v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:a.duration||5;a.w=v.videoWidth||a.w||1920;a.h=v.videoHeight||a.h||1080;r()};v.onerror=r;v.load()});
  }else if(a.kind==="audio"){
    let au=document.createElement("audio");au.src=url;au.preload="auto";au.volume=+$("volume").value;a.el=au;
    await new Promise(r=>{au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:a.duration||5;r()};au.onerror=r;au.load()});
  }else{
    let img=new Image();img.src=url;a.el=img;
    await new Promise(r=>{img.onload=()=>{a.w=img.naturalWidth||a.w||1920;a.h=img.naturalHeight||a.h||1080;r()};img.onerror=r});
  }
  return a;
}

function saveManifest(){
  localStorage.setItem("studioflow_notext_manifest",JSON.stringify({
    assets:assets.map(a=>({id:a.id,dbId:a.dbId,name:a.name,kind:a.kind,duration:a.duration,w:a.w,h:a.h,type:a.type})),
    layers,current,duration
  }));
}
async function restoreBin(){
  let raw=localStorage.getItem("studioflow_notext_manifest");
  if(!raw)return alert("No saved bin.");
  let data=JSON.parse(raw);
  assets=data.assets||[];
  layers=data.layers||[];normalizeTrackRows();
  current=data.current||0;
  for(let a of assets)await hydrate(a);
  duration=calcDuration();
  renderAll();
}

async function importFiles(files){
  for(const file of Array.from(files||[])){
    let kind=kindOf(file),dbId=uid(),blob=file.slice(0,file.size,file.type||"application/octet-stream");
    await putRec({id:dbId,name:file.name,type:file.type,size:file.size,kind,blob,createdAt:new Date().toISOString()});
    let url=URL.createObjectURL(blob);
    let a={id:uid(),dbId,name:file.name,kind,type:file.type,url,duration:5,w:1920,h:1080,el:null};
    if(kind==="video"){
      let v=document.createElement("video");v.src=url;v.preload="auto";v.playsInline=true;v.volume=+$("volume").value;a.el=v;
      await new Promise(r=>{v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:5;a.w=v.videoWidth||1920;a.h=v.videoHeight||1080;r()};v.onerror=r;v.load()});
    }else if(kind==="audio"){
      let au=document.createElement("audio");au.src=url;au.preload="auto";au.volume=+$("volume").value;a.el=au;
      await new Promise(r=>{au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:5;r()};au.onerror=r;au.load()});
    }else{
      let img=new Image();img.src=url;a.el=img;
      await new Promise(r=>{img.onload=()=>{a.w=img.naturalWidth||1920;a.h=img.naturalHeight||1080;r()};img.onerror=r});
    }
    assets.push(a);
    addLayerFromAsset(a);
  }
  duration=calcDuration();
  saveManifest();
  renderAll();
}

function addLayerFromAsset(a){
  pushUndo();
  let kind=a.kind==="audio"?"audio":a.kind==="image"?"image":"video";
  let l={id:uid(),assetId:a.id,name:a.name,kind,start:0,duration:kind==="image"?Math.max(5,duration||5):a.duration||5,trim:0,x:960,y:540,scale:1,muted:false,volume:1,row:rowForKind(kind),z:layers.length,chroma:false,chromaColor:"#00ff00",chromaTolerance:70};
  if(kind==="image")l.scale=Math.min(1920/(a.w||1920),1080/(a.h||1080));
  layers.push(l);
  selected=l.id;
  duration=calcDuration();
}

function assetOf(l){return assets.find(a=>a.id===l?.assetId)}
function active(l){return current>=l.start&&current<=l.start+l.duration}
function activePlayable(){return layers.filter(l=>(l.kind==="video"||l.kind==="audio")&&active(l)).sort((a,b)=>(a.kind==="video"?0:1)-(b.kind==="video"?0:1)||a.row-b.row||a.start-b.start)}
function master(){let a=activePlayable();return a.find(l=>l.kind==="video")||a.find(l=>l.kind==="audio")||layers.filter(l=>l.kind==="video"||l.kind==="audio").sort((a,b)=>a.start-b.start)[0]||null}
function hasSplit(v){return!!(v&&v.linkedGroup&&layers.some(l=>l.kind==="audio"&&l.linkedGroup===v.linkedGroup))}

async function separateAudio(){
  const videoLayer = layers.find(l => l.id === selected && l.kind === "video");
  if(!videoLayer){
    alert("請先在時間線選取影片 Clip。");
    return;
  }

  const existing = videoLayer.linkedGroup
    ? layers.find(l => l.kind === "audio" && l.linkedGroup === videoLayer.linkedGroup)
    : null;

  if(existing){
    selected = existing.id;
    current = Math.max(existing.start, current);
    loadInspector(existing);
    renderAll();
    return;
  }

  const source = assetOf(videoLayer);
  if(!source){
    alert("找不到影片來源素材，請重新匯入影片。");
    return;
  }

  await hydrate(source);
  let record = source.dbId ? await getRec(source.dbId) : null;
  let sourceBlob = record?.blob || null;
  let sourceUrl = sourceBlob ? URL.createObjectURL(sourceBlob) : source.url;

  if(!sourceUrl){
    alert("影片素材尚未載入，無法分離音訊。");
    return;
  }

  pushUndo();

  // Use a real HTMLAudioElement so the separated audio is independently playable.
  const audioElement = document.createElement("audio");
  audioElement.src = sourceUrl;
  audioElement.preload = "auto";
  audioElement.crossOrigin = "anonymous";
  audioElement.volume = +$("volume").value || 0.75;

  await new Promise(resolve => {
    let finished = false;
    const done = () => {
      if(finished) return;
      finished = true;
      resolve();
    };
    audioElement.onloadedmetadata = done;
    audioElement.oncanplay = done;
    audioElement.onerror = done;
    try { audioElement.load(); } catch(e) { done(); }
    setTimeout(done, 1500);
  });

  const audioAsset = {
    id: uid(),
    dbId: source.dbId,
    name: "Separated Audio - " + source.name,
    kind: "audio",
    type: source.type || "audio/from-video",
    url: sourceUrl,
    duration: Number.isFinite(audioElement.duration)
      ? audioElement.duration
      : (source.duration || videoLayer.duration),
    w: 0,
    h: 0,
    el: audioElement,
    sourceVideoAssetId: source.id
  };
  assets.push(audioAsset);

  const linkedGroup = uid();
  videoLayer.linkedGroup = linkedGroup;
  videoLayer.muted = true;
  videoLayer.splitSource = true;

  // Audio rows are 5, 6, 7, 8, 9. Prefer Audio 1 (row 5).
  let targetRow = firstFreeAudioTrack(videoLayer.start,videoLayer.start+videoLayer.duration);

  const audioLayer = {
    id: uid(),
    assetId: audioAsset.id,
    name: audioAsset.name,
    kind: "audio",
    start: videoLayer.start,
    duration: videoLayer.duration,
    trim: videoLayer.trim || 0,
    x: 0,
    y: 0,
    scale: 1,
    volume: 1,
    muted: false,
    row: targetRow,
    linkedGroup,
    independentAfterSplit: true,
    splitAudio: true,
    z: layers.length
  };

  layers.push(audioLayer);
  selected = audioLayer.id;
  duration = calcDuration();
  saveManifest();
  sync(true);
  loadInspector(audioLayer);
  renderAll();
}

function setPreviewStatus(text,state=""){
  const el=$("previewPlaybackStatus");
  if(!el) return;
  el.textContent=text;
  el.classList.remove("playing","paused");
  if(state) el.classList.add(state);
}

async function ensureAssetReady(asset){
  if(!asset) return false;
  try{
    await hydrate(asset);
  }catch(e){}

  if(asset.kind==="video"){
    if(!asset.el || asset.el.tagName!=="VIDEO"){
      const video=document.createElement("video");
      video.preload="auto";
      video.playsInline=true;
      video.crossOrigin="anonymous";
      video.muted=true;
      if(asset.url) video.src=asset.url;
      asset.el=video;
    }
  }else if(asset.kind==="audio"){
    ensureAudioElement(asset);
  }

  const el=asset.el;
  if(!el) return false;

  if(el.readyState>=2 || asset.kind==="image") return true;

  return await new Promise(resolve=>{
    let done=false;
    const finish=value=>{
      if(done) return;
      done=true;
      resolve(value);
    };
    el.addEventListener("loadeddata",()=>finish(true),{once:true});
    el.addEventListener("canplay",()=>finish(true),{once:true});
    el.addEventListener("error",()=>finish(false),{once:true});
    try{el.load?.()}catch(e){}
    setTimeout(()=>finish(el.readyState>=1),1800);
  });
}

async function prepareActivePreviewAssets(){
  const candidates=layers.filter(layer=>
    active(layer) &&
    (layer.kind==="video"||layer.kind==="audio"||layer.kind==="image")
  );
  await Promise.all(candidates.map(layer=>ensureAssetReady(assetOf(layer))));
}

function drawPreviewFrame(){
  try{
    ctx.clearRect(0,0,1920,1080);
    ctx.fillStyle="#000";
    ctx.fillRect(0,0,1920,1080);

    const visuals=layers
      .filter(layer=>active(layer)&&(layer.kind==="video"||layer.kind==="image"))
      .sort((a,b)=>(a.z||0)-(b.z||0));

    for(const layer of visuals){
      const asset=assetOf(layer);
      const source=asset?.el;
      if(!source) continue;

      if(layer.kind==="video"){
        if(source.readyState<2) continue;
        const desired=Math.max(0,(layer.trim||0)+(current-layer.start));
        if(Math.abs((source.currentTime||0)-desired)>.20){
          safeSetMediaTime(source,desired);
        }
      }

      if(layer.kind==="image"&&!source.complete) continue;

      const sourceWidth=
        source.videoWidth||
        source.naturalWidth||
        asset.w||
        1920;
      const sourceHeight=
        source.videoHeight||
        source.naturalHeight||
        asset.h||
        1080;

      const scale=layer.scale||1;
      const width=sourceWidth*scale;
      const height=sourceHeight*scale;
      const x=(layer.x??960)-width/2;
      const y=(layer.y??540)-height/2;

      try{
        drawChroma(source,x,y,width,height,layer);
      }catch(error){
        try{ctx.drawImage(source,x,y,width,height)}catch(ignore){}
      }
    }
  }catch(error){
    console.error("drawPreviewFrame failed:",error);
    setPlaybackCoreStatus("Preview frame error","error");
  }
}


function setPlaybackCoreStatus(text,state=""){
  const el=$("playbackCoreStatus");
  if(!el) return;
  el.textContent=text;
  el.classList.remove("running","error");
  if(state) el.classList.add(state);
}

function safeSetMediaTime(element,time){
  if(!element || !("currentTime" in element)) return;
  if(!Number.isFinite(time) || time<0) return;

  try{
    if(element.readyState>=1){
      const maximum=Number.isFinite(element.duration)
        ? Math.max(0,element.duration-.025)
        : time;
      element.currentTime=Math.min(time,maximum);
    }else{
      const setLater=()=>{
        try{
          const maximum=Number.isFinite(element.duration)
            ? Math.max(0,element.duration-.025)
            : time;
          element.currentTime=Math.min(time,maximum);
        }catch(error){}
      };
      element.addEventListener("loadedmetadata",setLater,{once:true});
    }
  }catch(error){
    console.warn("Unable to seek media element",error);
  }
}

function safePlayMedia(element){
  if(!element || typeof element.play!=="function") return;
  try{
    const promise=element.play();
    if(promise?.catch){
      promise.catch(error=>{
        console.warn("Media play was blocked:",error);
      });
    }
  }catch(error){
    console.warn("Media play failed:",error);
  }
}

function synchronizeOneMediaLayer(layer,force=false){
  const asset=assetOf(layer);
  const element=asset?.el;
  if(!element) return;

  const isActive=active(layer);
  const localTime=Math.max(
    0,
    (layer.trim||0)+(current-layer.start)
  );
  const masterVolume=Math.max(0,Math.min(1,+($("volume")?.value||0.8)));
  const playbackSpeed=Math.max(.1,+($("speed")?.value||1));

  try{element.playbackRate=playbackSpeed}catch(error){}

  if(layer.kind==="video"){
    // Canvas supplies the picture. Muting the video prevents autoplay rejection
    // and duplicate audio after Separate Audio.
    element.muted=true;
  }else{
    element.muted=!!layer.muted;
    element.volume=Math.max(
      0,
      Math.min(1,masterVolume*(layer.volume??1))
    );
  }

  if(!isActive){
    try{element.pause()}catch(error){}
    return;
  }

  const drift=Math.abs((element.currentTime||0)-localTime);
  if(force || drift>.20){
    safeSetMediaTime(element,localTime);
  }

  if(playing){
    safePlayMedia(element);
  }else{
    try{element.pause()}catch(error){}
  }
}

function synchronizeAllTimelineMedia(force=false){
  for(const layer of layers){
    if(layer.kind==="video"||layer.kind==="audio"){
      synchronizeOneMediaLayer(layer,force);
    }
  }
}

async function startPreviewPlayback(startAt=current){
  if(sourcePreviewMode) stopSourcePreview();

  duration=calcDuration();
  if(!layers.length){
    alert("請先把影片或音訊 Clip 放到 Timeline。");
    return;
  }

  current=Math.max(0,Math.min(Number(startAt)||0,duration));
  if(current>=duration) current=0;

  playbackAnchorCurrent=current;
  playbackAnchorTime=performance.now();
  playing=true;

  setPreviewStatus("Playing preview","playing");
  setV80TransportStatus("Playing");
  setPlaybackCoreStatus("Playback running","running");

  // Start the clock immediately from the user's click.
  sync(true);
  drawPreviewFrame();
  renderPreviewOverlays();
  updatePlayheadPosition();

  // Hydrate missing assets in the background, then re-sync.
  const needed=layers
    .filter(layer=>active(layer))
    .map(layer=>assetOf(layer))
    .filter(Boolean);

  Promise.all(needed.map(asset=>hydrate(asset).catch(()=>asset)))
    .then(()=>{
      if(playing){
        sync(true);
        drawPreviewFrame();
      }
    });
}

function sync(force=false){
  synchronizeAllTimelineMedia(force);
}
let playbackAnchorTime = 0;
let playbackAnchorCurrent = 0;

function play(){
  startPreviewPlayback(current);
}

function pause(){
  if(playing){
    current=Math.min(
      duration,
      playbackAnchorCurrent+((performance.now()-playbackAnchorTime)/1000)*speed
    );
  }
  playing=false;
  for(const asset of assets){
    if(asset.el?.pause) asset.el.pause();
  }
  drawPreviewFrame();
  updatePlayheadPosition();
  setPreviewStatus("Preview paused","paused");setV80TransportStatus("Paused");setPlaybackCoreStatus("Playback paused");
}

function stop(){
  playing=false;
  current=0;
  playbackAnchorCurrent=0;
  for(const asset of assets){
    if(asset.el?.pause) asset.el.pause();
    if(asset.el && "currentTime" in asset.el){
      try{asset.el.currentTime=0}catch(e){}
    }
  }
  sync(true);
  drawPreviewFrame();
  updatePlayheadPosition();
  setPreviewStatus("Preview stopped");setV80TransportStatus("Stopped");setPlaybackCoreStatus("Playback stopped");
}

function seek(t){
  duration = calcDuration();
  current = Math.max(0,Math.min(Number(t)||0,duration));
  playbackAnchorCurrent = current;
  playbackAnchorTime = performance.now();
  sync(true);
  render();
  updatePlayheadPosition();

  updateManualPlayheadStatus(`Playhead: ${fmt(current)} · drag to seek`);
}

function trimIn(){
  let l=layers.find(x=>x.id===selected);if(!l||current<=l.start||current>=clipEnd(l))return;
  pushUndo();let d=current-l.start;l.start=current;l.duration=Math.max(.5,l.duration-d);if(l.kind==="video"||l.kind==="audio")l.trim=(l.trim||0)+d;duration=calcDuration();renderAll();saveManifest();
}
function trimOut(){
  const layer=layers.find(item=>item.id===selected);
  if(!layer||current<=layer.start||current>=clipEnd(layer)) return;
  pushUndo();
  layer.duration=Math.max(.05,current-layer.start);
  duration=calcDuration();
  renderAll();
  saveManifest();
}
function split(){
  let l=layers.find(x=>x.id===selected);if(!l||current<=l.start||current>=clipEnd(l))return;
  pushUndo();let left=current-l.start,right=l.duration-left,copy={...l,id:uid(),start:current,duration:right,trim:(l.trim||0)+left,z:l.z+1};l.duration=left;layers.push(copy);selected=copy.id;renderAll();saveManifest();
}
function duplicate(){let l=layers.find(x=>x.id===selected);if(!l)return;pushUndo();let c={...l,id:uid(),start:l.start+1,z:layers.length};layers.push(c);selected=c.id;renderAll();saveManifest()}

function drawChroma(source,x,y,w,h,l){
  if(!l.chroma){ctx.drawImage(source,x,y,w,h);return}
  let tmp=document.createElement("canvas");tmp.width=Math.max(1,Math.round(w));tmp.height=Math.max(1,Math.round(h));let t=tmp.getContext("2d",{willReadFrequently:true});
  try{
    t.drawImage(source,0,0,tmp.width,tmp.height);
    let img=t.getImageData(0,0,tmp.width,tmp.height),d=img.data,hex=l.chromaColor||"#00ff00",key=[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)],tol=+(l.chromaTolerance||70);
    for(let i=0;i<d.length;i+=4){let dr=d[i]-key[0],dg=d[i+1]-key[1],db=d[i+2]-key[2];if(Math.sqrt(dr*dr+dg*dg+db*db)<tol)d[i+3]=0}
    t.putImageData(img,0,0);ctx.drawImage(tmp,x,y,w,h);
  }catch(e){ctx.drawImage(source,x,y,w,h)}
}
function render(){
  drawPreviewFrame();

  renderPreviewOverlays();
}

function renderMedia(){
  let q=($("mediaSearch").value||"").toLowerCase(),box=$("mediaList");box.innerHTML="";
  let list=assets.filter(a=>(filter==="all"||a.kind===filter)&&(!q||a.name.toLowerCase().includes(q)));
  $("assetCount").textContent=`${assets.length} copied assets · NoText`;
  for(const a of list){
    let card=document.createElement("div");card.className="media-card"+(a.id===selectedAsset?" selected":"");
    let th=document.createElement("div");th.className="thumb";
    if(a.kind==="image"&&a.url){let img=new Image();img.src=a.url;img.className="thumb";th=img}
    else if(a.kind==="video"&&a.url){let v=document.createElement("video");v.src=a.url;v.muted=true;v.preload="metadata";v.className="thumb";th=v}
    else th.textContent=icon(a.kind);
    let meta=document.createElement("div");meta.className="media-meta";meta.innerHTML=`<b>${a.name}</b><small>${fmt(a.duration||0)}</small><small>${a.w||1920}x${a.h||1080}</small>`;
    card.append(th,meta);card.onclick=async()=>{selectedAsset=a.id;await hydrate(a);let l=layers.find(x=>x.assetId===a.id);if(!l)addLayerFromAsset(a);l=layers.find(x=>x.assetId===a.id);if(l){selected=l.id;current=l.start;seek(current)}renderAll()};box.appendChild(card);
  }
}
function renderRuler(){let r=$("timeRuler");r.innerHTML="";let total=Math.ceil(duration);for(let s=0;s<=total;s+=2){let d=document.createElement("div");d.className="tick";d.style.left=(s/secPerPx)+"px";d.textContent="00:"+String(s).padStart(2,"0");r.appendChild(d)}}
function renderTrackHeads(){
  const head=$("trackHeads");
  if(!head) return;
  head.innerHTML="";
  rows.forEach((row,index)=>{
    const title=document.createElement("div");
    title.className=`track-title ${row.type}-track`;
    title.dataset.row=index;
    title.innerHTML=`<span>${row.label}</span><span>👁 🔒</span>`;
    head.appendChild(title);
  });
}
function normalizeTrackRows(){
  for(const layer of layers){
    if(layer.kind === "audio"){
      if(!Number.isInteger(layer.row) || layer.row < 5 || layer.row > 9){
        layer.row = 5;
      }
    }else{
      if(!Number.isInteger(layer.row) || layer.row < 0 || layer.row > 4){
        layer.row = 0;
      }
    }
  }
}

function firstAvailableTrack(kind,startTime,endTime){
  const candidates = kind === "audio" ? [5,6,7,8,9] : [0,1,2,3,4];
  for(const row of candidates){
    const busy = layers.some(layer =>
      layer.row === row &&
      startTime < clipEnd(layer) &&
      endTime > layer.start
    );
    if(!busy) return row;
  }
  return candidates[0];
}

function renderTracks(){
  normalizeTrackRows();

  const labels = $("trackLabels") || document.querySelector(".track-labels");
  const tracks = $("tracks");
  if(!tracks) return;

  const definitions = [
    {label:"▦ Video 1",type:"video"},
    {label:"▦ Video 2",type:"video"},
    {label:"▦ Video 3",type:"video"},
    {label:"▦ Video 4",type:"video"},
    {label:"▦ Video 5",type:"video"},
    {label:"♫ Audio 1",type:"audio"},
    {label:"♫ Audio 2",type:"audio"},
    {label:"♫ Audio 3",type:"audio"},
    {label:"♫ Audio 4",type:"audio"},
    {label:"♫ Audio 5",type:"audio"}
  ];

  if(labels){
    labels.innerHTML = "";
    definitions.forEach((definition,row)=>{
      const title = document.createElement("div");
      title.className = `track-title ${definition.type}-track`;
      title.dataset.row = row;
      title.innerHTML = `<span>${definition.label}</span><span>👁 🔒</span>`;
      labels.appendChild(title);
    });
  }

  tracks.innerHTML = "";

  definitions.forEach((definition,row)=>{
    const lane = document.createElement("div");
    lane.className = `track-lane ${definition.type}-track`;
    lane.dataset.row = row;

    const rowLayers = layers.filter(layer => layer.row === row);
    if(!rowLayers.length){
      const hint = document.createElement("span");
      hint.className = "track-empty-hint";
      hint.textContent = definition.type === "audio"
        ? "Drop audio clip here"
        : "Drop video/image clip here";
      lane.appendChild(hint);
    }

    lane.addEventListener("dragover",event=>{
      event.preventDefault();
      lane.classList.add("drag-over");
      event.dataTransfer.dropEffect="move";
    });
    lane.addEventListener("dragleave",()=>lane.classList.remove("drag-over"));

    lane.addEventListener("drop",event=>{
      event.preventDefault();
      lane.classList.remove("drag-over");

      const layerId = event.dataTransfer.getData("layerId");
      const assetId = event.dataTransfer.getData("assetId") || event.dataTransfer.getData("asset") || event.dataTransfer.getData("asset-id");
      const rect = lane.getBoundingClientRect();
      const startTime = snapTime(Math.max(
        0,
        (event.clientX - rect.left + ($("timeArea")?.scrollLeft || 0)) * secPerPx
      ));

      if(layerId){
        const layer = layers.find(item=>item.id===layerId);
        if(!layer) return;

        const compatible = canDropOnRow(layer.kind,row);

        if(!compatible){
          alert(definition.type === "audio"
            ? "Audio 軌道只能放置 Audio Clip。"
            : "Video 軌道只能放置 Video 或 Image Clip。");
          return;
        }

        pushUndo();
        layer.row = row;
        layer.start = startTime;
        selected = layer.id;
        duration = calcDuration();
        saveManifest();
        renderAll();
        return;
      }

      if(assetId){
        const asset = assets.find(item=>item.id===assetId);
        if(!asset) return;

        const assetIsAudio = isAudioAsset(asset);
        if(!canDropOnRow(asset.kind,row)){
          alert(assetIsAudio
            ? "音訊素材請放到 Audio 1～5。"
            : "影片或圖片素材請放到 Video 1～5。");
          return;
        }

        pushUndo();
        const layer = {
          id:uid(),
          assetId:asset.id,
          name:asset.name,
          kind:asset.kind,
          start:startTime,
          duration:asset.kind === "image" ? 5 : Math.max(.5,asset.duration || 5),
          trim:0,
          x:960,
          y:540,
          scale:1,
          muted:false,
          volume:1,
          row,
          z:layers.length,
          chroma:false,
          chromaColor:"#00ff00",
          chromaTolerance:70
        };

        layers.push(layer);
        selected = layer.id;
        duration = calcDuration();
        saveManifest();
        renderAll();
      }
    });

    for(const layer of rowLayers){
      const clip = document.createElement("div");
      clip.className = `clip ${layer.kind}${selected===layer.id ? " selected" : ""}`;
      clip.dataset.id = layer.id;
      clip.draggable = true;
      clip.style.left = `${layer.start/secPerPx}px`;
      clip.style.width = `${Math.max(30,layer.duration/secPerPx)}px`;
      clip.title = `${layer.name}\n${fmt(layer.start)} – ${fmt(clipEnd(layer))}`;
      clip.innerHTML =
        `<span class="clip-name">${layer.name}</span>` +
        `<span class="clip-time">${fmt(layer.duration)}</span>`;

      if(layer.linkedGroup) clip.classList.add("linked-av");
      if(layer.splitAudio) clip.classList.add("split-audio");
      if(layer.kind==="audio"){
        if(layer.muted) clip.classList.add("muted");
        const wave=document.createElement("span");
        wave.className="audio-wave-mini";
        clip.appendChild(wave);
      }
      if(layerHasEffects(layer)) clip.classList.add("has-effects");

      const clearFxButton = document.createElement("button");
      clearFxButton.type = "button";
      clearFxButton.className = "clip-fx-clear-btn";
      clearFxButton.textContent = "FX";
      clearFxButton.title = "Clear effects from this clip only";
      clearFxButton.addEventListener("click",event=>{
        event.stopPropagation();
        selected = layer.id;
        clearSingleClipEffectsById(layer.id,true);
      });

      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "clip-delete-btn";
      deleteButton.textContent = "×";
      deleteButton.title = "Delete this clip only";
      deleteButton.addEventListener("click",event=>{
        event.stopPropagation();
        selected = layer.id;
        deleteSingleClipById(layer.id,true);
      });

      clip.append(clearFxButton,deleteButton);

      clip.addEventListener("click",event=>{
        event.stopPropagation();
        selected = layer.id;
        loadInspector(layer);
        renderAll();
      });

      clip.addEventListener("dragstart",event=>{
        event.dataTransfer.setData("layerId",layer.id);
        event.dataTransfer.effectAllowed = "move";
      });

      clip.addEventListener("mousedown",event=>{
        if(event.target.classList.contains("resize-handle")) return;
        dragClip(event,layer);
      });

      const leftHandle = document.createElement("span");
      leftHandle.className = "resize-handle left";
      leftHandle.addEventListener("mousedown",event=>resizeClip(event,layer,"left"));

      const rightHandle = document.createElement("span");
      rightHandle.className = "resize-handle right";
      rightHandle.addEventListener("mousedown",event=>resizeClip(event,layer,"right"));

      clip.append(leftHandle,rightHandle);
      lane.appendChild(clip);
    }

    tracks.appendChild(lane);
  });

  const requiredWidth = Math.max(
    $("timeArea")?.clientWidth || 800,
    duration/secPerPx + 240
  );
  tracks.style.width = `${requiredWidth}px`;
  if(labels) labels.style.height = `${definitions.length*46}px`;

  stableResizeTimeline();

  v80ResizeTimeline();
}
function resizeClip(e,l,side){e.preventDefault();e.stopPropagation();pushUndo();let sx=e.clientX,os=l.start,od=l.duration,ot=l.trim||0;function mv(ev){let ds=(ev.clientX-sx)*secPerPx;if(side==="right")l.duration=Math.max(.5,od+ds);else{l.start=snapTime(Math.max(0,os+ds));l.duration=Math.max(.5,od-ds);if(l.kind==="video"||l.kind==="audio")l.trim=Math.max(0,ot+(l.start-os))}duration=calcDuration();renderAll()}function up(){removeEventListener("mousemove",mv);removeEventListener("mouseup",up);saveManifest()}addEventListener("mousemove",mv);addEventListener("mouseup",up)}
function dragClip(e,l){e.preventDefault();pushUndo();let sx=e.clientX,sy=e.clientY,os=l.start,or=l.row;function mv(ev){let old=l.start;l.start=snapTime(Math.max(0,os+(ev.clientX-sx)*secPerPx));let nr=Math.max(0,Math.min(rows.length-1,or+Math.round((ev.clientY-sy)/42)));if(validRow(l.kind,nr))l.row=nr;if($("rippleMove").checked){let delta=l.start-old;for(const o of layers)if(o.id!==l.id&&o.row===l.row&&o.start>=old)o.start=Math.max(0,o.start+delta)}duration=calcDuration();renderAll()}function up(){removeEventListener("mousemove",mv);removeEventListener("mouseup",up);saveManifest()}addEventListener("mousemove",mv);addEventListener("mouseup",up)}
function loadInspector(layer){
  if($("selectedInfo")){
    $("selectedInfo").textContent=layer
      ? `${layer.kind.toUpperCase()} · ${layer.name}`
      : "No clip selected";
  }
  if(!layer) return;

  if($("xInput")) $("xInput").value=Math.round(layer.x??960);
  if($("yInput")) $("yInput").value=Math.round(layer.y??540);
  if($("scaleInput")) $("scaleInput").value=layer.scale??1;
  if($("startInput")) $("startInput").value=layer.start??0;
  if($("durationInput")) $("durationInput").value=layer.duration??0;
  if($("clipVolume")) $("clipVolume").value=layer.volume??1;
  if($("chromaOn")) $("chromaOn").checked=!!layer.chroma;
  if($("chromaColor")) $("chromaColor").value=layer.chromaColor||"#00ff00";
  if($("chromaTolerance")) $("chromaTolerance").value=layer.chromaTolerance??70;

  if(layer.kind==="audio"){
    if($("selectedAudioVolume")){
      $("selectedAudioVolume").value=layer.volume??1;
    }
    if($("muteSelectedAudio")){
      $("muteSelectedAudio").textContent=layer.muted?"Unmute":"Mute";
    }
  }
}
function applyInspector(){let l=layers.find(x=>x.id===selected);if(!l)return;l.x=+$("xInput").value;l.y=+$("yInput").value;l.scale=+$("scaleInput").value;l.start=+$("startInput").value;l.duration=+$("durationInput").value;l.volume=+$("clipVolume").value;l.chroma=$("chromaOn").checked;l.chromaColor=$("chromaColor").value;l.chromaTolerance=+$("chromaTolerance").value;duration=calcDuration();renderAll()}
function renderAll(){duration=calcDuration();render();renderMedia();renderTrackHeads();renderRuler();renderTracks();$("scrubber").max=duration;$("scrubber").value=current;$("timeLabel").textContent=`${fmt(current)} / ${fmt(duration)}`;$("durStatus").textContent=`Duration: ${fmt(duration)}`
  updatePlayheadPosition();
}
let studioFlowLastHeartbeat=0;
function loop(){
  try{
    const now=performance.now();
    if(now-studioFlowLastHeartbeat>1000){
      studioFlowLastHeartbeat=now;
      setEngineHeartbeat(
        playing ? `Playing ${fmt(current)}` : `Ready ${fmt(current)}`,
        "ok"
      );
    }
    if(playing&&!manualPlayheadDragging){
      const selectedSpeed=Math.max(.1,+($("speed")?.value||1));
      speed=selectedSpeed;

      current=
        playbackAnchorCurrent+
        ((performance.now()-playbackAnchorTime)/1000)*selectedSpeed;

      if(current>=duration){
        current=duration;
        pause();
      }else{
        synchronizeAllTimelineMedia(false);
      }
    }

    drawPreviewFrame();
    renderPreviewOverlays();
    updatePlayheadPosition();
    drawWaveform();
  }catch(error){
    console.error("Playback frame failed:",error);
    setPlaybackCoreStatus("Recovered frame error","error");
  }finally{
    requestAnimationFrame(loop);
  }
}
function drawWaveform(){let c=$("waveformCanvas");if(!c)return;let g=c.getContext("2d"),w=c.width,h=c.height;g.clearRect(0,0,w,h);g.fillStyle="#06111f";g.fillRect(0,0,w,h);g.strokeStyle="#0ea5e9";g.beginPath();for(let x=0;x<w;x++){let amp=Math.sin(x*.08+current)*Math.sin(x*.023)*.45+.5,y=h/2+(amp-.5)*h*.8;if(x===0)g.moveTo(x,y);else g.lineTo(x,y)}g.stroke()}

async function recordWebM(){let stream=canvas.captureStream(30),chunks=[],old=current,was=playing;seek(0);play();let rec=new MediaRecorder(stream,{mimeType:MediaRecorder.isTypeSupported("video/webm;codecs=vp9")?"video/webm;codecs=vp9":"video/webm"});rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};let done=new Promise(r=>rec.onstop=()=>r(new Blob(chunks,{type:"video/webm"})));rec.start(250);setTimeout(()=>rec.stop(),Math.max(1,duration)*1000);let blob=await done;pause();seek(old);if(was)play();return blob}
function download(blob,name){let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000)}
async function getFF(){if(location.protocol==="file:")throw Error("MP4/MP3 needs localhost. Run start_server.bat");let {FFmpeg}=window.FFmpegWASM;let ff=new FFmpeg();await ff.load();return ff}
async function exportWebM(){download(await recordWebM(),"studioflow_notext.webm")}
async function exportMP4(){try{let webm=await recordWebM(),ff=await getFF();await ff.writeFile("in.webm",new Uint8Array(await webm.arrayBuffer()));await ff.exec(["-i","in.webm","-c:v","libx264","-pix_fmt","yuv420p","-preset","veryfast","-crf","23","-movflags","+faststart","out.mp4"]);let data=await ff.readFile("out.mp4");download(new Blob([data.buffer],{type:"video/mp4"}),"studioflow_notext.mp4")}catch(e){alert(e.message+"\\nExporting WebM fallback.");exportWebM()}}
async function exportMP3(){try{let webm=await recordWebM(),ff=await getFF();await ff.writeFile("in.webm",new Uint8Array(await webm.arrayBuffer()));await ff.exec(["-i","in.webm","-vn","-acodec","libmp3lame","-b:a","192k","out.mp3"]);let data=await ff.readFile("out.mp3");download(new Blob([data.buffer],{type:"audio/mpeg"}),"studioflow_notext.mp3")}catch(e){alert("MP3 export failed: "+e.message)}}
function saveProject(){saveManifest();download(new Blob([JSON.stringify({assets:assets.map(a=>({id:a.id,dbId:a.dbId,name:a.name,kind:a.kind,duration:a.duration,w:a.w,h:a.h,type:a.type})),layers,current,duration},null,2)],{type:"application/json"}),"project.studioflow")}


function splitLayerAt(layer, at, rightGroup){
  if(!layer || at <= layer.start || at >= clipEnd(layer)) return null;
  const leftDuration = at - layer.start;
  const rightDuration = layer.duration - leftDuration;
  if(leftDuration < 0.05 || rightDuration < 0.05) return null;

  const right = {
    ...layer,
    id: uid(),
    start: at,
    duration: rightDuration,
    trim: (layer.trim || 0) + leftDuration,
    z: layers.length
  };
  if(rightGroup !== undefined) right.linkedGroup = rightGroup;
  layer.duration = leftDuration;
  layers.push(right);
  return right;
}

function splitLinkedAVCore(){
  const selectedLayer = layers.find(l => l.id === selected);
  if(!selectedLayer){
    alert("請先選取影片或音訊 Clip。");
    return;
  }

  const group = selectedLayer.linkedGroup;
  const targets = group
    ? layers.filter(l => l.linkedGroup === group && current > l.start && current < clipEnd(l))
    : [selectedLayer].filter(l => current > l.start && current < clipEnd(l));

  if(!targets.length){
    alert("播放頭必須位於 Clip 中間。");
    return;
  }

  pushUndo();
  const rightGroup = group ? uid() : undefined;
  const created = targets.map(l => splitLayerAt(l, current, rightGroup)).filter(Boolean);
  const preferred = created.find(l => l.kind === selectedLayer.kind) || created[0];
  if(preferred) selected = preferred.id;
  duration = calcDuration();
  saveManifest();
  sync(true);
  renderAll();
}

function unlinkSelectedAVCore(){
  const selectedLayer = layers.find(l => l.id === selected);
  if(!selectedLayer?.linkedGroup){
    alert("選取的 Clip 沒有影音連結。");
    return;
  }
  pushUndo();
  const group = selectedLayer.linkedGroup;
  for(const layer of layers.filter(l => l.linkedGroup === group)){
    layer.linkedGroup = null;
    layer.independentAfterSplit = true;
  }
  saveManifest();
  renderAll();
}

function duplicateSelectedCore(){
  const layer = layers.find(l => l.id === selected);
  if(!layer) return;
  pushUndo();
  const copy = {...layer, id:uid(), start:layer.start + 0.5, z:layers.length};
  layers.push(copy);
  selected = copy.id;
  duration = calcDuration();
  saveManifest();
  renderAll();
}



function ensurePlayhead(){
  let head = $("playhead");
  if(!head){
    head = document.createElement("div");
    head.id = "playhead";
    head.className = "playhead";
    const area = $("timeArea") || $("trackLanes")?.parentElement;
    if(area) area.appendChild(head);
  }
  return head;
}

function updatePlayheadPosition(){
  const head = ensurePlayhead();
  const area = $("timeArea");
  if(head){
    const x = current / secPerPx;
    head.style.left = `${x}px`;
    head.style.transform = "none";
  }

  const scrubber = $("scrubber");
  if(scrubber){
    scrubber.max = Math.max(0.01,duration);
    scrubber.value = Math.min(duration,current);
  }

  const label = $("timeLabel");
  if(label) label.textContent = `${fmt(current)} / ${fmt(duration)}`;

  // Keep the moving playhead visible while playing.
  if(playing && area){
    const x = current/secPerPx;
    const left = area.scrollLeft;
    const right = left + area.clientWidth;
    if(x > right - 80) area.scrollLeft = Math.max(0,x-area.clientWidth+120);
    if(x < left) area.scrollLeft = Math.max(0,x-40);
  }
}

let playheadFrame = 1;

function bindDynamicTrackButtons(){
  if($("addVideoTrack")) $("addVideoTrack").onclick = () => {
    alert("Video 軌道已固定提供 5 個：Video 1～Video 5。");
  };
  if($("addAudioTrack")) $("addAudioTrack").onclick = () => {
    alert("Audio 軌道已固定提供 5 個：Audio 1～Audio 5。");
  };
  if($("removeLastTrack")) $("removeLastTrack").onclick = () => {
    alert("為保留最多 10 軌的彈性，軌道不會永久刪除；可刪除該軌上的 Clips。");
  };
}



function layerHasEffects(layer){
  if(!layer) return false;
  return Boolean(
    layer.chroma ||
    (layer.transition && layer.transition !== "none") ||
    (layer.lut && layer.lut !== "none") ||
    (Array.isArray(layer.effects) && layer.effects.length) ||
    (Array.isArray(layer.keyframes) && layer.keyframes.length) ||
    layer.proxy ||
    layer.opacity !== undefined && layer.opacity !== 1 ||
    layer.rotation
  );
}

function clearEffectsFromLayer(layer){
  if(!layer) return;
  layer.chroma = false;
  layer.chromaColor = "#00ff00";
  layer.chromaTolerance = 70;
  layer.transition = "none";
  layer.lut = "none";
  layer.effects = [];
  layer.keyframes = [];
  layer.proxy = false;
  layer.opacity = 1;
  layer.rotation = 0;
  layer.fadeIn = 0;
  layer.fadeOut = 0;
}

function deleteSingleClipById(layerId, ask=true){
  const layer = layers.find(item=>item.id===layerId);
  if(!layer) return;

  if(ask && !confirm(`Delete only this clip?\n\n${layer.name}`)) return;

  pushUndo();
  layers = layers.filter(item=>item.id!==layerId);

  // Do not delete linked audio/video automatically.
  // Only remove the selected timeline clip.
  if(selected===layerId) selected=null;

  duration = calcDuration();
  saveManifest();
  sync(true);
  renderAll();
}

function deleteSelectedClipOnly(){
  if(!selected){
    alert("請先選取要刪除的 Clip。");
    return;
  }
  deleteSingleClipById(selected,true);
}

function clearSingleClipEffectsById(layerId, ask=true){
  const layer = layers.find(item=>item.id===layerId);
  if(!layer) return;

  if(!layerHasEffects(layer)){
    alert("選取的 Clip 沒有可清除的 Effects。");
    return;
  }

  if(ask && !confirm(`Clear effects only from this clip?\n\n${layer.name}`)) return;

  pushUndo();
  clearEffectsFromLayer(layer);

  if($("chromaOn")) $("chromaOn").checked=false;
  if($("chromaColor")) $("chromaColor").value="#00ff00";
  if($("chromaTolerance")) $("chromaTolerance").value=70;

  saveManifest();
  loadInspector(layer);
  renderAll();
}

function clearSelectedClipEffectsOnly(){
  if(!selected){
    alert("請先選取要清除 Effects 的 Clip。");
    return;
  }
  clearSingleClipEffectsById(selected,true);
}

function bindIndividualDeleteControls(){
  const deleteIds = ["deleteCurrentClip","deleteOnlySelected"];
  for(const id of deleteIds){
    if($(id)) $(id).onclick=deleteSelectedClipOnly;
  }

  const clearIds = ["clearCurrentClipEffects","clearOnlySelectedFX"];
  for(const id of clearIds){
    if($(id)) $(id).onclick=clearSelectedClipEffectsOnly;
  }
}



function stableResizeTimeline(){
  const area=$("timeArea");
  const tracks=$("tracks");
  if(!area||!tracks) return;
  const viewport=Math.max(800,area.clientWidth||800);
  const projectWidth=duration>0?duration/secPerPx+400:viewport*2;
  tracks.style.width=`${Math.max(viewport*2,projectWidth)}px`;
  tracks.style.minHeight=`${rows.length*50}px`;
}

function stableBindTimelineNavigation(){
  const area=$("timeArea");
  if(!area) return;

  if($("stableStart")) $("stableStart").onclick=()=>area.scrollTo({left:0,behavior:"smooth"});
  if($("stableEnd")) $("stableEnd").onclick=()=>area.scrollTo({
    left:Math.max(0,area.scrollWidth-area.clientWidth),behavior:"smooth"
  });
  if($("stableTop")) $("stableTop").onclick=()=>area.scrollTo({top:0,behavior:"smooth"});
  if($("stableBottom")) $("stableBottom").onclick=()=>area.scrollTo({
    top:Math.max(0,area.scrollHeight-area.clientHeight),behavior:"smooth"
  });

  area.addEventListener("wheel",event=>{
    if(event.shiftKey){
      event.preventDefault();
      area.scrollLeft+=event.deltaY||event.deltaX;
    }
  },{passive:false});

  area.addEventListener("scroll",()=>{
    const heads=$("trackHeads");
    if(heads) heads.scrollTop=area.scrollTop;
  },{passive:true});

  window.addEventListener("resize",stableResizeTimeline);
  stableResizeTimeline();
}

function stableStartupCheck(){
  const required=[
    "canvas","play","pause","stop","scrubber","trackHeads",
    "timeArea","timeRuler","tracks","fileInput","dropZone"
  ];
  const missing=required.filter(id=>!$(id));
  if(missing.length){
    console.error("StudioFlow missing elements:",missing);
    alert("StudioFlow startup error: "+missing.join(", "));
    return false;
  }
  return true;
}


function bindTrackVerticalSync(){
  const area=$("timeArea");
  const heads=$("trackHeads");
  if(!area||!heads) return;

  area.addEventListener("scroll",()=>{
    heads.scrollTop=area.scrollTop;
  },{passive:true});

  heads.addEventListener("wheel",event=>{
    event.preventDefault();
    area.scrollTop+=event.deltaY;
  },{passive:false});
}


function audioTrackRows(){
  return [5,6,7,8,9];
}

function audioLayerById(id){
  return layers.find(layer=>layer.id===id&&layer.kind==="audio")||null;
}

function selectedAudioLayer(){
  return audioLayerById(selected);
}

function firstFreeAudioTrack(startTime,endTime,excludeId=null){
  for(const row of audioTrackRows()){
    const occupied=layers.some(layer=>
      layer.id!==excludeId &&
      layer.kind==="audio" &&
      layer.row===row &&
      startTime<clipEnd(layer) &&
      endTime>layer.start
    );
    if(!occupied) return row;
  }
  return 5;
}

function ensureAudioElement(asset){
  if(!asset) return null;
  if(asset.el && asset.el.tagName==="AUDIO") return asset.el;

  const el=document.createElement("audio");
  el.preload="auto";
  el.crossOrigin="anonymous";
  if(asset.url) el.src=asset.url;
  asset.el=el;
  try{el.load();}catch(e){}
  return el;
}

function setSelectedAudioTrack(row){
  const layer=selectedAudioLayer();
  if(!layer){
    alert("請先選取 Audio Clip。");
    return;
  }
  if(row<5||row>9) return;
  pushUndo();
  layer.row=row;
  saveManifest();
  renderAll();
}

function moveSelectedAudioToFreeTrack(){
  const layer=selectedAudioLayer();
  if(!layer){
    alert("請先選取 Audio Clip。");
    return;
  }
  pushUndo();
  layer.row=firstFreeAudioTrack(layer.start,clipEnd(layer),layer.id);
  saveManifest();
  renderAll();
}

function updateSelectedAudioVolume(value){
  const layer=selectedAudioLayer();
  if(!layer) return;
  layer.volume=Math.max(0,Math.min(2,Number(value)||0));
  const asset=assetOf(layer);
  const el=ensureAudioElement(asset);
  if(el) el.volume=Math.max(0,Math.min(1,layer.volume));
  saveManifest();
}

function toggleSelectedAudioMute(){
  const layer=selectedAudioLayer();
  if(!layer){
    alert("請先選取 Audio Clip。");
    return;
  }
  layer.muted=!layer.muted;
  const asset=assetOf(layer);
  const el=ensureAudioElement(asset);
  if(el) el.muted=layer.muted;
  saveManifest();
  renderAll();
}

function soloSelectedAudio(){
  const layer=selectedAudioLayer();
  if(!layer){
    alert("請先選取 Audio Clip。");
    return;
  }
  pushUndo();
  for(const item of layers.filter(x=>x.kind==="audio")){
    item.muted=item.id!==layer.id;
    const asset=assetOf(item);
    const el=ensureAudioElement(asset);
    if(el) el.muted=item.muted;
  }
  saveManifest();
  renderAll();
}

function syncAudioTracks(force=false){
  for(const layer of layers.filter(item=>item.kind==="audio")){
    const asset=assetOf(layer);
    const el=ensureAudioElement(asset);
    if(!el) continue;

    const active=current>=layer.start&&current<clipEnd(layer);
    const localTime=Math.max(0,(layer.trim||0)+(current-layer.start));

    el.muted=!!layer.muted;
    el.volume=Math.max(0,Math.min(1,layer.volume===undefined?1:layer.volume));
    el.playbackRate=speed||1;

    if(active&&playing){
      if(force||Math.abs((el.currentTime||0)-localTime)>.18){
        try{el.currentTime=Math.min(localTime,Number.isFinite(el.duration)?Math.max(0,el.duration-.02):localTime);}catch(e){}
      }
      if(el.paused){
        el.play().catch(()=>{});
      }
    }else{
      if(!el.paused) el.pause();
      if(force&&localTime>=0){
        try{el.currentTime=localTime;}catch(e){}
      }
    }
  }
}

function bindAudioTrackControls(){
  [1,2,3,4,5].forEach((n,index)=>{
    const button=$(`audioTrack${n}Btn`);
    if(button) button.onclick=()=>setSelectedAudioTrack(5+index);
  });

  const volume=$("selectedAudioVolume");
  if(volume){
    volume.oninput=()=>updateSelectedAudioVolume(volume.value);
  }
  if($("muteSelectedAudio")) $("muteSelectedAudio").onclick=toggleSelectedAudioMute;
  if($("soloSelectedAudio")) $("soloSelectedAudio").onclick=soloSelectedAudio;
  if($("moveSelectedAudioToFreeTrack")) $("moveSelectedAudioToFreeTrack").onclick=moveSelectedAudioToFreeTrack;
}


function setPreviewMode(mode){
  const preview=document.querySelector(".preview");
  const canvas=$("canvas");
  if(!preview||!canvas) return;

  if(mode==="small"){
    preview.style.height="200px";
    preview.style.maxHeight="200px";
    canvas.style.maxHeight="180px";
    canvas.style.maxWidth="70%";
  }else if(mode==="medium"){
    preview.style.height="280px";
    preview.style.maxHeight="280px";
    canvas.style.maxHeight="260px";
    canvas.style.maxWidth="80%";
  }else{
    preview.style.height="28vh";
    preview.style.maxHeight="300px";
    canvas.style.maxHeight="280px";
    canvas.style.maxWidth="78%";
  }

  try{
    localStorage.setItem("studioflow_preview_mode",mode);
  }catch(e){}
}

function bindPreviewSizeControls(){
  if($("previewSmall")) $("previewSmall").onclick=()=>setPreviewMode("small");
  if($("previewMedium")) $("previewMedium").onclick=()=>setPreviewMode("medium");
  if($("previewFit")) $("previewFit").onclick=()=>setPreviewMode("fit");

  let saved="small";
  try{
    saved=localStorage.getItem("studioflow_preview_mode")||"small";
  }catch(e){}
  setPreviewMode(saved);
}


function bindReferenceLayoutControls(){
  if($("timelineExportFocus")){
    $("timelineExportFocus").onclick=()=>{
      const button=$("exportMP4")||$("sideExportMP4");
      if(button) button.click();
    };
  }
  if($("timelineInfoBtn")){
    $("timelineInfoBtn").onclick=()=>alert(
      "StudioFlow Timeline\nVideo 1–5 / Audio 1–5\nShift + Wheel: horizontal scroll"
    );
  }
}


function isAudioAsset(asset){
  return !!asset && asset.kind==="audio";
}

function isVideoVisualAsset(asset){
  return !!asset && (asset.kind==="video" || asset.kind==="image");
}

function canDropOnRow(kind,row){
  if(kind==="audio") return row>=5 && row<=9;
  return row>=0 && row<=4;
}

function normalizeDroppedLayerKind(layer,row){
  if(row>=5){
    layer.kind="audio";
  }else if(layer.kind==="audio"){
    return false;
  }
  return true;
}

function playSelectedClipOnly(){
  const layer=layers.find(item=>item.id===selected);
  if(!layer){
    alert("請先選取要播放的 Clip。");
    return;
  }
  startPreviewPlayback(layer.start);
}

function playFromCurrentPlayhead(){
  startPreviewPlayback(current);
}

function restartTimelinePlayback(){
  startPreviewPlayback(0);
}

function bindPlaybackExtras(){
  if($("playSelectedClip")) $("playSelectedClip").onclick=playSelectedClipOnly;
  if($("playFromPlayhead")) $("playFromPlayhead").onclick=playFromCurrentPlayhead;
  if($("restartPlayback")) $("restartPlayback").onclick=restartTimelinePlayback;
}


function setV80TransportStatus(text){
  const el=$("v80TransportStatus");
  if(el) el.textContent=text;
}

function v80ResizeTimeline(){
  const area=$("timeArea");
  const tracks=$("tracks");
  if(!area||!tracks) return;
  const viewport=Math.max(900,area.clientWidth||900);
  const projectWidth=duration>0 ? duration/secPerPx+500 : viewport*2;
  tracks.style.width=`${Math.max(viewport*2,projectWidth)}px`;
  tracks.style.minHeight=`${rows.length*50}px`;
}

function bindV80Layout(){
  const area=$("timeArea");
  if(area){
    if($("v80Start")) $("v80Start").onclick=()=>area.scrollTo({left:0,behavior:"smooth"});
    if($("v80End")) $("v80End").onclick=()=>area.scrollTo({
      left:Math.max(0,area.scrollWidth-area.clientWidth),
      behavior:"smooth"
    });
    if($("v80Top")) $("v80Top").onclick=()=>area.scrollTo({top:0,behavior:"smooth"});
    if($("v80Bottom")) $("v80Bottom").onclick=()=>area.scrollTo({
      top:Math.max(0,area.scrollHeight-area.clientHeight),
      behavior:"smooth"
    });

    area.addEventListener("scroll",()=>{
      const heads=$("trackHeads");
      if(heads) heads.scrollTop=area.scrollTop;
    },{passive:true});

    area.addEventListener("wheel",event=>{
      if(event.shiftKey){
        event.preventDefault();
        area.scrollLeft+=event.deltaY||event.deltaX;
      }
    },{passive:false});
  }

  const zoom=$("v80Zoom");
  if(zoom){
    zoom.oninput=()=>{
      const percent=Math.max(25,Math.min(250,Number(zoom.value)||100));
      secPerPx=0.08/(percent/100);
      if($("v80ZoomValue")) $("v80ZoomValue").textContent=`${percent}%`;
      renderRuler();
      renderTracks();
      updatePlayheadPosition();
      v80ResizeTimeline();
    };
  }

  window.addEventListener("resize",v80ResizeTimeline);
  v80ResizeTimeline();
  setV80TransportStatus("Ready");
}


let manualPlayheadDragging=false;
let manualPlayheadWasPlaying=false;

function timelineClientXToTime(clientX){
  const area=$("timeArea");
  if(!area) return current;

  const rect=area.getBoundingClientRect();
  const contentX=Math.max(
    0,
    clientX-rect.left+area.scrollLeft
  );

  return Math.max(
    0,
    Math.min(duration,contentX*secPerPx)
  );
}

function updateManualPlayheadStatus(text,dragging=false){
  const status=$("manualPlayheadStatus");
  if(!status) return;
  status.textContent=text;
  status.classList.toggle("dragging",dragging);
}

function seekPreviewManually(time){
  current=Math.max(0,Math.min(Number(time)||0,duration));
  playbackAnchorCurrent=current;
  playbackAnchorTime=performance.now();

  sync(true);
  render();
  updatePlayheadPosition();

  const scrubber=$("scrubber");
  if(scrubber) scrubber.value=current;

  const label=$("timeLabel");
  if(label) label.textContent=`${fmt(current)} / ${fmt(duration)}`;
}

function beginManualPlayheadDrag(event){
  if(event.button!==undefined && event.button!==0) return;
  event.preventDefault();
  event.stopPropagation();

  const head=ensurePlayhead();
  manualPlayheadDragging=true;
  manualPlayheadWasPlaying=playing;

  if(playing){
    pause();
  }

  if(head){
    head.classList.add("dragging");
    try{head.setPointerCapture?.(event.pointerId)}catch(e){}
  }

  updateManualPlayheadStatus("Dragging playhead",true);
  seekPreviewManually(timelineClientXToTime(event.clientX));
}

function moveManualPlayhead(event){
  if(!manualPlayheadDragging) return;
  event.preventDefault();
  seekPreviewManually(timelineClientXToTime(event.clientX));

  const area=$("timeArea");
  if(area){
    const rect=area.getBoundingClientRect();
    const edge=50;

    if(event.clientX>rect.right-edge){
      area.scrollLeft+=20;
    }else if(event.clientX<rect.left+edge){
      area.scrollLeft=Math.max(0,area.scrollLeft-20);
    }
  }
}

function endManualPlayheadDrag(event){
  if(!manualPlayheadDragging) return;
  event?.preventDefault?.();

  manualPlayheadDragging=false;
  const head=ensurePlayhead();

  if(head){
    head.classList.remove("dragging");
    try{head.releasePointerCapture?.(event.pointerId)}catch(e){}
  }

  seekPreviewManually(current);
  updateManualPlayheadStatus(
    `Playhead: ${fmt(current)} · drag to seek`,
    false
  );

  // Resume automatically only when playback was active before dragging.
  if(manualPlayheadWasPlaying){
    startPreviewPlayback(current);
  }
}

function bindDraggablePlayhead(){
  const head=ensurePlayhead();
  const area=$("timeArea");
  if(!head || !area) return;

  head.addEventListener("pointerdown",beginManualPlayheadDrag);
  window.addEventListener("pointermove",moveManualPlayhead);
  window.addEventListener("pointerup",endManualPlayheadDrag);
  window.addEventListener("pointercancel",endManualPlayheadDrag);

  // Clicking the ruler or an empty timeline position also seeks.
  area.addEventListener("pointerdown",event=>{
    if(event.target.closest(".clip")) return;
    if(event.target===head || event.target.closest("#playhead")) return;

    // Only seek on the ruler/empty timeline; preserve lane drag interactions.
    if(event.button!==0) return;
    seekPreviewManually(timelineClientXToTime(event.clientX));
    updateManualPlayheadStatus(`Playhead: ${fmt(current)} · drag to seek`);
  });

  updateManualPlayheadStatus("Drag red playhead to seek");
}


let sourcePreviewMode=false;
let sourcePreviewAssetId=null;
let sourcePreviewElement=null;
let overlayDragState=null;

function sourceStatus(text){
  const el=$("sourcePreviewStatus");
  if(el) el.textContent=text;
}

function stopSourcePreview(){
  sourcePreviewMode=false;
  sourcePreviewAssetId=null;

  if(sourcePreviewElement){
    try{sourcePreviewElement.pause?.()}catch(e){}
    try{sourcePreviewElement.remove()}catch(e){}
    sourcePreviewElement=null;
  }

  document.querySelectorAll(".source-previewing")
    .forEach(element=>element.classList.remove("source-previewing"));

  sourceStatus("Timeline Preview");
  render();
}

async function previewSourceAsset(asset,cardElement=null){
  if(!asset) return;

  stopSourcePreview();
  sourcePreviewMode=true;
  sourcePreviewAssetId=asset.id;
  sourceStatus(`Source Preview: ${asset.name}`);

  if(cardElement) cardElement.classList.add("source-previewing");

  try{
    await hydrate(asset);
  }catch(e){}

  const preview=document.querySelector(".preview");
  if(!preview) return;

  if(asset.kind==="video"){
    const video=document.createElement("video");
    video.className="preview-source-video";
    video.src=asset.url||asset.el?.src||"";
    video.controls=true;
    video.autoplay=true;
    video.playsInline=true;
    video.volume=Math.max(0,Math.min(1,+($("volume")?.value||0.8)));
    preview.appendChild(video);
    sourcePreviewElement=video;
    video.play().catch(()=>{});
  }else if(asset.kind==="audio"){
    const audio=document.createElement("audio");
    audio.src=asset.url||asset.el?.src||"";
    audio.controls=true;
    audio.autoplay=true;
    audio.style.position="absolute";
    audio.style.left="50%";
    audio.style.top="50%";
    audio.style.transform="translate(-50%,-50%)";
    audio.style.zIndex="9";
    preview.appendChild(audio);
    sourcePreviewElement=audio;
    audio.play().catch(()=>{});
  }else{
    const image=document.createElement("img");
    image.className="preview-source-image";
    image.src=asset.url||asset.el?.src||"";
    preview.appendChild(image);
    sourcePreviewElement=image;
  }
}

function normalizedPreviewPosition(clientX,clientY){
  const preview=document.querySelector(".preview");
  if(!preview) return {x:960,y:540};

  const rect=preview.getBoundingClientRect();
  const nx=Math.max(0,Math.min(1,(clientX-rect.left)/Math.max(1,rect.width)));
  const ny=Math.max(0,Math.min(1,(clientY-rect.top)/Math.max(1,rect.height)));

  return {
    x:nx*1920,
    y:ny*1080
  };
}

function beginOverlayDrag(event,layerId){
  if(event.button!==undefined&&event.button!==0) return;
  event.preventDefault();
  event.stopPropagation();

  const layer=layers.find(item=>item.id===layerId);
  if(!layer) return;

  selected=layer.id;
  loadInspector(layer);

  const point=normalizedPreviewPosition(event.clientX,event.clientY);
  overlayDragState={
    layerId:layer.id,
    offsetX:point.x-(layer.x??960),
    offsetY:point.y-(layer.y??540)
  };

  event.currentTarget.classList.add("selected");
  try{event.currentTarget.setPointerCapture?.(event.pointerId)}catch(e){}
}

function moveOverlayDrag(event){
  if(!overlayDragState) return;
  event.preventDefault();

  const layer=layers.find(item=>item.id===overlayDragState.layerId);
  if(!layer) return;

  const point=normalizedPreviewPosition(event.clientX,event.clientY);
  layer.x=Math.max(0,Math.min(1920,point.x-overlayDragState.offsetX));
  layer.y=Math.max(0,Math.min(1080,point.y-overlayDragState.offsetY));

  if($("xInput")) $("xInput").value=Math.round(layer.x);
  if($("yInput")) $("yInput").value=Math.round(layer.y);

  renderPreviewOverlays();
  drawPreviewFrame();
}

function endOverlayDrag(event){
  if(!overlayDragState) return;
  event?.preventDefault?.();

  const layer=layers.find(item=>item.id===overlayDragState.layerId);
  overlayDragState=null;

  document.querySelectorAll(".preview-overlay-item")
    .forEach(element=>element.classList.remove("selected"));

  if(layer){
    saveManifest();
    renderAll();
  }
}

function layerOverlaySource(layer){
  const asset=assetOf(layer);
  if(!asset) return null;

  return {
    layer,
    asset,
    src:asset.url||asset.el?.src||""
  };
}

function renderPreviewOverlays(){
  const container=$("previewOverlayLayer");
  const preview=document.querySelector(".preview");
  if(!container||!preview) return;

  container.innerHTML="";
  if(sourcePreviewMode) return;

  const activeLayers=layers
    .filter(layer=>active(layer))
    .filter(layer=>
      layer.kind==="image"||
      layer.kind==="text"||
      layer.overlayType==="text"||
      layer.overlayType==="gif"||
      layer.overlayType==="tif"
    )
    .sort((a,b)=>(a.z||0)-(b.z||0));

  const rect=preview.getBoundingClientRect();
  const sx=rect.width/1920;
  const sy=rect.height/1080;

  for(const layer of activeLayers){
    const element=document.createElement("div");
    element.className="preview-overlay-item";
    element.dataset.layerId=layer.id;

    const asset=assetOf(layer);
    const scale=layer.scale||1;
    const rawWidth=asset?.w||asset?.el?.naturalWidth||640;
    const rawHeight=asset?.h||asset?.el?.naturalHeight||360;
    const width=Math.max(60,rawWidth*scale);
    const height=Math.max(40,rawHeight*scale);
    const x=(layer.x??960)-width/2;
    const y=(layer.y??540)-height/2;

    element.style.left=`${x*sx}px`;
    element.style.top=`${y*sy}px`;
    element.style.width=`${width*sx}px`;
    element.style.height=`${height*sy}px`;

    if(layer.kind==="text"||layer.overlayType==="text"){
      const text=document.createElement("div");
      text.className="preview-text-block";
      text.textContent=layer.text||layer.name||"Text";
      text.style.fontSize=`${Math.max(12,(layer.fontSize||48)*Math.min(sx,sy))}px`;
      element.appendChild(text);
    }else{
      const image=document.createElement("img");
      image.src=asset?.url||asset?.el?.src||"";
      element.appendChild(image);
    }

    element.addEventListener("pointerdown",event=>beginOverlayDrag(event,layer.id));
    container.appendChild(element);
  }
}

function bindDoubleClickSourcePreview(){
  const mediaRoot=document.querySelector(".media-list,.bin-list,#mediaList,#assetList");
  if(!mediaRoot) return;

  mediaRoot.addEventListener("dblclick",event=>{
    const card=event.target.closest("[data-asset-id],.asset-card,.media-card");
    if(!card) return;

    const id=
      card.dataset.assetId||
      card.getAttribute("data-id")||
      card.dataset.id;

    let asset=assets.find(item=>item.id===id);

    if(!asset){
      const title=card.textContent?.trim();
      asset=assets.find(item=>title&&title.includes(item.name));
    }

    if(asset){
      previewSourceAsset(asset,card);
    }
  });
}

function bindOverlayDragging(){
  window.addEventListener("pointermove",moveOverlayDrag);
  window.addEventListener("pointerup",endOverlayDrag);
  window.addEventListener("pointercancel",endOverlayDrag);

  window.addEventListener("resize",renderPreviewOverlays);

  if($("returnTimelinePreview")){
    $("returnTimelinePreview").onclick=stopSourcePreview;
  }
}

let studioFlowLoopStarted=false;

function setEngineHeartbeat(text,state=""){
  const el=$("engineHeartbeat");
  if(!el) return;
  el.textContent=text;
  el.classList.remove("ok","warn","error");
  if(state) el.classList.add(state);
}

function safeInitStep(name,fn){
  try{
    fn();
    console.log(`[StudioFlow] ${name}: OK`);
    return true;
  }catch(error){
    console.error(`[StudioFlow] ${name}: FAILED`,error);
    setEngineHeartbeat(`${name} failed`,"warn");
    return false;
  }
}

function safeOn(id,event,handler){
  const element=$(id);
  if(!element){
    console.warn(`[StudioFlow] Missing control: ${id}`);
    return;
  }
  element[event]=handler;
}

function startStudioFlowLoopOnce(){
  if(studioFlowLoopStarted) return;
  studioFlowLoopStarted=true;
  requestAnimationFrame(loop);
  setEngineHeartbeat("Engine running","ok");
}


let v85FallbackTimer=null;
let v85LastTick=0;

function updateV85Clock(){
  const status=$("v85ClockStatus");
  if(status){
    status.textContent=`${fmt(current)} / ${fmt(duration)}`;
  }

  const center=$("v85CenterPlay");
  if(center){
    center.classList.toggle("hidden",!!playing);
  }
}

function v85PlaybackTick(){
  try{
    const now=performance.now();

    if(playing){
      if(!v85LastTick) v85LastTick=now;

      // Existing playbackAnchor values remain the source of truth.
      const selectedSpeed=Math.max(.1,+($("speed")?.value||1));
      current=
        playbackAnchorCurrent+
        ((now-playbackAnchorTime)/1000)*selectedSpeed;

      if(current>=duration){
        current=duration;
        pause();
      }else{
        try{synchronizeAllTimelineMedia?.(false)}catch(error){
          try{sync(false)}catch(ignore){}
        }

        try{drawPreviewFrame?.()}catch(error){
          try{render()}catch(ignore){}
        }

        try{renderPreviewOverlays?.()}catch(ignore){}
        try{updatePlayheadPosition()}catch(ignore){}

        const scrubber=$("scrubber");
        if(scrubber){
          scrubber.max=Math.max(.01,duration);
          scrubber.value=current;
        }
      }
    }

    updateV85Clock();
  }catch(error){
    console.error("v8.5 fallback playback tick failed",error);
  }
}

function startV85FallbackClock(){
  if(v85FallbackTimer) return;
  v85LastTick=performance.now();
  v85FallbackTimer=setInterval(v85PlaybackTick,33);
}

function v85Play(){
  duration=calcDuration();
  if(!layers.length){
    alert("請先把 Video 或 Audio Clip 放到 Timeline。");
    return;
  }

  if(current>=duration) current=0;
  playbackAnchorCurrent=current;
  playbackAnchorTime=performance.now();
  v85LastTick=playbackAnchorTime;
  playing=true;

  try{startPreviewPlayback(current)}catch(error){
    console.warn("Primary preview playback failed; fallback clock continues.",error);
    try{sync(true)}catch(ignore){}
  }

  updateV85Clock();
}

function v85Pause(){
  try{pause()}catch(error){
    playing=false;
    for(const asset of assets){
      try{asset.el?.pause?.()}catch(ignore){}
    }
  }
  updateV85Clock();
}

function v85Stop(){
  try{stop()}catch(error){
    playing=false;
    current=0;
    playbackAnchorCurrent=0;
    playbackAnchorTime=performance.now();
    try{sync(true)}catch(ignore){}
    try{render()}catch(ignore){}
    try{updatePlayheadPosition()}catch(ignore){}
  }
  updateV85Clock();
}

function v85Restart(){
  current=0;
  playbackAnchorCurrent=0;
  playbackAnchorTime=performance.now();
  v85Play();
}

function bindV85VisiblePlayback(){
  safeOn("v85Play","onclick",v85Play);
  safeOn("v85Pause","onclick",v85Pause);
  safeOn("v85Stop","onclick",v85Stop);
  safeOn("v85Restart","onclick",v85Restart);

  const center=$("v85CenterPlay");
  if(center){
    center.onclick=v85Play;
    center.onkeydown=event=>{
      if(event.key==="Enter"||event.key===" "){
        event.preventDefault();
        v85Play();
      }
    };
  }

  // Rebind the original transport controls as well.
  safeOn("play","onclick",v85Play);
  safeOn("pause","onclick",v85Pause);
  safeOn("stop","onclick",v85Stop);

  document.addEventListener("keydown",event=>{
    if(event.target && /INPUT|TEXTAREA|SELECT/.test(event.target.tagName)) return;
    if(event.code==="Space"){
      event.preventDefault();
      if(playing) v85Pause();
      else v85Play();
    }
  });

  startV85FallbackClock();
  updateV85Clock();
}


let v86PanelDragState=null;

function saveV86PanelState(){
  const panel=$("v85PreviewControls");
  if(!panel) return;

  try{
    localStorage.setItem("studioflow_v86_panel_state",JSON.stringify({
      left:panel.style.left,
      top:panel.style.top,
      right:panel.style.right,
      bottom:panel.style.bottom,
      collapsed:panel.classList.contains("collapsed")
    }));
  }catch(error){}
}

function restoreV86PanelState(){
  const panel=$("v85PreviewControls");
  if(!panel) return;

  try{
    const raw=localStorage.getItem("studioflow_v86_panel_state");
    if(!raw) return;

    const state=JSON.parse(raw);
    if(state.left) panel.style.left=state.left;
    if(state.top) panel.style.top=state.top;
    panel.style.right=state.right||"auto";
    panel.style.bottom=state.bottom||"auto";
    panel.classList.toggle("collapsed",!!state.collapsed);

    const button=$("v86CollapsePanel");
    if(button) button.textContent=state.collapsed?"+":"−";
  }catch(error){}
}

function clampV86PanelPosition(left,top){
  const preview=document.querySelector(".preview");
  const panel=$("v85PreviewControls");
  if(!preview||!panel) return {left,top};

  const previewRect=preview.getBoundingClientRect();
  const panelRect=panel.getBoundingClientRect();

  return {
    left:Math.max(0,Math.min(previewRect.width-panelRect.width,left)),
    top:Math.max(0,Math.min(previewRect.height-panelRect.height,top))
  };
}

function beginV86PanelDrag(event){
  if(event.button!==undefined&&event.button!==0) return;
  if(event.target.closest("button")) return;

  const panel=$("v85PreviewControls");
  const preview=document.querySelector(".preview");
  if(!panel||!preview) return;

  event.preventDefault();

  const panelRect=panel.getBoundingClientRect();
  const previewRect=preview.getBoundingClientRect();

  v86PanelDragState={
    offsetX:event.clientX-panelRect.left,
    offsetY:event.clientY-panelRect.top,
    previewLeft:previewRect.left,
    previewTop:previewRect.top
  };

  panel.classList.add("dragging");
  panel.style.right="auto";
  panel.style.bottom="auto";
}

function moveV86Panel(event){
  if(!v86PanelDragState) return;

  const panel=$("v85PreviewControls");
  if(!panel) return;

  event.preventDefault();

  const rawLeft=event.clientX-v86PanelDragState.previewLeft-v86PanelDragState.offsetX;
  const rawTop=event.clientY-v86PanelDragState.previewTop-v86PanelDragState.offsetY;
  const position=clampV86PanelPosition(rawLeft,rawTop);

  panel.style.left=`${position.left}px`;
  panel.style.top=`${position.top}px`;
}

function endV86PanelDrag(){
  if(!v86PanelDragState) return;

  const panel=$("v85PreviewControls");
  v86PanelDragState=null;

  if(panel) panel.classList.remove("dragging");
  saveV86PanelState();
}

function toggleV86Panel(){
  const panel=$("v85PreviewControls");
  const button=$("v86CollapsePanel");
  if(!panel) return;

  panel.classList.toggle("collapsed");
  if(button){
    button.textContent=panel.classList.contains("collapsed")?"+":"−";
  }

  // Re-clamp after changing dimensions.
  const left=parseFloat(panel.style.left)||20;
  const top=parseFloat(panel.style.top)||20;
  const position=clampV86PanelPosition(left,top);
  panel.style.left=`${position.left}px`;
  panel.style.top=`${position.top}px`;

  saveV86PanelState();
}

function bindV86MovablePanel(){
  const panel=$("v85PreviewControls");
  const handle=$("v86PanelHandle");
  const collapse=$("v86CollapsePanel");

  if(!panel||!handle) return;

  restoreV86PanelState();

  handle.addEventListener("pointerdown",beginV86PanelDrag);
  window.addEventListener("pointermove",moveV86Panel);
  window.addEventListener("pointerup",endV86PanelDrag);
  window.addEventListener("pointercancel",endV86PanelDrag);

  if(collapse){
    collapse.onclick=event=>{
      event.stopPropagation();
      toggleV86Panel();
    };
  }

  window.addEventListener("resize",()=>{
    const left=parseFloat(panel.style.left)||20;
    const top=parseFloat(panel.style.top)||20;
    const position=clampV86PanelPosition(left,top);
    panel.style.left=`${position.left}px`;
    panel.style.top=`${position.top}px`;
  });
}


let v87TransportDrag=null;
let v87TransportResize=null;

function getV87Transport(){
  return document.querySelector(".transport");
}

function saveV87TransportState(){
  const bar=getV87Transport();
  if(!bar) return;

  try{
    localStorage.setItem("studioflow_v87_transport_state",JSON.stringify({
      mode:
        bar.classList.contains("v87-docked-top") ? "top" :
        bar.classList.contains("v87-docked-bottom") ? "bottom" :
        bar.classList.contains("v87-floating") ? "float" : "normal",
      left:bar.style.left,
      top:bar.style.top,
      width:bar.style.width,
      transform:bar.style.transform,
      collapsed:bar.classList.contains("v87-collapsed")
    }));
  }catch(error){}
}

function clearV87Modes(bar){
  bar.classList.remove(
    "v87-floating",
    "v87-docked-top",
    "v87-docked-bottom"
  );
}

function applyV87Mode(mode){
  const bar=getV87Transport();
  if(!bar) return;

  clearV87Modes(bar);

  if(mode==="float"){
    bar.classList.add("v87-floating");
    if(!bar.style.left) bar.style.left="50%";
    if(!bar.style.top) bar.style.top="180px";
    if(!bar.style.width) bar.style.width="min(900px, calc(100vw - 40px))";
  }else if(mode==="top"){
    bar.classList.add("v87-docked-top");
    bar.style.left="0";
    bar.style.top="0";
    bar.style.width="100vw";
    bar.style.transform="none";
  }else if(mode==="bottom"){
    bar.classList.add("v87-docked-bottom");
    bar.style.left="0";
    bar.style.top="auto";
    bar.style.width="100vw";
    bar.style.transform="none";
  }

  saveV87TransportState();
}

function restoreV87TransportState(){
  const bar=getV87Transport();
  if(!bar) return;

  try{
    const raw=localStorage.getItem("studioflow_v87_transport_state");
    if(!raw) return;

    const state=JSON.parse(raw);
    applyV87Mode(state.mode||"normal");

    if(state.mode==="float"){
      if(state.left) bar.style.left=state.left;
      if(state.top) bar.style.top=state.top;
      if(state.width) bar.style.width=state.width;
      bar.style.transform=state.transform||"none";
    }

    bar.classList.toggle("v87-collapsed",!!state.collapsed);
    const collapse=$("v87CollapseTransport");
    if(collapse) collapse.textContent=state.collapsed?"+":"−";
  }catch(error){}
}

function clampV87FloatingPosition(left,top){
  const bar=getV87Transport();
  if(!bar) return {left,top};

  const rect=bar.getBoundingClientRect();
  return {
    left:Math.max(0,Math.min(window.innerWidth-rect.width,left)),
    top:Math.max(0,Math.min(window.innerHeight-rect.height,top))
  };
}

function beginV87TransportDrag(event){
  if(event.button!==undefined&&event.button!==0) return;
  if(event.target.closest("button")) return;

  const bar=getV87Transport();
  if(!bar) return;

  if(!bar.classList.contains("v87-floating")){
    applyV87Mode("float");
    const rect=bar.getBoundingClientRect();
    bar.style.left=`${rect.left}px`;
    bar.style.top=`${rect.top}px`;
    bar.style.transform="none";
  }

  event.preventDefault();

  const rect=bar.getBoundingClientRect();
  v87TransportDrag={
    offsetX:event.clientX-rect.left,
    offsetY:event.clientY-rect.top
  };

  bar.classList.add("v87-dragging");
}

function moveV87Transport(event){
  if(!v87TransportDrag) return;

  const bar=getV87Transport();
  if(!bar) return;

  event.preventDefault();

  const rawLeft=event.clientX-v87TransportDrag.offsetX;
  const rawTop=event.clientY-v87TransportDrag.offsetY;
  const position=clampV87FloatingPosition(rawLeft,rawTop);

  bar.style.left=`${position.left}px`;
  bar.style.top=`${position.top}px`;
  bar.style.transform="none";
}

function endV87TransportDrag(){
  if(!v87TransportDrag) return;

  const bar=getV87Transport();
  v87TransportDrag=null;

  if(bar) bar.classList.remove("v87-dragging");
  saveV87TransportState();
}

function beginV87Resize(event,side){
  if(event.button!==undefined&&event.button!==0) return;

  const bar=getV87Transport();
  if(!bar) return;

  if(!bar.classList.contains("v87-floating")){
    applyV87Mode("float");
    const rect=bar.getBoundingClientRect();
    bar.style.left=`${rect.left}px`;
    bar.style.top=`${rect.top}px`;
    bar.style.width=`${rect.width}px`;
    bar.style.transform="none";
  }

  event.preventDefault();
  event.stopPropagation();

  const rect=bar.getBoundingClientRect();
  v87TransportResize={
    side,
    startX:event.clientX,
    startLeft:rect.left,
    startWidth:rect.width
  };

  bar.classList.add("v87-resizing");
}

function moveV87Resize(event){
  if(!v87TransportResize) return;

  const bar=getV87Transport();
  if(!bar) return;

  event.preventDefault();

  let width=v87TransportResize.startWidth;
  let left=v87TransportResize.startLeft;
  const delta=event.clientX-v87TransportResize.startX;

  if(v87TransportResize.side==="right"){
    width=v87TransportResize.startWidth+delta;
  }else{
    width=v87TransportResize.startWidth-delta;
    left=v87TransportResize.startLeft+delta;
  }

  width=Math.max(320,Math.min(window.innerWidth-20,width));
  left=Math.max(0,Math.min(window.innerWidth-width,left));

  bar.style.width=`${width}px`;
  bar.style.left=`${left}px`;
  bar.style.transform="none";
}

function endV87Resize(){
  if(!v87TransportResize) return;

  const bar=getV87Transport();
  v87TransportResize=null;

  if(bar) bar.classList.remove("v87-resizing");
  saveV87TransportState();
}

function toggleV87TransportCollapse(){
  const bar=getV87Transport();
  const button=$("v87CollapseTransport");
  if(!bar) return;

  bar.classList.toggle("v87-collapsed");
  if(button){
    button.textContent=bar.classList.contains("v87-collapsed")?"+":"−";
  }

  saveV87TransportState();
}

function bindV87TransportBar(){
  const bar=getV87Transport();
  const handle=$("v87TransportHandle");
  if(!bar||!handle) return;

  restoreV87TransportState();

  handle.addEventListener("pointerdown",beginV87TransportDrag);
  window.addEventListener("pointermove",event=>{
    moveV87Transport(event);
    moveV87Resize(event);
  });
  window.addEventListener("pointerup",()=>{
    endV87TransportDrag();
    endV87Resize();
  });
  window.addEventListener("pointercancel",()=>{
    endV87TransportDrag();
    endV87Resize();
  });

  const left=$("v87ResizeLeft");
  const right=$("v87ResizeRight");

  if(left){
    left.addEventListener("pointerdown",event=>beginV87Resize(event,"left"));
  }
  if(right){
    right.addEventListener("pointerdown",event=>beginV87Resize(event,"right"));
  }

  if($("v87DockTop")) $("v87DockTop").onclick=event=>{
    event.stopPropagation();
    applyV87Mode("top");
  };
  if($("v87DockBottom")) $("v87DockBottom").onclick=event=>{
    event.stopPropagation();
    applyV87Mode("bottom");
  };
  if($("v87FloatTransport")) $("v87FloatTransport").onclick=event=>{
    event.stopPropagation();
    applyV87Mode("float");
  };
  if($("v87CollapseTransport")) $("v87CollapseTransport").onclick=event=>{
    event.stopPropagation();
    toggleV87TransportCollapse();
  };

  window.addEventListener("resize",()=>{
    if(!bar.classList.contains("v87-floating")) return;
    const rect=bar.getBoundingClientRect();
    const position=clampV87FloatingPosition(rect.left,rect.top);
    bar.style.left=`${position.left}px`;
    bar.style.top=`${position.top}px`;
  });
}

function bind(){
  safeInitStep('v8.7 transport bar',bindV87TransportBar);

  safeInitStep('v8.6 movable panel',bindV86MovablePanel);

  safeInitStep('v8.5 visible playback',bindV85VisiblePlayback);

  setEngineHeartbeat("Initializing…");

  safeInitStep("double-click preview",bindDoubleClickSourcePreview);
  safeInitStep("overlay dragging",bindOverlayDragging);
  safeInitStep("draggable playhead",bindDraggablePlayhead);
  safeInitStep("v8 layout",bindV80Layout);
  safeInitStep("playback extras",bindPlaybackExtras);
  safeInitStep("reference layout",bindReferenceLayoutControls);
  safeInitStep("preview size",bindPreviewSizeControls);
  safeInitStep("audio controls",bindAudioTrackControls);
  safeInitStep("track sync",bindTrackVerticalSync);
  safeInitStep("stable navigation",stableBindTimelineNavigation);
  safeInitStep("delete controls",bindIndividualDeleteControls);
  safeInitStep("dynamic tracks",bindDynamicTrackButtons);

  safeInitStep("ensure playhead",ensurePlayhead);

  safeOn("fileInput","onchange",event=>importFiles(event.target.files));

  const dropZone=$("dropZone");
  if(dropZone){
    dropZone.onclick=()=>$("fileInput")?.click();
    dropZone.ondragover=event=>{
      event.preventDefault();
      dropZone.style.borderColor="#8b5cf6";
    };
    dropZone.ondragleave=()=>dropZone.style.borderColor="#34506e";
    dropZone.ondrop=event=>{
      event.preventDefault();
      dropZone.style.borderColor="#34506e";
      importFiles(event.dataTransfer.files);
    };
  }

  document.querySelectorAll(".tabs button").forEach(button=>{
    button.onclick=()=>{
      document.querySelectorAll(".tabs button")
        .forEach(item=>item.classList.remove("active"));
      button.classList.add("active");
      filter=button.dataset.filter;
      renderMedia();
    };
  });

  safeOn("mediaSearch","oninput",renderMedia);
  safeOn("restoreBin","onclick",restoreBin);
  safeOn("clearBin","onclick",async()=>{
    await clearDB();
    assets=[];
    layers=[];
    selected=null;
    localStorage.removeItem("studioflow_notext_manifest");
    renderAll();
  });

  safeOn("play","onclick",()=>startPreviewPlayback(current));
  safeOn("pause","onclick",pause);
  safeOn("stop","onclick",stop);
  safeOn("back","onclick",()=>seek(current-5));
  safeOn("forward","onclick",()=>seek(current+5));
  safeOn("speed","onchange",event=>{
    speed=+event.target.value||1;
    playbackAnchorCurrent=current;
    playbackAnchorTime=performance.now();
    sync(true);
  });
  safeOn("volume","oninput",()=>sync(true));
  safeOn("scrubber","oninput",event=>seek(+event.target.value));

  safeOn("split","onclick",split);
  safeOn("trimIn","onclick",trimIn);
  safeOn("trimOut","onclick",trimOut);
  safeOn("duplicate","onclick",duplicate);
  safeOn("deleteSelected","onclick",()=>{
    if(!selected) return;
    pushUndo();
    layers=layers.filter(layer=>layer.id!==selected);
    selected=null;
    duration=calcDuration();
    saveManifest();
    renderAll();
  });
  safeOn("bringFront","onclick",()=>{
    const layer=layers.find(item=>item.id===selected);
    if(layer){
      layer.z=999;
      renderAll();
    }
  });
  safeOn("sendBack","onclick",()=>{
    const layer=layers.find(item=>item.id===selected);
    if(layer){
      layer.z=0;
      renderAll();
    }
  });
  safeOn("zoomFit","onclick",renderAll);

  safeOn("separateAudio","onclick",separateAudio);
  safeOn("separateAudioQuick","onclick",separateAudio);
  safeOn("splitLinkedAV","onclick",splitLinkedAVCore);
  safeOn("splitLinkedAVSide","onclick",splitLinkedAVCore);
  safeOn("unlinkAV","onclick",unlinkSelectedAVCore);
  safeOn("unlinkAVSide","onclick",unlinkSelectedAVCore);

  safeOn("saveProject","onclick",saveProject);
  safeOn("exportWebM","onclick",exportWebM);
  safeOn("exportMP4","onclick",exportMP4);
  safeOn("exportMP3","onclick",exportMP3);
  safeOn("sideExportWebM","onclick",exportWebM);
  safeOn("sideExportMP4","onclick",exportMP4);
  safeOn("sideExportMP3","onclick",exportMP3);

  [
    "xInput","yInput","scaleInput","startInput","durationInput",
    "clipVolume","chromaOn","chromaColor","chromaTolerance"
  ].forEach(id=>{
    const element=$(id);
    if(element) element.oninput=applyInspector;
  });

  ["mixA1","mixA2","mixA3"].forEach((id,index)=>{
    const element=$(id);
    if(!element) return;
    element.oninput=()=>{
      [5,6,7,8,9].forEach((row,rowIndex)=>{
        if(rowIndex===index){
          for(const layer of layers.filter(item=>item.kind==="audio"&&item.row===row)){
            layer.volume=+element.value;
          }
        }
      });
      sync(true);
    };
  });

  safeInitStep("initial render",renderAll);
  startStudioFlowLoopOnce();

  // Restore saved project/media without being allowed to stop the playback loop.
  Promise.resolve()
    .then(()=>restoreManifest?.())
    .catch(error=>console.warn("Manifest restore failed",error))
    .finally(()=>{
      setEngineHeartbeat("Engine running","ok");
    });
}
document.addEventListener("keydown", e => {
  if(e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
  if(e.key === "Delete"){
    e.preventDefault();
    deleteSelectedClipOnly();
    return;
  }
  if(e.key.toLowerCase() === "s" && !e.ctrlKey){
    e.preventDefault();
    splitLinkedAVCore();
  }
});
if(document.readyState==="loading"){
  document.addEventListener("DOMContentLoaded",bind,{once:true});
}else{
  bind();
}

document.addEventListener("DOMContentLoaded",()=>{
  const area = $("timeArea");
  if(area){
    area.addEventListener("click",e=>{
      if(e.target.closest(".clip")) return;
      const rect = area.getBoundingClientRect();
      current = Math.max(0,Math.min(duration,(e.clientX - rect.left + area.scrollLeft)/pxPerSecond()));
      sync(true);
      updatePlayheadPosition();
      renderAll();
    });
  }
});


window.addEventListener("error",event=>{
  console.error("StudioFlow runtime error:",event.error||event.message);
  const status=document.getElementById("durStatus");
  if(status) status.textContent="Runtime error: "+event.message;
});


window.addEventListener("error",event=>{
  console.error("StudioFlow runtime error:",event.error||event.message);
  setPlaybackCoreStatus("Runtime recovered","error");
});
window.addEventListener("unhandledrejection",event=>{
  console.error("StudioFlow rejected promise:",event.reason);
  setPlaybackCoreStatus("Media promise recovered","error");
});

})();




/* v7.6 MoviePy local backend integration */
(function(){
  const API = "";
  const $ = id => document.getElementById(id);

  async function apiFetch(url, options={}){
    const response = await fetch(API + url, options);
    const data = await response.json().catch(()=>({}));
    if(!response.ok) throw new Error(data.error || data.message || `HTTP ${response.status}`);
    return data;
  }

  function setBackendStatus(text, ok=false){
    const el = $("backendStatus");
    if(!el) return;
    el.textContent = text;
    el.classList.toggle("ready", ok);
    el.classList.toggle("warn", !ok);
  }

  function setJobStatus(text, ok=false){
    const el = $("moviepyJobStatus");
    if(!el) return;
    el.textContent = text;
    el.classList.toggle("ready", ok);
    el.classList.toggle("warn", !ok);
  }

  async function checkBackend(){
    try{
      const data = await apiFetch("/api/health");
      setBackendStatus(`Backend ready · MoviePy ${data.moviepy} · FFmpeg ${data.ffmpeg}`, true);
      await refreshMedia();
    }catch(e){
      setBackendStatus("Backend unavailable. Run install_and_start.bat", false);
    }
  }

  async function uploadMedia(){
    const input = $("backendUploadInput");
    const files = Array.from(input?.files || []);
    if(!files.length){
      alert("請選擇影片、音訊、JPG、TIF/TIFF 或 GIF。");
      return;
    }

    const form = new FormData();
    files.forEach(file => form.append("files", file, file.name));
    setJobStatus(`Uploading ${files.length} file(s)...`);

    try{
      const data = await apiFetch("/api/media/upload", {method:"POST", body:form});
      setJobStatus(`Stored ${data.files.length} file(s) in Uploads and Copies.`, true);
      input.value = "";
      await refreshMedia();
    }catch(e){
      setJobStatus("Upload failed: " + e.message, false);
    }
  }

  async function refreshMedia(){
    try{
      const data = await apiFetch("/api/media");
      const box = $("storedMediaList");
      if(!box) return;
      box.innerHTML = "";
      for(const item of data.files){
        const row = document.createElement("div");
        row.className = "stored-media-item";
        const info = document.createElement("span");
        info.textContent = `${item.name} · ${item.kind} · ${item.size_text}`;
        const use = document.createElement("button");
        use.textContent = "Use";
        use.onclick = () => {
          const target = item.kind === "video" ? $("mpClip1") :
                         item.kind === "audio" ? $("ffCutSource") : $("gifSource");
          if(target) target.value = item.name;
        };
        row.append(info,use);
        box.appendChild(row);
      }
    }catch(e){}
  }

  function moviePyPayload(){
    return {
      clip1: $("mpClip1")?.value.trim(),
      clip2: $("mpClip2")?.value.trim(),
      clip1_start: Number($("mpClip1Start")?.value || 0),
      clip1_end: Number($("mpClip1End")?.value || 3),
      clip2_start: Number($("mpClip2Start")?.value || 5),
      clip2_end: Number($("mpClip2End")?.value || 10),
      black_and_white_clip2: !!$("mpBlackWhite")?.checked,
      output_name: $("mpOutputName")?.value.trim() || "output",
      overlay_text: $("mpOverlayText")?.value || "",
      text_start: Number($("mpTextStart")?.value || 0),
      text_duration: Number($("mpTextDuration")?.value || 3),
      text_size: Number($("mpTextSize")?.value || 48),
      text_position: $("mpTextPosition")?.value || "bottom",
      transition: $("mpTransition")?.value || "none",
      transition_duration: Number($("mpTransitionDuration")?.value || 0.8),
      encoder_preset: $("mpEncoderPreset")?.value || "veryfast",
      output_fps: Number($("mpOutputFps")?.value || 24),
      audio_clips: [1,2,3].map(i => ({
        filename: $(`mpAudio${i}`)?.value.trim() || "",
        start: Number($(`mpAudio${i}Start`)?.value || 0),
        volume: Number($(`mpAudio${i}Volume`)?.value || 1)
      })).filter(item => item.filename)
    };
  }

  async function compose(format){
    const payload = moviePyPayload();
    payload.format = format;
    setJobStatus(`MoviePy is composing ${format.toUpperCase()}...`);
    try{
      const data = await apiFetch("/api/moviepy/compose", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(payload)
      });
      setJobStatus(`Completed: ${data.output}`, true);
      await refreshMedia();
      window.open(data.download_url, "_blank");
    }catch(e){
      setJobStatus("Compose failed: " + e.message, false);
    }
  }

  async function fastCut(){
    const payload = {
      source: $("ffCutSource")?.value.trim(),
      start: $("ffCutStart")?.value.trim(),
      end: $("ffCutEnd")?.value.trim(),
      output: $("ffCutOutput")?.value.trim() || "cut1.mp4"
    };
    setJobStatus("FFmpeg stream-copy cut running...");
    try{
      const data = await apiFetch("/api/ffmpeg/fast-cut", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(payload)
      });
      setJobStatus(`Completed: ${data.output}`, true);
      window.open(data.download_url, "_blank");
    }catch(e){
      setJobStatus("Fast cut failed: " + e.message, false);
    }
  }

  async function paletteGif(){
    const payload = {
      source: $("gifSource")?.value.trim(),
      width: Number($("gifWidth")?.value || 480),
      fps: Number($("gifFps")?.value || 10),
      output: $("gifOutput")?.value.trim() || "output_high_q.gif"
    };
    setJobStatus("Generating palette and high-quality GIF...");
    try{
      const data = await apiFetch("/api/ffmpeg/high-quality-gif", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(payload)
      });
      setJobStatus(`Completed: ${data.output}`, true);
      window.open(data.download_url, "_blank");
    }catch(e){
      setJobStatus("GIF export failed: " + e.message, false);
    }
  }


  async function advancedCompose(format){
    const payload = moviePyPayload();
    payload.format = format;
    setJobStatus(`MoviePy rendering and FFmpeg encoding ${format.toUpperCase()}...`);
    try{
      const data = await apiFetch("/api/moviepy/advanced-compose", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(payload)
      });
      setJobStatus(`Completed: ${data.output} · ${data.encoder}`, true);
      await refreshMedia();
      window.open(data.download_url, "_blank");
    }catch(e){
      setJobStatus("Advanced export failed: " + e.message, false);
    }
  }

  function bind(){
    $("backendUploadBtn")?.addEventListener("click", uploadMedia);
    $("refreshStoredMedia")?.addEventListener("click", refreshMedia);
    $("moviepyComposeMp4")?.addEventListener("click", ()=>compose("mp4"));
    $("moviepyComposeGif")?.addEventListener("click", ()=>compose("gif"));
    $("advancedComposeMp4")?.addEventListener("click", ()=>advancedCompose("mp4"));
    $("advancedComposeGif")?.addEventListener("click", ()=>advancedCompose("gif"));
    $("fastCutBtn")?.addEventListener("click", fastCut);
    $("highQualityGifBtn")?.addEventListener("click", paletteGif);
    checkBackend();
  }

  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind);
  else bind();
})();
