# StudioFlow v7 Direct Player Fix

This build is designed to verify playback first.

## What changed

- Uses native `<video>` and `<audio>` controls plus Canvas rendering.
- Imported media opens immediately.
- Video is drawn to the black Canvas every animation frame.
- Audio uses real browser audio controls and can be unlocked with `🔊 啟用聲音`.
- Shows file type, size and decode errors.
- Supports direct position and scale editing.

## Use order

1. Open `index.html` in Chrome or Edge.
2. Click `選擇影片/音訊/圖片`.
3. Choose MP4 H.264 / WebM / MP3 / WAV / image.
4. Click `🔊 啟用聲音`.
5. Click `播放`.

## Important

If an `.mp4` file still says it cannot decode, the MP4 probably contains unsupported codec such as HEVC, AV1, ProRes, etc.

Use MP4 H.264 + AAC or WebM for browser playback.
