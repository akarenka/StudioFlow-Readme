const $ = id => document.getElementById(id);
const canvas = $("canvas");
const ctx = canvas.getContext("2d");
const video = $("nativeVideo");
const audio = $("nativeAudio");

let media = [];
let active = null;
let type = null;
let img = null;
let scale = 1;
let pos = {x: 640, y: 360};

function fmt(t){
  t = Math.max(0, t || 0);
  const m = Math.floor(t/60), s = Math.floor(t%60), h = Math.floor((t%1)*100);
  return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(h).padStart(2,"0")}`;
}
function msg(t){ $("msg").textContent = t; }
function debug(t){ $("debug").textContent = t; }

function kindOf(file){
  const ext = file.name.split(".").pop().toLowerCase();
  if(file.type.startsWith("video/") || ["mp4","webm","mov","avi","mkv","m4v","ogv"].includes(ext)) return "video";
  if(file.type.startsWith("audio/") || ["mp3","wav","m4a","aac","ogg","flac"].includes(ext)) return "audio";
  return "image";
}

async function loadFiles(files){
  for(const file of [...files]){
    const url = URL.createObjectURL(file);
    const kind = kindOf(file);
    media.push({file, url, kind});
  }
  renderList();
  if(media.length) await openMedia(media[media.length-1]);
}

function openMedia(item){
  return new Promise((resolve) => {
    active = item;
    type = item.kind;
    img = null;
    video.pause();
    audio.pause();
    video.removeAttribute("src");
    audio.removeAttribute("src");
    video.style.display = "none";
    audio.style.display = "none";

    debug(`File: ${item.file.name}\nType: ${item.file.type || "(empty MIME)"}\nKind: ${item.kind}\nSize: ${(item.file.size/1024/1024).toFixed(2)} MB`);

    if(item.kind === "video"){
      video.style.display = "block";
      video.src = item.url;
      video.muted = false;
      video.volume = Number($("volume").value);
      video.playbackRate = Number($("speed").value);
      video.onloadedmetadata = () => {
        fitToCanvas(video.videoWidth || 1280, video.videoHeight || 720);
        msg("Video loaded. Press 🔊 啟用聲音 then ▶ 播放.");
        resolve();
      };
      video.onerror = () => {
        msg("影片無法解碼");
        alert(`${item.file.name}\n此影片編碼瀏覽器無法解碼。\n請用 MP4 H.264 + AAC 或 WebM，或用 FFmpeg 轉檔。`);
        resolve();
      };
      video.load();
    } else if(item.kind === "audio"){
      audio.style.display = "block";
      audio.src = item.url;
      audio.volume = Number($("volume").value);
      audio.playbackRate = Number($("speed").value);
      audio.onloadedmetadata = () => {
        msg("Audio loaded. Press 🔊 啟用聲音 then ▶ 播放.");
        resolve();
      };
      audio.onerror = () => {
        msg("音訊無法解碼");
        alert(`${item.file.name}\n此音訊編碼瀏覽器無法解碼。請用 WAV/MP3/AAC。`);
        resolve();
      };
      audio.load();
    } else {
      img = new Image();
      img.onload = () => {
        fitToCanvas(img.naturalWidth || 1280, img.naturalHeight || 720);
        msg("Image loaded.");
        resolve();
      };
      img.onerror = () => { msg("圖片無法載入"); resolve(); };
      img.src = item.url;
    }
  });
}

function fitToCanvas(w,h){
  scale = Math.min(canvas.width/w, canvas.height/h) * 0.9;
  pos = {x: canvas.width/2, y: canvas.height/2};
  $("scale").value = scale;
  $("x").value = pos.x;
  $("y").value = pos.y;
}

async function unlock(){
  try{
    if(type === "video"){
      await video.play();
      video.pause();
    }else if(type === "audio"){
      await audio.play();
      audio.pause();
    }
    msg("Sound unlocked. Press Play.");
  }catch(e){
    msg("請再按一次播放或檢查瀏覽器音量");
  }
}

function play(){
  if(type === "video") video.play().catch(()=>msg("Browser blocked playback. Press 🔊 啟用聲音."));
  if(type === "audio") audio.play().catch(()=>msg("Browser blocked audio. Press 🔊 啟用聲音."));
}
function pause(){
  video.pause(); audio.pause();
}
function stop(){
  pause();
  if(type === "video") video.currentTime = 0;
  if(type === "audio") audio.currentTime = 0;
}
function seek(delta){
  if(type === "video") video.currentTime = Math.max(0, Math.min(video.duration || 0, video.currentTime + delta));
  if(type === "audio") audio.currentTime = Math.max(0, Math.min(audio.duration || 0, audio.currentTime + delta));
}
function setVolume(v){ video.volume = v; audio.volume = v; }
function setSpeed(v){ video.playbackRate = v; audio.playbackRate = v; }

function renderList(){
  $("list").innerHTML = "";
  media.forEach((m,i)=>{
    const d = document.createElement("div");
    d.className = "card";
    d.innerHTML = `<strong>${m.file.name}</strong><small>${m.kind}</small><br><button>Open</button>`;
    d.querySelector("button").onclick = () => openMedia(m);
    $("list").appendChild(d);
  });
}

function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = "#000";
  ctx.fillRect(0,0,canvas.width,canvas.height);

  if(!active){
    ctx.fillStyle = "#8fa0be";
    ctx.font = "34px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("Choose video / audio / image", canvas.width/2, canvas.height/2);
  } else if(type === "video" && video.readyState >= 2){
    const w = (video.videoWidth || 1280) * scale;
    const h = (video.videoHeight || 720) * scale;
    try{ ctx.drawImage(video, pos.x-w/2, pos.y-h/2, w, h); }catch(e){}
  } else if(type === "image" && img){
    const w = (img.naturalWidth || 1280) * scale;
    const h = (img.naturalHeight || 720) * scale;
    ctx.drawImage(img, pos.x-w/2, pos.y-h/2, w, h);
  } else if(type === "audio"){
    ctx.fillStyle = "#38bdf8";
    ctx.font = "34px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("♪ " + active.file.name, canvas.width/2, canvas.height/2);
    const t = audio.currentTime || 0;
    const d = audio.duration || 1;
    ctx.fillStyle = "#2563eb";
    ctx.fillRect(240, 430, 800*(t/d), 24);
    ctx.strokeStyle = "#93c5fd";
    ctx.strokeRect(240, 430, 800, 24);
  }

  const cur = type === "video" ? video.currentTime : type === "audio" ? audio.currentTime : 0;
  const dur = type === "video" ? video.duration : type === "audio" ? audio.duration : 0;
  $("time").textContent = `${fmt(cur)} / ${fmt(dur)}`;
  requestAnimationFrame(draw);
}

$("fileInput").onchange = e => loadFiles(e.target.files);
$("unlock").onclick = unlock;
$("play").onclick = play;
$("pause").onclick = pause;
$("stop").onclick = stop;
$("back").onclick = () => seek(-5);
$("fwd").onclick = () => seek(5);
$("volume").oninput = e => setVolume(Number(e.target.value));
$("speed").onchange = e => setSpeed(Number(e.target.value));
$("scale").oninput = e => { scale = Number(e.target.value); };
$("x").oninput = e => { pos.x = Number(e.target.value); };
$("y").oninput = e => { pos.y = Number(e.target.value); };
$("fit").onclick = () => {
  if(type === "video") fitToCanvas(video.videoWidth || 1280, video.videoHeight || 720);
  if(type === "image" && img) fitToCanvas(img.naturalWidth || 1280, img.naturalHeight || 720);
};
$("separate").onclick = () => alert("示範版：目前影片聲音已由原生 video 播放。完整分離音軌需要 Web Audio / FFmpeg 模組。");
$("clear").onclick = () => { media=[]; active=null; type=null; video.pause(); audio.pause(); renderList(); msg("Cleared"); };

const drop = $("drop");
drop.ondragover = e => { e.preventDefault(); drop.classList.add("drag"); };
drop.ondragleave = () => drop.classList.remove("drag");
drop.ondrop = e => { e.preventDefault(); drop.classList.remove("drag"); loadFiles(e.dataTransfer.files); };

canvas.onmousedown = e => {
  if(!(type === "video" || type === "image")) return;
  const r = canvas.getBoundingClientRect();
  const sx = (e.clientX-r.left)*(canvas.width/r.width);
  const sy = (e.clientY-r.top)*(canvas.height/r.height);
  const ox = pos.x, oy = pos.y;
  const move = ev => {
    const nx = (ev.clientX-r.left)*(canvas.width/r.width);
    const ny = (ev.clientY-r.top)*(canvas.height/r.height);
    pos.x = ox + nx - sx;
    pos.y = oy + ny - sy;
    $("x").value = Math.round(pos.x);
    $("y").value = Math.round(pos.y);
  };
  const up = () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); };
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
};

draw();
