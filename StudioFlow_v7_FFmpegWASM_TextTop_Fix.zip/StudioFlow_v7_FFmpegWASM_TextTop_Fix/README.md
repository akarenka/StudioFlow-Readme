# StudioFlow v7 FFmpegWASM TextTop Fix

此版本保留目前所有功能與 FFmpeg 匯出，只修正文字顯示問題。

## 修正內容

- 新輸入文字按「Add Text」後會立即顯示
- Text Clip 會加入 Text 軌
- Text 永遠最後繪製，固定在最上層
- 圖層順序固定為：
  1. Video
  2. Image
  3. Effects
  4. Text
- Text 可在 Canvas 上拖曳
- Text 支援 Scroll / Fade / Bounce
- 保留 FFmpeg 匯出

## 保留功能

- Preview Canvas
- Timeline
- Inspector
- Video × 5
- Audio × 3
- Text × 3
- Clip Move / Resize
- Snap / Ripple Move
- Trim / Split
- Drag & Drop
- Save / Open Project
- FFmpeg Export WebM / MP4 / MP3 / WAV / GIF

## 使用

執行：

```text
start_server.bat
```

開啟：

```text
http://localhost:8000
```
