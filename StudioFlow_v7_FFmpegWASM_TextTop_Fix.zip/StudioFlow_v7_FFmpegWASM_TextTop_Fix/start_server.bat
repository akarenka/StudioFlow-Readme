@echo off
title StudioFlow v7 FFmpegWASM Ultimate Edition FIXED
echo Open http://localhost:8000
python -m http.server 8000
pause
