(() => {
"use strict";
const $=id=>document.getElementById(id), canvas=$("canvas"), ctx=canvas.getContext("2d");
let assets=[],layers=[],selected=null,current=0,duration=0,playing=false,speed=1;
const tracks={video:["Video 1","Video 2","Video 3","Video 4","Video 5"],audio:["Audio 1","Audio 2","Audio 3"],text:["Text 1","Text 2","Text 3"]};
function pub(){window.assets=assets;window.layers=layers;window.selected=selected;window.current=current;window.duration=duration;window.playing=playing}
function uid(){return"sf_"+Math.random().toString(36).slice(2)+Date.now().toString(36)}
function log(m){$("log").textContent=m;console.log("[StudioFlow]",m)}
function fmt(t){t=Math.max(0,t||0);return`${String(Math.floor(t/60)).padStart(2,"0")}:${String(Math.floor(t%60)).padStart(2,"0")}.${String(Math.floor((t%1)*100)).padStart(2,"0")}`}
function snap(t){return $("snapToggle").checked?Math.round(t*10)/10:t}
function sel(){return layers.find(l=>l.id===selected)||null}
function asset(l){return assets.find(a=>a.id===l.assetId)||null}
function kindOf(f){let e=f.name.split(".").pop().toLowerCase();if(["txt","srt","vtt"].includes(e))return"textfile";if(f.type.startsWith("video/")||["mp4","webm","mov","mkv"].includes(e))return"video";if(f.type.startsWith("audio/")||["mp3","wav","m4a","aac","ogg"].includes(e))return"audio";return"image"}
function updateDuration(){duration=Math.max(0,...layers.map(l=>(+l.start||0)+(+l.duration||0)));$("scrubber").max=duration;pub()}
async function importFiles(files){for(const file of Array.from(files||[])){let kind=kindOf(file),url=URL.createObjectURL(file);try{if(kind==="textfile"){let text=(await file.text()).replace(/\r/g,"").split("\n").filter(Boolean).slice(0,20).join("  ");addTextLayer(text||file.name,file.name);continue}let a={id:uid(),name:file.name,kind,url,duration:5,w:640,h:360,el:null};if(kind==="video"){let v=document.createElement("video");v.src=url;v.preload="auto";v.playsInline=true;v.volume=+$("volume").value;a.el=v;await new Promise((res,rej)=>{v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:5;a.w=v.videoWidth||640;a.h=v.videoHeight||360;res()};v.onerror=()=>rej(Error("瀏覽器無法解碼此影片"));v.load()})}else if(kind==="audio"){let au=document.createElement("audio");au.src=url;au.preload="auto";au.volume=+$("volume").value;a.el=au;await new Promise((res,rej)=>{au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:5;res()};au.onerror=()=>rej(Error("瀏覽器無法解碼音訊"));au.load()})}else{let img=new Image();img.src=url;a.el=img;await new Promise(res=>{img.onload=()=>{a.w=img.naturalWidth||640;a.h=img.naturalHeight||360;res()};img.onerror=res})}assets.push(a);addLayerFromAsset(a);log("Imported: "+file.name)}catch(e){alert(file.name+"\n"+e.message)}}renderAll()}
function addLayerFromAsset(a){let scale=a.kind==="audio"?1:Math.min(canvas.width/a.w,canvas.height/a.h)*.85;layers.push({id:uid(),assetId:a.id,name:a.name,kind:a.kind,start:0,duration:a.duration,trim:0,x:640,y:360,scale,volume:1,muted:false,trackIndex:0,linkedGroup:null,effect:"none"});selected=layers.at(-1).id;updateDuration()}
function addTextLayer(text,name="Text"){layers.push({id:uid(),name,kind:"text",text:text||$("textInput").value||"文字",start:current||0,duration:Math.max(5,duration-current||5),x:640,y:72,scale:1,fontFamily:$("fontFamily").value||"system-ui",fontSize:+$("fontSize").value||46,color:$("textColor").value||"#fff",outlineSize:+$("outlineSize").value||8,shadow:$("shadowOn").checked,effect:$("effect").value||"none",scrollDir:$("scrollDir").value||"rtl",trackIndex:0});selected=layers.at(-1).id;updateDuration();renderAll();log("Text added on top layer")}
async function unlockAudio(){for(const a of assets)if(a.el?.play)try{await a.el.play();a.el.pause();a.el.currentTime=0}catch{}log("Audio unlocked")}
function hasSep(v){return v?.linkedGroup&&layers.some(l=>l.kind==="audio"&&l.linkedGroup===v.linkedGroup)}
function createSepAsset(v){let s=asset(v);if(!s)return null;let m=document.createElement("video");m.src=s.url;m.preload="auto";m.playsInline=true;m.volume=+$("volume").value;m.muted=false;m.playbackRate=speed;let a={id:uid(),name:"[Separated Audio Asset] "+s.name,kind:"audio",url:s.url,duration:s.duration||v.duration,w:0,h:0,el:m};assets.push(a);return a}
function separateAudio(){let v=sel();if(!v||v.kind!=="video")return alert("請先選取 Video Clip。");if(hasSep(v)){v.muted=true;renderAll();return alert("此影片已經分離過音訊。")}let a=createSepAsset(v);if(!a)return alert("分離失敗。");let g=uid();v.linkedGroup=g;v.muted=true;layers.push({id:uid(),assetId:a.id,name:"[Separated Audio] "+v.name,kind:"audio",start:v.start,duration:v.duration,trim:v.trim||0,x:640,y:360,scale:1,volume:1,muted:false,trackIndex:0,linkedGroup:g});selected=layers.at(-1).id;updateDuration();sync(true);renderAll()}
function linkAV(){let l=sel();if(!l?.linkedGroup)return alert("請選取已分離的影片或音訊。");for(const x of layers.filter(x=>x.linkedGroup===l.linkedGroup)){x.start=l.start;x.duration=l.duration;x.trim=l.trim||0}updateDuration();renderAll()}
function localTime(l){return Math.max(0,current-l.start+(l.trim||0))}
function sync(force=false){let vol=+$("volume").value;for(const l of layers){let a=asset(l);if(!a?.el||!(l.kind==="video"||l.kind==="audio"))continue;let active=current>=l.start&&current<=l.start+l.duration;if(!active){if(!a.el.paused)a.el.pause();continue}if(l.kind==="video"&&hasSep(l))l.muted=true;let target=localTime(l),drift=Math.abs((a.el.currentTime||0)-target);if(a.el.readyState>=1&&(force||drift>.35))try{a.el.currentTime=target}catch{}try{a.el.playbackRate=speed}catch{}a.el.volume=l.kind==="audio"?vol*(l.volume??1):vol;a.el.muted=!!l.muted;if(playing&&a.el.paused)a.el.play().catch(()=>log("請先按 Enable Audio"));if(!playing&&!a.el.paused)a.el.pause()}}
function master(){return layers.find(l=>l.kind==="video")||layers.find(l=>l.kind==="audio")||null}
function play(){if(!layers.length)return log("請先匯入媒體");playing=true;pub();sync(true)}
function pause(){playing=false;pub();for(const a of assets)if(a.el?.pause)a.el.pause()}
function stop(){pause();current=0;pub();sync(true);renderAll()}
function seek(t){current=Math.max(0,Math.min(+t||0,duration));pub();sync(true);renderAll()}
function split(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;let left=current-l.start,right=l.duration-left,copy={...l,id:uid(),start:current,duration:right,trim:(l.trim||0)+left};l.duration=left;layers.push(copy);selected=copy.id;updateDuration();renderAll()}
function trimIn(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;let d=current-l.start;l.trim=(l.trim||0)+d;l.duration-=d;l.start=current;updateDuration();renderAll()}
function trimOut(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;l.duration=current-l.start;updateDuration();renderAll()}
function fit(){let l=sel();if(!l)return;let a=asset(l);l.x=640;l.y=l.kind==="text"?72:360;if(a&&l.kind!=="audio")l.scale=Math.min(canvas.width/a.w,canvas.height/a.h)*.85;renderAll()}
function applyInspector(){let l=sel();if(!l)return;l.x=+$("xInput").value;l.y=+$("yInput").value;l.scale=+$("scaleInput").value;l.start=+$("startInput").value;l.duration=+$("durationInput").value;if(l.kind==="text"){l.text=$("textInput").value||"文字";l.fontFamily=$("fontFamily").value||"system-ui";l.fontSize=+$("fontSize").value||46;l.color=$("textColor").value||"#fff";l.outlineSize=+$("outlineSize").value||8;l.shadow=$("shadowOn").checked;l.effect=$("effect").value||"none";l.scrollDir=$("scrollDir").value||"rtl"}else l.volume=+$("volume").value;updateDuration();renderAll()}
function textPos(l){let p=Math.max(0,Math.min(1,(current-l.start)/Math.max(l.duration,.01))),x=l.x,y=l.y,alpha=1;if(l.effect==="fade")alpha=Math.min(1,p*3,(1-p)*3);if(l.effect==="bounce")y=l.y-Math.abs(Math.sin(p*Math.PI*6))*30;if(l.effect==="scroll")x=l.scrollDir==="ltr"?-360+p*(canvas.width+720):canvas.width+360-p*(canvas.width+720);return{x,y,alpha}}
function drawText(l){let p=textPos(l);ctx.save();ctx.globalAlpha=Math.max(0,p.alpha);ctx.font=`bold ${l.fontSize||46}px ${l.fontFamily||"system-ui"}`;ctx.textAlign="center";ctx.textBaseline="middle";ctx.lineJoin="round";if(l.shadow){ctx.shadowColor="rgba(0,0,0,.85)";ctx.shadowBlur=10;ctx.shadowOffsetX=2;ctx.shadowOffsetY=2}ctx.lineWidth=l.outlineSize||8;ctx.strokeStyle="rgba(0,0,0,.92)";ctx.strokeText(l.text||"文字",p.x,p.y);ctx.shadowColor="transparent";ctx.lineWidth=3;ctx.strokeStyle="rgba(255,255,255,.35)";ctx.strokeText(l.text||"文字",p.x,p.y);ctx.fillStyle=l.color||"#fff";ctx.fillText(l.text||"文字",p.x,p.y);ctx.restore()}
function render(){ctx.clearRect(0,0,1280,720);ctx.fillStyle="#000";ctx.fillRect(0,0,1280,720);if(!layers.length){ctx.fillStyle="#8fa0be";ctx.font="34px system-ui";ctx.textAlign="center";ctx.fillText("Import media / TXT subtitles",640,360);return}for(const l of layers){if(current<l.start||current>l.start+l.duration)continue;if(l.kind==="text"||l.kind==="audio")continue;let a=asset(l);if(!a)continue;let w=(a.el.videoWidth||a.el.naturalWidth||a.w||640)*(l.scale||1),h=(a.el.videoHeight||a.el.naturalHeight||a.h||360)*(l.scale||1);try{ctx.drawImage(a.el,l.x-w/2,l.y-h/2,w,h)}catch{}if(l.id===selected){ctx.strokeStyle="#8b5cf6";ctx.lineWidth=3;ctx.strokeRect(l.x-w/2,l.y-h/2,w,h)}}for(const l of layers){if(current>=l.start&&current<=l.start+l.duration&&l.kind==="text"){drawText(l);if(l.id===selected){let bw=Math.max(180,(l.text||"文字").length*(l.fontSize||46)*.72),bh=(l.fontSize||46)*1.9;ctx.save();ctx.strokeStyle="#f59e0b";ctx.lineWidth=2;ctx.strokeRect(l.x-bw/2,l.y-bh/2,bw,bh);ctx.restore()}}}}
function renderMedia(){let box=$("mediaList");box.innerHTML="";for(const a of assets){let d=document.createElement("div");d.className="card";d.innerHTML=`<strong>${a.name}</strong><small>${a.kind} · ${fmt(a.duration)} · ${a.w}x${a.h}</small><button>Add again</button>`;d.querySelector("button").onclick=()=>{addLayerFromAsset(a);renderAll()};box.appendChild(d)}}
function groupFor(k){return k==="audio"?"audio":k==="text"?"text":"video"}function groupKinds(g){return g==="audio"?["audio"]:g==="text"?["text"]:["video","image","gif"]}function maxDur(l){let a=asset(l);return["image","gif","text"].includes(l.kind)?Math.max(duration,300):(a?.duration||l.duration||1)}
function rippleFrom(layer,delta){if(!$("rippleToggle").checked||!delta)return;let g=groupFor(layer.kind);for(const l of layers)if(l.id!==layer.id&&groupFor(l.kind)===g&&l.trackIndex===layer.trackIndex&&l.start>=layer.start)l.start=Math.max(0,l.start+delta)}
function resizeClip(e,id,side){e.preventDefault();e.stopPropagation();let l=layers.find(x=>x.id===id),lane=e.currentTarget.closest(".lane");if(!l||!lane)return;let rect=lane.getBoundingClientRect(),total=Math.max(duration,1),sx=e.clientX,os=l.start,od=l.duration,ot=l.trim||0;function move(ev){let sec=(ev.clientX-sx)/rect.width*total;if(side==="right")l.duration=Math.max(1,Math.min(od+sec,maxDur(l)));else{let ns=os+sec,nd=od-sec;if(ns<0){nd+=ns;ns=0}if(nd<1){ns=os+od-1;nd=1}l.start=snap(Math.max(0,ns));l.duration=Math.max(1,Math.min(nd,maxDur(l)));if(!["image","gif","text"].includes(l.kind))l.trim=Math.max(0,ot+(l.start-os))}updateDuration();renderAll()}function up(){removeEventListener("mousemove",move);removeEventListener("mouseup",up)}addEventListener("mousemove",move);addEventListener("mouseup",up)}
function dragClip(e,id){e.preventDefault();e.stopPropagation();let l=layers.find(x=>x.id===id),lane=e.currentTarget.closest(".lane");if(!l||!lane)return;selected=id;let g=groupFor(l.kind),names=tracks[g],rect=lane.getBoundingClientRect(),total=Math.max(duration,1),sx=e.clientX,sy=e.clientY,os=l.start,ot=l.trackIndex||0;function move(ev){let ns=snap(Math.max(0,os+(ev.clientX-sx)/rect.width*total)),delta=ns-l.start;l.start=ns;l.trackIndex=Math.max(0,Math.min(names.length-1,ot+Math.round((ev.clientY-sy)/34)));rippleFrom(l,delta);updateDuration();renderAll()}function up(){removeEventListener("mousemove",move);removeEventListener("mouseup",up);renderAll()}addEventListener("mousemove",move);addEventListener("mouseup",up)}
function renderTracks(){let cont=$("tracks");cont.innerHTML="";for(const g of ["video","audio","text"]){let names=tracks[g],kinds=groupKinds(g);names.forEach((name,idx)=>{let tr=document.createElement("div");tr.className="track";tr.innerHTML=`<div class="track-name">${name}</div><div class="lane" data-group="${g}" data-track="${idx}"></div>`;let lane=tr.querySelector(".lane"),total=Math.max(duration,1);for(const l of layers.filter(x=>kinds.includes(x.kind)&&(x.trackIndex??0)===idx)){let c=document.createElement("div");c.className="clip "+(l.kind==="text"?"text":l.kind==="audio"?"audio":"")+(l.id===selected?" selected":"")+(l.linkedGroup?" linked":"");c.innerHTML=`<span class="resize-left"></span><span class="clip-label"></span><span class="resize-right"></span>`;c.querySelector(".clip-label").textContent=l.name||l.text;c.style.left=`${l.start/total*100}%`;c.style.width=`${Math.max(2,l.duration/total*100)}%`;c.onclick=()=>{selected=l.id;pub();renderAll()};c.querySelector(".clip-label").onmousedown=ev=>dragClip(ev,l.id);c.querySelector(".resize-left").onmousedown=ev=>resizeClip(ev,l.id,"left");c.querySelector(".resize-right").onmousedown=ev=>resizeClip(ev,l.id,"right");lane.appendChild(c)}cont.appendChild(tr)})}}
function renderInspector(){let l=sel();$("selectedName").textContent=l?(l.name||l.text):"未選取";if(!l)return;$("xInput").value=Math.round(l.x||0);$("yInput").value=Math.round(l.y||0);$("scaleInput").value=l.scale??1;$("startInput").value=l.start??0;$("durationInput").value=l.duration??0;if(l.kind==="text"){$("textInput").value=l.text||"";$("fontFamily").value=l.fontFamily||"system-ui";$("fontSize").value=l.fontSize||46;$("textColor").value=l.color||"#fff";$("outlineSize").value=l.outlineSize||8;$("shadowOn").checked=l.shadow??true;$("effect").value=l.effect||"none";$("scrollDir").value=l.scrollDir||"rtl"}}
function renderAll(){pub();render();renderMedia();renderTracks();renderInspector();$("timeLabel").textContent=`${fmt(current)} / ${fmt(duration)}`;$("scrubber").value=current}
function loop(){let m=master();if(playing&&m){let a=asset(m);if(a?.el){current=m.start+Math.max(0,(a.el.currentTime||0)-(m.trim||0));if(current>=duration||a.el.ended){current=Math.min(duration,current);pause()}pub();sync(false)}}render();$("timeLabel").textContent=`${fmt(current)} / ${fmt(duration)}`;$("scrubber").value=current;requestAnimationFrame(loop)}
function saveProject(){let blob=new Blob([JSON.stringify({version:"ultimate-fixed",assets:assets.map(a=>({id:a.id,name:a.name,kind:a.kind,duration:a.duration,w:a.w,h:a.h})),layers},null,2)],{type:"application/json"});let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="project.studioflow";a.click()}
async function openProjectFile(file){try{let data=JSON.parse(await file.text());if(Array.isArray(data.layers)){layers=data.layers;selected=null;current=0;updateDuration();renderAll();alert("Project opened. 請重新匯入原始媒體以重新連結素材。")}}catch(e){alert("Open failed: "+e.message)}}
async function saveBlob(blob,name,mime){let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000)}
function recordWebM(){return new Promise((res,rej)=>{let seconds=Math.max(1,duration||1),old=current,was=playing,chunks=[];seek(0);play();let stream=canvas.captureStream(30),mime="video/webm;codecs=vp9";if(!MediaRecorder.isTypeSupported(mime))mime="video/webm";let rec=new MediaRecorder(stream,{mimeType:mime});rec.ondataavailable=e=>{if(e.data&&e.data.size)chunks.push(e.data)};rec.onerror=e=>rej(e.error||e);rec.onstop=()=>{pause();seek(old);if(was)play();res(new Blob(chunks,{type:"video/webm"}))};rec.start(250);setTimeout(()=>rec.stop(),seconds*1000)})}
async function getFFmpeg(){if(location.protocol==="file:")throw Error("FFmpeg conversion needs localhost. Run start_server.bat and open http://localhost:8000. WebM export can still work.");if(!window.FFmpegWASM||!window.FFmpegUtil)throw Error("FFmpeg.wasm scripts are not available.");let {FFmpeg}=window.FFmpegWASM,{toBlobURL}=window.FFmpegUtil,ffmpeg=new FFmpeg();ffmpeg.on("log",({message})=>$("exportStatus").textContent=message.slice(0,160));ffmpeg.on("progress",({progress})=>{$("exportProgress").value=progress*100;$("exportStatus").textContent="FFmpeg: "+Math.round(progress*100)+"%"});try{await ffmpeg.load({coreURL:"./ffmpeg/ffmpeg-core.js",wasmURL:"./ffmpeg/ffmpeg-core.wasm",workerURL:"./ffmpeg/ffmpeg-core.worker.js"})}catch(e){let b="https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd";await ffmpeg.load({coreURL:await toBlobURL(`${b}/ffmpeg-core.js`,"text/javascript"),wasmURL:await toBlobURL(`${b}/ffmpeg-core.wasm`,"application/wasm")})}return ffmpeg}
async function convert(webm,fmt){let f=await getFFmpeg();await f.writeFile("in.webm",new Uint8Array(await webm.arrayBuffer()));let map={mp4:{args:["-i","in.webm","-c:v","libx264","-pix_fmt","yuv420p","-preset","veryfast","-crf","23","-movflags","+faststart","out.mp4"],file:"out.mp4",mime:"video/mp4",name:"studioflow.mp4"},mp3:{args:["-i","in.webm","-vn","-acodec","libmp3lame","-b:a","192k","out.mp3"],file:"out.mp3",mime:"audio/mpeg",name:"studioflow.mp3"},wav:{args:["-i","in.webm","-vn","-acodec","pcm_s16le","-ar","44100","-ac","2","out.wav"],file:"out.wav",mime:"audio/wav",name:"studioflow.wav"},gif:{args:["-i","in.webm","-vf","fps=12,scale=960:-1:flags=lanczos","-loop","0","out.gif"],file:"out.gif",mime:"image/gif",name:"studioflow.gif"}};let item=map[fmt];if(!item)return{blob:webm,name:"studioflow.webm",mime:"video/webm"};await f.exec(item.args);let d=await f.readFile(item.file);return{blob:new Blob([d.buffer],{type:item.mime}),name:item.name,mime:item.mime}}
async function exportAll(){try{let fmt=$("exportFormat").value;$("exportStatus").textContent="Recording full timeline...";let webm=await recordWebM();if(fmt==="webm"){await saveBlob(webm,"studioflow.webm","video/webm");$("exportStatus").textContent="WebM exported";return}try{let out=await convert(webm,fmt);await saveBlob(out.blob,out.name,out.mime);$("exportStatus").textContent=fmt.toUpperCase()+" exported"}catch(e){alert("FFmpeg 轉檔失敗：\n"+e.message+"\n\n已改為下載 WebM。");await saveBlob(webm,"studioflow_fallback.webm","video/webm")}}catch(e){alert("Export failed:\n"+e.message)}}
function bind(){$("fileInput").onchange=e=>importFiles(e.target.files);$("openProject").onchange=e=>{let f=e.target.files[0];if(f)openProjectFile(f)};$("unlockAudio").onclick=unlockAudio;$("newProject").onclick=()=>{assets=[];layers=[];selected=null;current=0;updateDuration();renderAll()};$("saveProject").onclick=saveProject;$("play").onclick=play;$("pause").onclick=pause;$("stop").onclick=stop;$("back").onclick=()=>seek(current-5);$("forward").onclick=()=>seek(current+5);$("speed").onchange=e=>{speed=+e.target.value;sync(true)};$("volume").oninput=()=>sync(true);$("scrubber").oninput=e=>seek(+e.target.value);$("split").onclick=split;$("trimIn").onclick=trimIn;$("trimOut").onclick=trimOut;$("separateAudio").onclick=separateAudio;$("linkAV").onclick=linkAV;$("muteVideoAudio").onclick=()=>{let l=sel();if(l&&l.kind==="video"){l.muted=true;renderAll()}};$("unmuteVideoAudio").onclick=()=>{let l=sel();if(l&&l.kind==="video"&&!hasSep(l)){l.muted=false;renderAll()}};$("fit").onclick=fit;$("addText").onclick=()=>addTextLayer($("textInput").value||"文字");$("textTop").onclick=()=>{let l=sel();if(l&&l.kind==="text"){l.x=640;l.y=72;renderAll()}};$("textBottom").onclick=()=>{let l=sel();if(l&&l.kind==="text"){l.x=640;l.y=650;renderAll()}};$("removeClipEffect").onclick=()=>{let l=sel();if(l){l.effect="none";renderAll()}};$("deleteSelected").onclick=()=>{layers=layers.filter(l=>l.id!==selected);selected=null;updateDuration();renderAll()};$("deleteAllText").onclick=()=>{layers=layers.filter(l=>l.kind!=="text");selected=null;updateDuration();renderAll()};$("deleteAllEffects").onclick=()=>{for(const l of layers)l.effect="none";renderAll()};$("clearTimeline").onclick=()=>{layers=[];selected=null;current=0;updateDuration();renderAll()};$("exportButton").onclick=exportAll;["xInput","yInput","scaleInput","startInput","durationInput","textInput","fontFamily","fontSize","textColor","outlineSize","shadowOn","effect","scrollDir"].forEach(id=>$(id).oninput=applyInspector);let drop=$("dropZone");drop.ondragover=e=>{e.preventDefault();drop.classList.add("drag")};drop.ondragleave=()=>drop.classList.remove("drag");drop.ondrop=e=>{e.preventDefault();drop.classList.remove("drag");importFiles(e.dataTransfer.files)};canvas.onmousedown=e=>{let r=canvas.getBoundingClientRect(),sx=(e.clientX-r.left)*(1280/r.width),sy=(e.clientY-r.top)*(720/r.height),hit=null;for(let i=layers.length-1;i>=0;i--){let l=layers[i];if(l.kind!=="text")continue;let bw=Math.max(180,(l.text||"文字").length*(l.fontSize||46)*.72),bh=(l.fontSize||46)*1.9;if(sx>=l.x-bw/2&&sx<=l.x+bw/2&&sy>=l.y-bh/2&&sy<=l.y+bh/2){hit=l;break}}if(!hit){for(let i=layers.length-1;i>=0;i--){let l=layers[i];if(l.kind==="audio"||l.kind==="text")continue;let a=asset(l);if(!a)continue;let w=(a.el.videoWidth||a.el.naturalWidth||a.w||640)*(l.scale||1),h=(a.el.videoHeight||a.el.naturalHeight||a.h||360)*(l.scale||1);if(sx>=l.x-w/2&&sx<=l.x+w/2&&sy>=l.y-h/2&&sy<=l.y+h/2){hit=l;break}}}if(!hit)return;selected=hit.id;let ox=hit.x,oy=hit.y;function move(ev){let nx=(ev.clientX-r.left)*(1280/r.width),ny=(ev.clientY-r.top)*(720/r.height);hit.x=ox+nx-sx;hit.y=oy+ny-sy;renderAll()}function up(){removeEventListener("mousemove",move);removeEventListener("mouseup",up);renderAll()}addEventListener("mousemove",move);addEventListener("mouseup",up);renderAll()};renderAll();requestAnimationFrame(loop);log("StudioFlow Ultimate FIXED ready")}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bind);else bind();
})();

/* TextTop Final Internal Fix
   Keeps FFmpeg and all current features.
   Fixes:
   - New text not visible after Add Text
   - Text always above video/image/effects
   - Text draggable on canvas
*/
(function(){
  function q(id){ return document.getElementById(id); }

  function normalizeTextLayer(l){
    l.kind = "text";
    l.name = l.name || "Text";
    l.text = l.text || q("textInput")?.value || "文字";
    l.start = Number.isFinite(Number(l.start)) ? Number(l.start) : 0;
    l.duration = Math.max(1, Number(l.duration || 8));
    l.x = Number.isFinite(Number(l.x)) ? Number(l.x) : 640;
    l.y = Number.isFinite(Number(l.y)) ? Number(l.y) : 72;
    l.scale = Number(l.scale || 1);
    l.fontFamily = l.fontFamily || q("fontFamily")?.value || "system-ui";
    l.fontSize = Number(l.fontSize || q("fontSize")?.value || 46);
    l.color = l.color || q("textColor")?.value || "#ffffff";
    l.outlineSize = Number(l.outlineSize || q("outlineSize")?.value || 8);
    l.shadow = l.shadow !== false;
    l.effect = l.effect || q("effect")?.value || "none";
    l.scrollDir = l.scrollDir || q("scrollDir")?.value || "rtl";
    l.trackIndex = Number(l.trackIndex || 0);
    return l;
  }

  function addTextTopLayer(){
    const text = q("textInput")?.value || "文字";
    const start = Number(current || 0);
    const dur = Math.max(5, Number(duration || 0) > start ? Number(duration) - start : 8);

    const layer = normalizeTextLayer({
      id: uid(),
      name: "Text",
      kind: "text",
      text,
      start,
      duration: dur,
      x: 640,
      y: 72,
      scale: 1,
      fontFamily: q("fontFamily")?.value || "system-ui",
      fontSize: Number(q("fontSize")?.value || 46),
      color: q("textColor")?.value || "#ffffff",
      outlineSize: Number(q("outlineSize")?.value || 8),
      shadow: q("shadowOn")?.checked ?? true,
      effect: q("effect")?.value || "none",
      scrollDir: q("scrollDir")?.value || "rtl",
      trackIndex: 0
    });

    layers.push(layer);
    selected = layer.id;
    updateDuration();

    // Make it visible immediately even if the playhead is outside duration by seeking to the clip start.
    if(current < layer.start || current > layer.start + layer.duration){
      current = layer.start;
    }

    renderAll();
    log("Text added: 文字已顯示並固定在最上層。");
  }

  function topTextPosition(l){
    normalizeTextLayer(l);
    const p = Math.max(0, Math.min(1, (current - l.start) / Math.max(l.duration, 0.01)));
    let x = l.x;
    let y = l.y;
    let alpha = 1;

    if(l.effect === "fade"){
      alpha = Math.min(1, p * 3, (1 - p) * 3);
    }
    if(l.effect === "bounce"){
      y = l.y - Math.abs(Math.sin(p * Math.PI * 6)) * 30;
    }
    if(l.effect === "scroll"){
      x = l.scrollDir === "ltr"
        ? -360 + p * (canvas.width + 720)
        : canvas.width + 360 - p * (canvas.width + 720);
    }

    return {x, y, alpha};
  }

  function drawTextTop(l){
    normalizeTextLayer(l);
    const p = topTextPosition(l);

    ctx.save();
    ctx.globalAlpha = Math.max(0, p.alpha);
    ctx.font = `bold ${l.fontSize}px ${l.fontFamily}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";

    if(l.shadow){
      ctx.shadowColor = "rgba(0,0,0,.85)";
      ctx.shadowBlur = 10;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 2;
    }

    ctx.lineWidth = l.outlineSize;
    ctx.strokeStyle = "rgba(0,0,0,.92)";
    ctx.strokeText(l.text, p.x, p.y);

    ctx.shadowColor = "transparent";
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(255,255,255,.35)";
    ctx.strokeText(l.text, p.x, p.y);

    ctx.fillStyle = l.color;
    ctx.fillText(l.text, p.x, p.y);

    if(l.id === selected){
      const bw = Math.max(180, l.text.length * l.fontSize * 0.72);
      const bh = l.fontSize * 1.9;
      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 2;
      ctx.strokeRect(l.x - bw/2, l.y - bh/2, bw, bh);
    }

    ctx.restore();
  }

  function renderTextAlwaysTop(){
    ctx.clearRect(0,0,1280,720);
    ctx.fillStyle = "#000";
    ctx.fillRect(0,0,1280,720);

    if(!layers.length){
      ctx.fillStyle = "#8fa0be";
      ctx.font = "34px system-ui";
      ctx.textAlign = "center";
      ctx.fillText("Import media / TXT subtitles", 640, 360);
      return;
    }

    // 1. Video / Image / GIF
    for(const l of layers){
      if(current < l.start || current > l.start + l.duration) continue;
      if(l.kind === "audio" || l.kind === "text") continue;

      const a = asset(l);
      if(!a) continue;

      const w = (a.el.videoWidth || a.el.naturalWidth || a.w || 640) * (l.scale || 1);
      const h = (a.el.videoHeight || a.el.naturalHeight || a.h || 360) * (l.scale || 1);

      try{ ctx.drawImage(a.el, l.x - w/2, l.y - h/2, w, h); }catch(e){}

      if(l.id === selected){
        ctx.strokeStyle = "#8b5cf6";
        ctx.lineWidth = 3;
        ctx.strokeRect(l.x - w/2, l.y - h/2, w, h);
      }
    }

    // 2. Effects placeholder stays below text.

    // 3. Text ALWAYS LAST / TOP.
    for(const l of layers){
      if(l.kind !== "text") continue;
      normalizeTextLayer(l);
      if(current < l.start || current > l.start + l.duration) continue;
      drawTextTop(l);
    }
  }

  function bindTextTopDrag(){
    canvas.addEventListener("mousedown", function(e){
      const r = canvas.getBoundingClientRect();
      const sx = (e.clientX - r.left) * (1280 / r.width);
      const sy = (e.clientY - r.top) * (720 / r.height);

      let hit = null;

      // Text has selection priority because it is top layer.
      for(let i = layers.length - 1; i >= 0; i--){
        const l = layers[i];
        if(l.kind !== "text") continue;
        normalizeTextLayer(l);
        const bw = Math.max(180, l.text.length * l.fontSize * 0.72);
        const bh = l.fontSize * 1.9;
        if(sx >= l.x - bw/2 && sx <= l.x + bw/2 &&
           sy >= l.y - bh/2 && sy <= l.y + bh/2){
          hit = l;
          break;
        }
      }

      if(!hit) return;

      e.preventDefault();
      e.stopPropagation();

      selected = hit.id;
      const ox = hit.x;
      const oy = hit.y;

      function move(ev){
        const nx = (ev.clientX - r.left) * (1280 / r.width);
        const ny = (ev.clientY - r.top) * (720 / r.height);
        hit.x = ox + nx - sx;
        hit.y = oy + ny - sy;
        renderAll();
      }

      function up(){
        window.removeEventListener("mousemove", move, true);
        window.removeEventListener("mouseup", up, true);
        renderAll();
      }

      window.addEventListener("mousemove", move, true);
      window.addEventListener("mouseup", up, true);
      renderAll();
    }, true);
  }

  // Override render/addText while keeping FFmpeg/export and all existing functions.
  render = renderTextAlwaysTop;
  drawText = drawTextTop;
  addTextLayer = addTextTopLayer;

  function rebindText(){
    const add = q("addText");
    if(add){
      add.onclick = function(e){
        if(e) e.preventDefault();
        addTextTopLayer();
      };
    }

    [
      "xInput","yInput","scaleInput","startInput","durationInput",
      "textInput","fontFamily","fontSize","textColor","outlineSize",
      "shadowOn","effect","scrollDir"
    ].forEach(id => {
      const el = q(id);
      if(el){
        const old = el.oninput;
        el.oninput = function(ev){
          const l = sel();
          if(l && l.kind === "text"){
            normalizeTextLayer(l);
            l.x = Number(q("xInput")?.value || l.x);
            l.y = Number(q("yInput")?.value || l.y);
            l.start = Number(q("startInput")?.value || l.start);
            l.duration = Math.max(1, Number(q("durationInput")?.value || l.duration));
            l.text = q("textInput")?.value || l.text || "文字";
            l.fontFamily = q("fontFamily")?.value || l.fontFamily;
            l.fontSize = Number(q("fontSize")?.value || l.fontSize);
            l.color = q("textColor")?.value || l.color;
            l.outlineSize = Number(q("outlineSize")?.value || l.outlineSize);
            l.shadow = q("shadowOn")?.checked ?? true;
            l.effect = q("effect")?.value || l.effect;
            l.scrollDir = q("scrollDir")?.value || l.scrollDir;
            updateDuration();
            renderAll();
          }else if(typeof old === "function"){
            old(ev);
          }
        };
      }
    });
  }

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", () => {
      rebindText();
      bindTextTopDrag();
      renderAll();
      log("TextTop Final Fix loaded.");
    });
  }else{
    rebindText();
    bindTextTopDrag();
    renderAll();
    log("TextTop Final Fix loaded.");
  }

  setTimeout(rebindText, 500);
  setTimeout(rebindText, 1500);
})();
