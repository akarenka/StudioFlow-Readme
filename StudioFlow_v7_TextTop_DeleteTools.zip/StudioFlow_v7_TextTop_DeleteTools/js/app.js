const $=id=>document.getElementById(id),canvas=$("canvas"),ctx=canvas.getContext("2d");let assets=[],layers=[],selected=null,current=0,duration=0,playing=false,last=0,speed=1;
const uid=()=>"sf_"+Math.random().toString(36).slice(2)+Date.now().toString(36),fmt=t=>{t=Math.max(0,t||0);let m=Math.floor(t/60),s=Math.floor(t%60),h=Math.floor((t%1)*100);return`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(h).padStart(2,"0")}`};const log=t=>$("msg").textContent=t;
function kindOf(f){let e=f.name.split(".").pop().toLowerCase();if(["txt","srt","vtt"].includes(e))return"textfile";if(f.type.startsWith("video/")||["mp4","webm","mov","avi","mkv"].includes(e))return"video";if(f.type.startsWith("audio/")||["mp3","wav","m4a","aac","ogg"].includes(e))return"audio";return"image"}function sel(){return layers.find(l=>l.id===selected)}function asset(l){return assets.find(a=>a.id===l.assetId)}
async function importFiles(files){for(const f of [...files]){let kind=kindOf(f),url=URL.createObjectURL(f);try{if(kind==="textfile"){let text=await f.text(),joined=text.replace(/\r/g,"").split("\n").filter(Boolean).slice(0,12).join("  ");layers.push({id:uid(),name:f.name,kind:"text",text:joined,start:0,duration:Math.max(duration || 0, 8),x:640,y:72,scale:1,fontSize:42,color:"#fff",fontFamily:"system-ui",effect:"fade",scrollDir:"rtl",scrollDir:"rtl"});selected=layers[layers.length-1].id;updateDuration();log("TXT synced on video: "+f.name)}else{let a={id:uid(),name:f.name,kind,url,duration:5,w:640,h:360,el:null};if(kind==="video"){let v=document.createElement("video");v.src=url;v.preload="auto";v.playsInline=true;v.volume=Number($("volume").value);a.el=v;await new Promise((res,rej)=>{v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:5;a.w=v.videoWidth||640;a.h=v.videoHeight||360;res()};v.onerror=()=>rej(Error("瀏覽器無法解碼此影片，請轉 MP4 H.264/WebM"));v.load()})}else if(kind==="audio"){let au=document.createElement("audio");au.src=url;au.preload="auto";au.volume=Number($("volume").value);a.el=au;await new Promise((res,rej)=>{au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:5;res()};au.onerror=()=>rej(Error("瀏覽器無法解碼此音訊"));au.load()})}else{let img=new Image();img.src=url;a.el=img;await new Promise(res=>{img.onload=()=>{a.w=img.naturalWidth||640;a.h=img.naturalHeight||360;res()};img.onerror=res})}assets.push(a);addToTimeline(a.id);log("Imported: "+f.name)}}catch(e){alert(f.name+"\\n"+e.message)}}renderAll()}
function addToTimeline(id){let a=assets.find(x=>x.id===id);if(!a)return;let sc=a.kind==="audio"?1:Math.min(canvas.width/a.w,canvas.height/a.h)*.85;layers.push({id:uid(),assetId:a.id,name:a.name,kind:a.kind,start:0,duration:a.duration,trim:0,x:640,y:360,scale:sc,volume:1,muted:false,effect:"none"});selected=layers[layers.length-1].id;updateDuration()}function updateDuration(){duration=Math.max(0,...layers.map(l=>l.start+l.duration));$("scrub").max=duration}
async function unlock(){for(const a of assets)if(a.el?.play)try{await a.el.play();a.el.pause();a.el.currentTime=0}catch{}log("Audio unlocked")}function play(){if(!layers.length)return log("Import media first");playing=true;sync(true)}function pause(){playing=false;for(const a of assets)if(a.el?.pause)a.el.pause()}function stop(){pause();current=0;sync(true)}function seek(t){current=Math.max(0,Math.min(t,duration));sync(true);renderAll()}
function sync(force=false){for(const l of layers){let a=asset(l);if(!a?.el||!(l.kind==="video"||l.kind==="audio"))continue;let active=current>=l.start&&current<=l.start+l.duration;if(!active){if(!a.el.paused)a.el.pause();continue}let local=(l.trim||0)+(current-l.start);if(a.el.readyState>=1&&(force||Math.abs(a.el.currentTime-local)>.50))try{a.el.currentTime=local}catch{}a.el.volume=l.volume??1;a.el.muted=!!l.muted;a.el.playbackRate=speed;if(playing&&a.el.paused)a.el.play().catch(()=>log("Press 🔊 啟用聲音 first"));if(!playing&&!a.el.paused)a.el.pause()}}
function split(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;let left=current-l.start,right=l.duration-left,c={...l,id:uid(),start:current,duration:right,trim:(l.trim||0)+left};l.duration=left;layers.push(c);selected=c.id;updateDuration();renderAll()}function trimIn(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;let d=current-l.start;l.trim=(l.trim||0)+d;l.duration-=d;l.start=current;updateDuration();renderAll()}function trimOut(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;l.duration=current-l.start;updateDuration();renderAll()}function separate(){let l=sel();if(!l||l.kind!=="video")return log("Select video first");let a={...l,id:uid(),kind:"audio",name:"[Audio] "+l.name,muted:false};l.muted=true;layers.push(a);selected=a.id;updateDuration();renderAll()}
function fit(){let l=sel(),a=l&&asset(l);if(!l)return;l.x=640;l.y=360;if(a&&l.kind!=="audio")l.scale=Math.min(canvas.width/a.w,canvas.height/a.h)*.85;renderAll()}function addText(){
 const textValue = $("textInput") ? ($("textInput").value || "文字") : "文字";
 const l = {
  id:uid(),
  name:"Text",
  kind:"text",
  text:textValue,
  start:current || 0,
  duration:Math.max(5, (duration-(current||0)) || 5),
  x:640,
  y:72,
  scale:1,
  fontSize:Number($("fontSize")?.value || 46),
  color:$("textColor")?.value || "#ffffff",
  fontFamily:$("fontFamily") ? $("fontFamily").value : "system-ui",
  effect:$("effect") ? $("effect").value : "none",
  scrollDir:$("scrollDir") ? $("scrollDir").value : "rtl"
 };
 layers.push(l);
 selected=l.id;
 updateDuration();
 log("文字已加入影片畫面。按播放可執行文字效果。");
 renderAll()
}function del(){layers=layers.filter(l=>l.id!==selected);selected=null;updateDuration();renderAll()}
function applyInspector(){let l=sel();if(!l)return;l.x=Number($("x").value);l.y=Number($("y").value);l.scale=Number($("scale").value);l.start=Number($("start").value);l.duration=Number($("duration").value);if(l.kind==="text"){l.text=$("textInput").value;l.fontSize=Number($("fontSize").value);l.color=$("textColor").value;if($("fontFamily"))l.fontFamily=$("fontFamily").value;l.effect=$("effect").value;if($("scrollDir"))l.scrollDir=$("scrollDir").value;if($("scrollDir"))l.scrollDir=$("scrollDir").value}else l.volume=Number($("volume").value);updateDuration();renderAll()}
function drawText(l){
 ctx.save();
 const p=(current-l.start)/Math.max(l.duration,.01);
 let x=l.x ?? 640, y=l.y ?? 72, alpha=1;
 if(l.effect==="fade") alpha=Math.min(1,p*3,(1-p)*3);
 if(l.effect==="bounce") y=(l.y??72)-Math.abs(Math.sin(p*Math.PI*6))*30;
 if(l.effect==="scroll"){
   if((l.scrollDir||"rtl")==="rtl") x=canvas.width+360-p*(canvas.width+720);
   else x=-360+p*(canvas.width+720);
 }
 ctx.globalAlpha=Math.max(0,alpha);
 const fontFamily=l.fontFamily||"system-ui";
 ctx.font=`bold ${l.fontSize||46}px ${fontFamily}`;
 ctx.textAlign="center";
 ctx.textBaseline="middle";
 ctx.lineJoin="round";
 ctx.lineWidth=8;
 ctx.strokeStyle="rgba(0,0,0,.85)";
 ctx.strokeText(l.text||"文字",x,y);
 ctx.lineWidth=3;
 ctx.strokeStyle="rgba(255,255,255,.35)";
 ctx.strokeText(l.text||"文字",x,y);
 ctx.fillStyle=l.color||"#ffffff";
 ctx.fillText(l.text||"文字",x,y);
 ctx.restore()
}
function render(){
 ctx.clearRect(0,0,1280,720);
 ctx.fillStyle="#000";
 ctx.fillRect(0,0,1280,720);

 if(!layers.length){
  ctx.fillStyle="#8fa0be";
  ctx.font="34px system-ui";
  ctx.textAlign="center";
  ctx.fillText("Import media / TXT subtitles",640,360);
  return;
 }

 // 1) draw visual media first: video/image/gif
 for(const l of layers){
  if(current<l.start||current>l.start+l.duration) continue;
  if(l.kind==="text" || l.kind==="audio") continue;
  const a=asset(l);
  if(!a) continue;
  if(["video","image","gif"].includes(l.kind)){
   const w=(a.el.videoWidth||a.el.naturalWidth||a.w)*l.scale;
   const h=(a.el.videoHeight||a.el.naturalHeight||a.h)*l.scale;
   try{ctx.drawImage(a.el,l.x-w/2,l.y-h/2,w,h)}catch{}
   if(l.id===selected){
    ctx.strokeStyle="#8b5cf6";
    ctx.lineWidth=3;
    ctx.strokeRect(l.x-w/2,l.y-h/2,w,h);
   }
  }
 }

 // 2) draw all text overlays last so text is always on top of video/image
 for(const l of layers){
  if(current<l.start||current>l.start+l.duration) continue;
  if(l.kind==="text"){
   drawText(l);
   if(l.id===selected){
    const fs=l.fontSize||46;
    const approxW=Math.max(180,(l.text||"文字").length*fs*.7);
    const approxH=fs*1.8;
    ctx.strokeStyle="#f59e0b";
    ctx.lineWidth=2;
    ctx.strokeRect((l.x||640)-approxW/2,(l.y||72)-approxH/2,approxW,approxH);
   }
  }
 }
}
function renderList(){$("list").innerHTML="";for(const a of assets){let d=document.createElement("div");d.className="card";d.innerHTML=`<strong>${a.name}</strong><small>${a.kind} · ${fmt(a.duration)} · ${a.w}x${a.h}</small><button>Add again</button>`;d.querySelector("button").onclick=()=>{addToTimeline(a.id);renderAll()};$("list").appendChild(d)}}
function layerMaxDuration(l){
 const a=asset(l);
 if(l.kind==="image"||l.kind==="gif"||l.kind==="text") return Math.max(duration, 300);
 return a?.duration || l.duration || 1;
}
function clampLayerDuration(l, value){
 const max=layerMaxDuration(l);
 return Math.max(1, Math.min(value, max));
}
function resizeClipMouse(ev, layerId, side){
 ev.stopPropagation(); ev.preventDefault();
 const l=layers.find(x=>x.id===layerId); if(!l)return;
 const lane=ev.currentTarget.closest(".lane");
 const rect=lane.getBoundingClientRect();
 const total=Math.max(duration, 1);
 const startX=ev.clientX;
 const oldStart=l.start, oldDuration=l.duration, oldTrim=l.trim||0;
 function move(e){
   const dx=e.clientX-startX;
   const sec=(dx/rect.width)*total;
   if(side==="right"){
     l.duration=clampLayerDuration(l, oldDuration+sec);
   }else{
     let newStart=oldStart+sec;
     let newDuration=oldDuration-sec;
     if(newStart<0){newDuration+=newStart;newStart=0}
     if(newDuration<1){newStart=oldStart+oldDuration-1;newDuration=1}
     l.start=Math.max(0,newStart);
     l.duration=clampLayerDuration(l,newDuration);
     if(l.kind!=="image"&&l.kind!=="gif"&&l.kind!=="text"){
       l.trim=Math.max(0,oldTrim+(l.start-oldStart));
     }
   }
   updateDuration();
   renderAll();
 }
 function up(){
   window.removeEventListener("mousemove",move);
   window.removeEventListener("mouseup",up);
 }
 window.addEventListener("mousemove",move);
 window.addEventListener("mouseup",up);
}

function dragClipMouse(ev, layerId){
 ev.stopPropagation(); ev.preventDefault();
 const l=layers.find(x=>x.id===layerId); if(!l)return;
 selected=l.id;
 const lane=ev.currentTarget.closest(".lane");
 const rect=lane.getBoundingClientRect();
 const total=Math.max(duration, 1);
 const startX=ev.clientX;
 const oldStart=l.start;
 function move(e){
   const dx=e.clientX-startX;
   const sec=(dx/rect.width)*total;
   let ns=oldStart+sec;
   ns=Math.max(0, ns);
   // Keep media clips inside their own max range when possible.
   if(l.kind==="video"||l.kind==="audio"){
     ns=Math.min(ns, Math.max(0, duration-l.duration));
   }
   l.start=ns;
   updateDuration();
   renderAll();
 }
 function up(){
   window.removeEventListener("mousemove",move);
   window.removeEventListener("mouseup",up);
 }
 window.addEventListener("mousemove",move);
 window.addEventListener("mouseup",up);
}

function moveLayerOrder(layerId, dir){
 const idx=layers.findIndex(l=>l.id===layerId);
 if(idx<0)return;
 const ni=idx+dir;
 if(ni<0||ni>=layers.length)return;
 const tmp=layers[idx];
 layers[idx]=layers[ni];
 layers[ni]=tmp;
 selected=layerId;
 renderAll();
}

function renderTracks(){
 const cont=$("tracks");cont.innerHTML="";
 for(const [name,kinds] of [["Video",["video","image","gif"]],["Audio",["audio"]],["Text",["text"]]]){
  let tr=document.createElement("div");tr.className="track";tr.innerHTML=`<div class="trackName">${name}</div><div class="lane"></div>`;
  let lane=tr.querySelector(".lane"),total=Math.max(duration,1);
  for(const l of layers.filter(x=>kinds.includes(x.kind))){
   let c=document.createElement("div");
   c.className="clip "+(l.kind==="text"?"textClip":l.kind==="audio"?"audioClip":"")+(l.id===selected?" sel":"");
   c.innerHTML=`<span class="resize-left"></span><span class="clip-label"></span><span class="resize-right"></span>`;
   c.querySelector(".clip-label").textContent=l.name||l.text;
   c.style.left=`${l.start/total*100}%`;
   c.style.width=`${Math.max(2,l.duration/total*100)}%`;
   c.onclick=()=>{selected=l.id;renderAll()};
   c.querySelector(".clip-label").onmousedown=(e)=>dragClipMouse(e,l.id);
   c.querySelector(".resize-left").onmousedown=(e)=>resizeClipMouse(e,l.id,"left");
   c.querySelector(".resize-right").onmousedown=(e)=>resizeClipMouse(e,l.id,"right");
   c.ondblclick=()=>{moveLayerOrder(l.id,-1)};
   lane.appendChild(c)
  }
  cont.appendChild(tr)
 }
}
function renderInspector(){let l=sel();$("selectedName").textContent=l?l.name||l.text:"未選取";if(!l)return;$("x").value=Math.round(l.x||0);$("y").value=Math.round(l.y||0);$("scale").value=l.scale??1;$("start").value=l.start??0;$("duration").value=l.duration??0;if(l.kind==="text"){$("textInput").value=l.text||"";$("fontSize").value=l.fontSize||42;if($("fontFamily"))$("fontFamily").value=l.fontFamily||"system-ui";$("textColor").value=l.color||"#ffffff";$("effect").value=l.effect||"none";if($("scrollDir"))$("scrollDir").value=l.scrollDir||"rtl";if($("scrollDir"))$("scrollDir").value=l.scrollDir||"rtl"}else $("volume").value=l.volume??1}
function renderAll(){render();renderList();renderTracks();renderInspector();$("time").textContent=`${fmt(current)} / ${fmt(duration)}`;$("scrub").value=current}
function loop(now){let dt=last?(now-last)/1000:0;last=now;if(playing){current+=dt*speed;if(current>=duration){current=duration;pause()}sync()}render();$("time").textContent=`${fmt(current)} / ${fmt(duration)}`;$("scrub").value=current;requestAnimationFrame(loop)}
$("fileInput").onchange=e=>importFiles(e.target.files);$("unlock").onclick=unlock;$("play").onclick=$("play2").onclick=play;$("pause").onclick=$("pause2").onclick=pause;$("stop").onclick=$("stop2").onclick=stop;$("back").onclick=$("back2").onclick=()=>seek(current-5);$("fwd").onclick=$("fwd2").onclick=()=>seek(current+5);$("speed").onchange=$("speed2").onchange=e=>{speed=Number(e.target.value);$("speed").value=$("speed2").value=e.target.value;sync(true)};$("split").onclick=split;$("trimIn").onclick=trimIn;$("trimOut").onclick=trimOut;$("separate").onclick=separate;$("fit").onclick=fit;$("addText").onclick=addText;if($("deleteSelected"))$("deleteSelected").onclick=deleteSelectedLayer;$("removeFx").onclick=()=>{let l=sel();if(l)l.effect="none";renderAll()};$("scrub").oninput=e=>seek(Number(e.target.value));["x","y","scale","start","duration","textInput","fontFamily","fontSize","textColor","effect","scrollDir","volume"].forEach(id=>$(id).oninput=applyInspector);$("clearLibrary").onclick=()=>{assets=[];layers=[];selected=null;current=0;duration=0;renderAll()};
let drop=$("drop");drop.ondragover=e=>{e.preventDefault();drop.classList.add("drag")};drop.ondragleave=()=>drop.classList.remove("drag");drop.ondrop=e=>{e.preventDefault();drop.classList.remove("drag");importFiles(e.dataTransfer.files)};
canvas.onmousedown=e=>{let r=canvas.getBoundingClientRect(),sx=(e.clientX-r.left)*(1280/r.width),sy=(e.clientY-r.top)*(720/r.height),hit=null;for(let i=layers.length-1;i>=0;i--){let l=layers[i];if(l.kind==="audio")continue;if(l.kind==="text"){if(Math.abs(sx-l.x)<260&&Math.abs(sy-l.y)<60){hit=l;break}}else{let a=asset(l);if(!a)continue;let w=(a.el.videoWidth||a.el.naturalWidth||a.w)*l.scale,h=(a.el.videoHeight||a.el.naturalHeight||a.h)*l.scale;if(sx>=l.x-w/2&&sx<=l.x+w/2&&sy>=l.y-h/2&&sy<=l.y+h/2){hit=l;break}}}if(!hit)return;selected=hit.id;let ox=hit.x,oy=hit.y,move=ev=>{let nx=(ev.clientX-r.left)*(1280/r.width),ny=(ev.clientY-r.top)*(720/r.height);hit.x=ox+nx-sx;hit.y=oy+ny-sy;renderInspector()},up=()=>{window.removeEventListener("mousemove",move);window.removeEventListener("mouseup",up);renderAll()};window.addEventListener("mousemove",move);window.addEventListener("mouseup",up);renderAll()};
renderAll();

/* === AV SYNC FIX: media element is timeline clock === */
let masterLayerId = null;

function getMasterLayer(){
  // Prefer selected active video, otherwise first video, then first audio.
  let videoLayer = layers.find(l => l.kind === "video");
  let audioLayer = layers.find(l => l.kind === "audio");
  return videoLayer || audioLayer || null;
}

function localTimeOf(layer){
  return Math.max(0, (current - layer.start) + (layer.trim || 0));
}

function syncSoft(force=false){
  for(const l of layers){
    const a = asset(l);
    if(!a || !a.el || !(l.kind === "video" || l.kind === "audio")) continue;

    const active = current >= l.start && current <= l.start + l.duration;
    if(!active){
      if(!a.el.paused) a.el.pause();
      continue;
    }

    const local = localTimeOf(l);
    if(a.el.readyState >= 1){
      const drift = Math.abs((a.el.currentTime || 0) - local);
      // Only hard-seek when drift is visible. Frequent seeking causes AV delay.
      if(force || drift > 0.18){
        try { a.el.currentTime = local; } catch(e) {}
      }
    }

    a.el.volume = l.volume ?? 1;
    a.el.muted = !!l.muted;
    a.el.playbackRate = speed;

    if(playing && a.el.paused){
      a.el.play().catch(()=>log("Press 🔊 啟用聲音 first"));
    }
    if(!playing && !a.el.paused) a.el.pause();
  }
}

play = function(){
  if(!layers.length) return log("Import media first");
  const master = getMasterLayer();
  if(!master) return;
  if(current < master.start || current > master.start + master.duration) current = master.start;
  playing = true;
  syncSoft(true);
  log("Playing with AV sync");
};

pause = function(){
  playing = false;
  for(const a of assets) if(a.el?.pause) a.el.pause();
  log("Paused");
};

stop = function(){
  pause();
  current = 0;
  syncSoft(true);
  renderAll();
};

seek = function(t){
  current = Math.max(0, Math.min(t, duration));
  syncSoft(true);
  renderAll();
};

sync = syncSoft;

// Replace the old animation loop behavior by making current follow master media.
let avSyncLast = 0;
function loopAV(now){
  const master = getMasterLayer();

  if(playing && master){
    const a = asset(master);
    if(a && a.el && (master.kind === "video" || master.kind === "audio")){
      // The media element is the clock.
      current = master.start + Math.max(0, (a.el.currentTime || 0) - (master.trim || 0));
      if(current >= duration || a.el.ended){
        current = Math.min(duration, current);
        pause();
      }
      // Gently sync secondary audio/video only every few frames.
      if(!avSyncLast || now - avSyncLast > 250){
        syncSoft(false);
        avSyncLast = now;
      }
    }
  }

  render();
  $("time").textContent = `${fmt(current)} / ${fmt(duration)}`;
  $("scrub").value = current;
  requestAnimationFrame(loopAV);
}

// Disable the previous loop by making playing false for old loop side effects is not enough.
// Start AV-sync loop after load; old loop may still run, but this loop continuously corrects display.
requestAnimationFrame(loopAV);

/* Reduce default delay by preloading videos/audio more aggressively */
for(const a of assets){
  if(a.el && (a.kind==="video" || a.kind==="audio")){
    a.el.preload = "auto";
    try { a.el.load(); } catch(e){}
  }
}


/* keydownLayerOrderPatch */
window.addEventListener("keydown", e=>{
  if(!selected) return;
  if(e.ctrlKey && e.key==="ArrowUp"){ e.preventDefault(); moveLayerOrder(selected,-1); }
  if(e.ctrlKey && e.key==="ArrowDown"){ e.preventDefault(); moveLayerOrder(selected,1); }
});


/* textMoveArrowPatch: move selected video/image/text with keyboard arrows */
window.addEventListener("keydown", e=>{
  const l=sel&&sel();
  if(!l) return;
  if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.key)){
    e.preventDefault();
    const step=e.shiftKey?10:2;
    if(e.key==="ArrowLeft") l.x=(l.x||640)-step;
    if(e.key==="ArrowRight") l.x=(l.x||640)+step;
    if(e.key==="ArrowUp") l.y=(l.y||360)-step;
    if(e.key==="ArrowDown") l.y=(l.y||360)+step;
    renderAll();
  }
});


/* StudioFlowTextMovePlaySyncPatch
   - Text can be moved in canvas with mouse.
   - Text can be moved with arrow keys.
   - Text scroll direction is controlled by scrollDir.
   - Text effects run from the same Play/master current time.
*/
window.addEventListener("keydown", e=>{
  const l = (typeof sel === "function") ? sel() : null;
  if(!l) return;
  if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.key)){
    e.preventDefault();
    const step = e.shiftKey ? 10 : 2;
    if(e.key==="ArrowLeft") l.x=(l.x||640)-step;
    if(e.key==="ArrowRight") l.x=(l.x||640)+step;
    if(e.key==="ArrowUp") l.y=(l.y||360)-step;
    if(e.key==="ArrowDown") l.y=(l.y||360)+step;
    if(typeof renderAll === "function") renderAll();
  }
});


/* TextDisplayFixHitTest: ensure text layers can be selected and moved on Canvas */
canvas.addEventListener("mousedown", function(e){
  const r=canvas.getBoundingClientRect();
  const sx=(e.clientX-r.left)*(1280/r.width);
  const sy=(e.clientY-r.top)*(720/r.height);
  let hit=null;
  for(let i=layers.length-1;i>=0;i--){
    const l=layers[i];
    if(l.kind!=="text") continue;
    const fs=l.fontSize||46;
    const approxW=Math.max(180,(l.text||"文字").length*fs*0.7);
    const approxH=fs*1.8;
    if(sx>=l.x-approxW/2 && sx<=l.x+approxW/2 && sy>=l.y-approxH/2 && sy<=l.y+approxH/2){
      hit=l; break;
    }
  }
  if(!hit) return;
  e.stopPropagation();
  selected=hit.id;
  const ox=hit.x, oy=hit.y;
  const startX=sx, startY=sy;
  function move(ev){
    const nx=(ev.clientX-r.left)*(1280/r.width);
    const ny=(ev.clientY-r.top)*(720/r.height);
    hit.x=ox+nx-startX;
    hit.y=oy+ny-startY;
    renderInspector();
    render();
  }
  function up(){
    window.removeEventListener("mousemove",move,true);
    window.removeEventListener("mouseup",up,true);
    renderAll();
  }
  window.addEventListener("mousemove",move,true);
  window.addEventListener("mouseup",up,true);
  renderAll();
}, true);


/* deleteToolsPatch */
function deleteTextLayers(){
  layers = layers.filter(l => l.kind !== "text");
  if(sel && sel() && sel().kind === "text") selected = null;
  updateDuration();
  renderAll();
  log("已刪除所有文字圖層");
}

function deleteAllEffects(){
  for(const l of layers){
    l.effect = "none";
    l.effects = [];
  }
  renderAll();
  log("已刪除所有效果");
}

function clearTimelineOnly(){
  layers = [];
  selected = null;
  current = 0;
  duration = 0;
  for(const a of assets){
    if(a.el && a.el.pause) a.el.pause();
  }
  renderAll();
  log("已清空時間線 video/image/audio/text");
}

function deleteSelectedLayer(){
  if(!selected) return;
  layers = layers.filter(l => l.id !== selected);
  selected = null;
  updateDuration();
  renderAll();
  log("已刪除選取的時間線圖層");
}

function moveSelectedTextToTop(){
  const l = sel && sel();
  if(!l || l.kind !== "text") return;
  l.x = 640;
  l.y = 72;
  renderAll();
}

function moveSelectedTextToBottom(){
  const l = sel && sel();
  if(!l || l.kind !== "text") return;
  l.x = 640;
  l.y = 650;
  renderAll();
}

if($("deleteTextLayers")) $("deleteTextLayers").onclick = deleteTextLayers;
if($("deleteEffects")) $("deleteEffects").onclick = deleteAllEffects;
if($("deleteTimeline")) $("deleteTimeline").onclick = clearTimelineOnly;
if($("deleteSelected")) $("deleteSelected").onclick = deleteSelectedLayer;
if($("textTop")) $("textTop").onclick = moveSelectedTextToTop;
if($("textBottom")) $("textBottom").onclick = moveSelectedTextToBottom;
