# StudioFlow v7 Text Top Overlay + Delete Tools

本版保留目前所有功能，並修正文字顯示與新增刪除工具。

## 修正文字顯示

- Text 永遠顯示在 Video / Image / GIF 最上層。
- 新增文字預設顯示在影片上方中央。
- TXT / SRT / VTT 匯入後會同步顯示在影片 Canvas 上。
- Audio 名稱不再顯示在影片畫面中，只保留在 Timeline。
- 文字可用滑鼠拖曳上下左右移動。
- 文字可用右側 X / Y 調整位置。
- Scroll 可切換：
  - 右 → 左
  - 左 → 右
- Scroll / Fade / Bounce 與同一個 Play 按鈕同步播放。

## 新增刪除功能

### 刪除選取圖層

可刪除目前選取的：

- Video clip
- Image clip
- Audio clip
- Text clip

### 刪除所有文字

一鍵刪除全部 Text / TXT / SRT / VTT 圖層。

### 刪除所有效果

一鍵清除所有文字效果與 layer effects。

### 清空時間線

一鍵清空 Timeline 上的：

- Video
- Image
- Audio
- Text

不會刪除電腦原始檔案。

## 保留功能

- 媒體匯入
- TXT 匯入
- 播放 / 暫停 / 停止
- 快轉 / 倒退
- Split
- Trim In / Trim Out
- 分離影音
- 時間軸 clip 拖曳
- 時間軸 clip 拉長 / 縮短
- 影片 / 圖片 / 文字 Canvas 拖曳
- 16:9 預覽
- AV Sync 修正
