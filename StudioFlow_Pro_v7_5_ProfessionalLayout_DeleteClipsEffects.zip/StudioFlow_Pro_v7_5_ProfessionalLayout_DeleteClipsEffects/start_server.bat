@echo off
title StudioFlow Pro v7.5 Professional Layout
python -m http.server 8000
pause
