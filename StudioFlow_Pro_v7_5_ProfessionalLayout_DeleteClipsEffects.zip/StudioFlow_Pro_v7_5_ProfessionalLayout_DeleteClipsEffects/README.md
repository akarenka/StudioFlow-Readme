# StudioFlow Pro v7.5 Professional Layout + Delete Clips / Effects

基於目前 NoText AVSplit Chroma 版本製作。

## 保留並實裝

- 影音分離 Separate Audio
- 綠幕 Chroma Key
- Video × 5
- Audio × 3
- 多軌 Timeline
- Clip Move 拖曳
- Clip Resize 左右縮放
- Trim In
- Trim Out
- Split
- Drag & Drop 匯入素材
- Export WebM
- Export MP4
- Export MP3

## 版面修正

- 縮小 Preview 螢幕
- 加寬 Timeline
- Timeline 高度增加
- 更適合多軌剪輯

## 新增刪除功能

- Delete selected clip
- Delete linked split clips
- Delete all video/image clips
- Delete all audio clips
- Delete all timeline clips
- Delete selected clip effects
- Delete all effects

## 使用

```text
start_server.bat
http://localhost:8000
```

MP4 / MP3 需要 localhost 與 FFmpeg.wasm。
