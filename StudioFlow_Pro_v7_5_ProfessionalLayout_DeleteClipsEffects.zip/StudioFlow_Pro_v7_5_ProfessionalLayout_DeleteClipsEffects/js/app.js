(() => {
"use strict";
const $ = id => document.getElementById(id);
const canvas = $("canvas");
const ctx = canvas.getContext("2d");

const DB_NAME = "StudioFlow_v73_NoText_AVSplit_DB";
const STORE = "files";
let dbp = null;

let assets = [];
let layers = [];
let selected = null;
let selectedAsset = null;
let current = 0;
let duration = 20;
let playing = false;
let speed = 1;
let filter = "all";
let undoStack = [];

const secPerPx = 1 / 90;

const rows = [
  {label:"▦ Video 1", type:"video"},
  {label:"▦ Video 2", type:"video"},
  {label:"▦ Video 3", type:"video"},
  {label:"▦ Video 4", type:"video"},
  {label:"▦ Video 5", type:"video"},
  {label:"♫ Audio 1", type:"audio"},
  {label:"♫ Audio 2", type:"audio"},
  {label:"♫ Audio 3", type:"audio"}
];

function uid(){return"sf_"+Math.random().toString(36).slice(2)+Date.now().toString(36)}
function ext(n){return(n||"").split(".").pop().toLowerCase()}
function fmt(t){t=Math.max(0,t||0);let m=Math.floor(t/60),s=Math.floor(t%60),h=Math.floor((t%1)*100);return`00:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(h).padStart(2,"0")}`}
function clipEnd(l){return(+l.start||0)+(+l.duration||0)}
function calcDuration(){return Math.max(20,...layers.map(clipEnd))}
function kindOf(file){let e=ext(file.name);if(file.type.startsWith("video/")||["mp4","avi","mov","webm","mkv","m4v"].includes(e))return"video";if(file.type.startsWith("audio/")||["mp3","wav","m4a","aac","ogg","flac"].includes(e))return"audio";return"image"}
function icon(k){return k==="video"?"🎞":k==="audio"?"♫":"🖼"}
function rowForKind(k){return k==="audio"?5:k==="image"?0:0}
function validRow(k,row){return rows[row]?.type===k || (k==="image"&&rows[row]?.type==="video")}
function snapTime(t){return $("snapToggle")?.checked?Math.round(t*10)/10:t}
function pushUndo(){try{undoStack.push(JSON.stringify({layers,current,duration}));if(undoStack.length>80)undoStack.shift()}catch(e){}}

function openDB(){if(dbp)return dbp;dbp=new Promise((res,rej)=>{let r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{let db=r.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:"id"})};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});return dbp}
async function putRec(rec){let db=await openDB();return new Promise((res,rej)=>{let tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).put(rec);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
async function getRec(id){let db=await openDB();return new Promise((res,rej)=>{let tx=db.transaction(STORE,"readonly"),r=tx.objectStore(STORE).get(id);r.onsuccess=()=>res(r.result||null);r.onerror=()=>rej(r.error)})}
async function clearDB(){let db=await openDB();return new Promise((res,rej)=>{let tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).clear();tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}

async function hydrate(a){
  if(a.el&&a.url)return a;
  if(!a.dbId)return a;
  let rec=await getRec(a.dbId);
  if(!rec)return a;
  let url=URL.createObjectURL(rec.blob);
  a.url=url;
  if(a.kind==="video"){
    let v=document.createElement("video");v.src=url;v.preload="auto";v.playsInline=true;v.volume=+$("volume").value;a.el=v;
    await new Promise(r=>{v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:a.duration||5;a.w=v.videoWidth||a.w||1920;a.h=v.videoHeight||a.h||1080;r()};v.onerror=r;v.load()});
  }else if(a.kind==="audio"){
    let au=document.createElement("audio");au.src=url;au.preload="auto";au.volume=+$("volume").value;a.el=au;
    await new Promise(r=>{au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:a.duration||5;r()};au.onerror=r;au.load()});
  }else{
    let img=new Image();img.src=url;a.el=img;
    await new Promise(r=>{img.onload=()=>{a.w=img.naturalWidth||a.w||1920;a.h=img.naturalHeight||a.h||1080;r()};img.onerror=r});
  }
  return a;
}

function saveManifest(){
  localStorage.setItem("studioflow_notext_manifest",JSON.stringify({
    assets:assets.map(a=>({id:a.id,dbId:a.dbId,name:a.name,kind:a.kind,duration:a.duration,w:a.w,h:a.h,type:a.type})),
    layers,current,duration
  }));
}
async function restoreBin(){
  let raw=localStorage.getItem("studioflow_notext_manifest");
  if(!raw)return alert("No saved bin.");
  let data=JSON.parse(raw);
  assets=data.assets||[];
  layers=data.layers||[];
  current=data.current||0;
  for(let a of assets)await hydrate(a);
  duration=calcDuration();
  renderAll();
}

async function importFiles(files){
  for(const file of Array.from(files||[])){
    let kind=kindOf(file),dbId=uid(),blob=file.slice(0,file.size,file.type||"application/octet-stream");
    await putRec({id:dbId,name:file.name,type:file.type,size:file.size,kind,blob,createdAt:new Date().toISOString()});
    let url=URL.createObjectURL(blob);
    let a={id:uid(),dbId,name:file.name,kind,type:file.type,url,duration:5,w:1920,h:1080,el:null};
    if(kind==="video"){
      let v=document.createElement("video");v.src=url;v.preload="auto";v.playsInline=true;v.volume=+$("volume").value;a.el=v;
      await new Promise(r=>{v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:5;a.w=v.videoWidth||1920;a.h=v.videoHeight||1080;r()};v.onerror=r;v.load()});
    }else if(kind==="audio"){
      let au=document.createElement("audio");au.src=url;au.preload="auto";au.volume=+$("volume").value;a.el=au;
      await new Promise(r=>{au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:5;r()};au.onerror=r;au.load()});
    }else{
      let img=new Image();img.src=url;a.el=img;
      await new Promise(r=>{img.onload=()=>{a.w=img.naturalWidth||1920;a.h=img.naturalHeight||1080;r()};img.onerror=r});
    }
    assets.push(a);
    addLayerFromAsset(a);
  }
  duration=calcDuration();
  saveManifest();
  renderAll();
}

function addLayerFromAsset(a){
  pushUndo();
  let kind=a.kind==="audio"?"audio":a.kind==="image"?"image":"video";
  let l={id:uid(),assetId:a.id,name:a.name,kind,start:0,duration:kind==="image"?Math.max(5,duration||5):a.duration||5,trim:0,x:960,y:540,scale:1,muted:false,volume:1,row:rowForKind(kind),z:layers.length,chroma:false,chromaColor:"#00ff00",chromaTolerance:70};
  if(kind==="image")l.scale=Math.min(1920/(a.w||1920),1080/(a.h||1080));
  layers.push(l);
  selected=l.id;
  duration=calcDuration();
}

function assetOf(l){return assets.find(a=>a.id===l?.assetId)}
function active(l){return current>=l.start&&current<=l.start+l.duration}
function activePlayable(){return layers.filter(l=>(l.kind==="video"||l.kind==="audio")&&active(l)).sort((a,b)=>(a.kind==="video"?0:1)-(b.kind==="video"?0:1)||a.row-b.row||a.start-b.start)}
function master(){let a=activePlayable();return a.find(l=>l.kind==="video")||a.find(l=>l.kind==="audio")||layers.filter(l=>l.kind==="video"||l.kind==="audio").sort((a,b)=>a.start-b.start)[0]||null}
function hasSplit(v){return!!(v&&v.linkedGroup&&layers.some(l=>l.kind==="audio"&&l.linkedGroup===v.linkedGroup))}

async function separateAudio(){
  let v=layers.find(l=>l.id===selected&&l.kind==="video")||layers.find(l=>l.kind==="video");
  if(!v)return alert("Select or import a video first.");
  if(hasSplit(v)){selected=layers.find(l=>l.kind==="audio"&&l.linkedGroup===v.linkedGroup).id;renderAll();return}
  pushUndo();
  let src=assetOf(v);await hydrate(src);
  let rec=src.dbId?await getRec(src.dbId):null;
  let url=rec?.blob?URL.createObjectURL(rec.blob):src.url;
  let el=document.createElement("video");el.src=url;el.preload="auto";el.playsInline=true;el.muted=false;el.volume=+$("volume").value;
  let a={id:uid(),dbId:src.dbId,name:"Separated Audio - "+src.name,kind:"audio",url,duration:src.duration||v.duration,w:0,h:0,el,sourceVideoAssetId:src.id};
  assets.push(a);
  let group=uid();v.linkedGroup=group;v.muted=true;v.splitSource=true;
  let layer={id:uid(),assetId:a.id,name:a.name,kind:"audio",start:v.start,duration:v.duration,trim:v.trim||0,x:0,y:0,scale:1,volume:1,muted:false,row:6,linkedGroup:group,independentAfterSplit:true,splitAudio:true,z:layers.length};
  layers.push(layer);selected=layer.id;duration=calcDuration();saveManifest();sync(true);renderAll();
}

function sync(force=false){
  let vol=+$("volume").value,rate=+($("speed").value||1);
  for(const l of layers){
    if(l.kind!=="video"&&l.kind!=="audio")continue;
    let a=assetOf(l);if(!a?.el)continue;
    if(!active(l)){if(!a.el.paused)a.el.pause();continue}
    let target=Math.max(0,current-l.start+(l.trim||0)),drift=Math.abs((a.el.currentTime||0)-target);
    if(a.el.readyState>=1&&(force||drift>.55))try{a.el.currentTime=target}catch{}
    try{a.el.playbackRate=rate}catch{}
    a.el.volume=l.kind==="audio"?vol*(l.volume??1):vol;
    a.el.muted=!!l.muted;
    if(playing&&a.el.paused)a.el.play().catch(()=>{});
    if(!playing&&!a.el.paused)a.el.pause();
  }
}
function play(){if(!layers.length)return;duration=calcDuration();playing=true;sync(true)}
function pause(){playing=false;for(const a of assets)if(a.el?.pause)a.el.pause()}
function stop(){pause();current=0;sync(true);renderAll()}
function seek(t){duration=calcDuration();current=Math.max(0,Math.min(+t||0,duration));sync(true);renderAll()}

function trimIn(){
  let l=layers.find(x=>x.id===selected);if(!l||current<=l.start||current>=clipEnd(l))return;
  pushUndo();let d=current-l.start;l.start=current;l.duration=Math.max(.5,l.duration-d);if(l.kind==="video"||l.kind==="audio")l.trim=(l.trim||0)+d;duration=calcDuration();renderAll();saveManifest();
}
function trimOut(){
  let l=layers.find(x=>x.id===selected);if(!l||current<=l.start||current>=clipEnd(l))return;
  pushUndo();l.duration=Math.max(.5,current-l.start);duration=calcDuration();renderAll();saveManifest();
}
function split(){
  let l=layers.find(x=>x.id===selected);if(!l||current<=l.start||current>=clipEnd(l))return;
  pushUndo();let left=current-l.start,right=l.duration-left,copy={...l,id:uid(),start:current,duration:right,trim:(l.trim||0)+left,z:l.z+1};l.duration=left;layers.push(copy);selected=copy.id;renderAll();saveManifest();
}
function duplicate(){let l=layers.find(x=>x.id===selected);if(!l)return;pushUndo();let c={...l,id:uid(),start:l.start+1,z:layers.length};layers.push(c);selected=c.id;renderAll();saveManifest()}

function drawChroma(source,x,y,w,h,l){
  if(!l.chroma){ctx.drawImage(source,x,y,w,h);return}
  let tmp=document.createElement("canvas");tmp.width=Math.max(1,Math.round(w));tmp.height=Math.max(1,Math.round(h));let t=tmp.getContext("2d",{willReadFrequently:true});
  try{
    t.drawImage(source,0,0,tmp.width,tmp.height);
    let img=t.getImageData(0,0,tmp.width,tmp.height),d=img.data,hex=l.chromaColor||"#00ff00",key=[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)],tol=+(l.chromaTolerance||70);
    for(let i=0;i<d.length;i+=4){let dr=d[i]-key[0],dg=d[i+1]-key[1],db=d[i+2]-key[2];if(Math.sqrt(dr*dr+dg*dg+db*db)<tol)d[i+3]=0}
    t.putImageData(img,0,0);ctx.drawImage(tmp,x,y,w,h);
  }catch(e){ctx.drawImage(source,x,y,w,h)}
}
function render(){
  ctx.clearRect(0,0,1920,1080);ctx.fillStyle="#000";ctx.fillRect(0,0,1920,1080);
  let visuals=layers.filter(l=>active(l)&&(l.kind==="video"||l.kind==="image")).sort((a,b)=>a.z-b.z);
  for(const l of visuals){
    let a=assetOf(l);if(!a?.el)continue;
    let w=(a.el.videoWidth||a.el.naturalWidth||a.w||1920)*(l.scale||1),h=(a.el.videoHeight||a.el.naturalHeight||a.h||1080)*(l.scale||1);
    try{drawChroma(a.el,l.x-w/2,l.y-h/2,w,h,l)}catch{}
  }
}

function renderMedia(){
  let q=($("mediaSearch").value||"").toLowerCase(),box=$("mediaList");box.innerHTML="";
  let list=assets.filter(a=>(filter==="all"||a.kind===filter)&&(!q||a.name.toLowerCase().includes(q)));
  $("assetCount").textContent=`${assets.length} copied assets · NoText`;
  for(const a of list){
    let card=document.createElement("div");card.className="media-card"+(a.id===selectedAsset?" selected":"");
    let th=document.createElement("div");th.className="thumb";
    if(a.kind==="image"&&a.url){let img=new Image();img.src=a.url;img.className="thumb";th=img}
    else if(a.kind==="video"&&a.url){let v=document.createElement("video");v.src=a.url;v.muted=true;v.preload="metadata";v.className="thumb";th=v}
    else th.textContent=icon(a.kind);
    let meta=document.createElement("div");meta.className="media-meta";meta.innerHTML=`<b>${a.name}</b><small>${fmt(a.duration||0)}</small><small>${a.w||1920}x${a.h||1080}</small>`;
    card.append(th,meta);card.onclick=async()=>{selectedAsset=a.id;await hydrate(a);let l=layers.find(x=>x.assetId===a.id);if(!l)addLayerFromAsset(a);l=layers.find(x=>x.assetId===a.id);if(l){selected=l.id;current=l.start;seek(current)}renderAll()};box.appendChild(card);
  }
}
function renderRuler(){let r=$("timeRuler");r.innerHTML="";let total=Math.ceil(duration);for(let s=0;s<=total;s+=2){let d=document.createElement("div");d.className="tick";d.style.left=(s/secPerPx)+"px";d.textContent="00:"+String(s).padStart(2,"0");r.appendChild(d)}}
function renderTrackHeads(){let h=$("trackHeads");h.innerHTML=rows.map(r=>`<div class="track-title">${r.label}<span>👁 🔒</span></div>`).join("")}
function renderTracks(){
  let cont=$("tracks");cont.innerHTML="";let width=Math.max(1200,duration/secPerPx+200);cont.style.width=width+"px";$("timeRuler").style.width=width+"px";
  rows.forEach((row,idx)=>{let lane=document.createElement("div");lane.className="track-lane";lane.style.width=width+"px";for(const l of layers.filter(x=>x.row===idx)){let c=document.createElement("div");c.className="clip "+l.kind+(l.id===selected?" selected":"")+(l.splitAudio?" split-audio":"")+(l.splitSource?" split-source":"");c.style.left=(l.start/secPerPx)+"px";c.style.width=Math.max(60,l.duration/secPerPx)+"px";c.innerHTML=`<span class="resize-l"></span>${l.kind==="audio"?"♫":l.kind==="image"?"▧":"▦"}&nbsp; ${l.name}<span class="resize-r"></span>`;c.onclick=e=>{e.stopPropagation();selected=l.id;loadInspector(l);renderAll()};c.querySelector(".resize-l").onmousedown=e=>resizeClip(e,l,"left");c.querySelector(".resize-r").onmousedown=e=>resizeClip(e,l,"right");c.onmousedown=e=>{if(e.target.className.includes("resize"))return;dragClip(e,l)};lane.appendChild(c)}cont.appendChild(lane)});
  let ph=document.createElement("div");ph.className="playhead";ph.style.left=(current/secPerPx)+"px";cont.appendChild(ph);
}
function resizeClip(e,l,side){e.preventDefault();e.stopPropagation();pushUndo();let sx=e.clientX,os=l.start,od=l.duration,ot=l.trim||0;function mv(ev){let ds=(ev.clientX-sx)*secPerPx;if(side==="right")l.duration=Math.max(.5,od+ds);else{l.start=snapTime(Math.max(0,os+ds));l.duration=Math.max(.5,od-ds);if(l.kind==="video"||l.kind==="audio")l.trim=Math.max(0,ot+(l.start-os))}duration=calcDuration();renderAll()}function up(){removeEventListener("mousemove",mv);removeEventListener("mouseup",up);saveManifest()}addEventListener("mousemove",mv);addEventListener("mouseup",up)}
function dragClip(e,l){e.preventDefault();pushUndo();let sx=e.clientX,sy=e.clientY,os=l.start,or=l.row;function mv(ev){let old=l.start;l.start=snapTime(Math.max(0,os+(ev.clientX-sx)*secPerPx));let nr=Math.max(0,Math.min(rows.length-1,or+Math.round((ev.clientY-sy)/42)));if(validRow(l.kind,nr))l.row=nr;if($("rippleMove").checked){let delta=l.start-old;for(const o of layers)if(o.id!==l.id&&o.row===l.row&&o.start>=old)o.start=Math.max(0,o.start+delta)}duration=calcDuration();renderAll()}function up(){removeEventListener("mousemove",mv);removeEventListener("mouseup",up);saveManifest()}addEventListener("mousemove",mv);addEventListener("mouseup",up)}
function loadInspector(l){$("selectedInfo").textContent=l?`${l.kind.toUpperCase()} · ${l.name}`:"No clip selected";$("xInput").value=Math.round(l.x||0);$("yInput").value=Math.round(l.y||0);$("scaleInput").value=l.scale||1;$("startInput").value=l.start||0;$("durationInput").value=l.duration||0;$("clipVolume").value=l.volume??1;$("chromaOn").checked=!!l.chroma;$("chromaColor").value=l.chromaColor||"#00ff00";$("chromaTolerance").value=l.chromaTolerance||70}
function applyInspector(){let l=layers.find(x=>x.id===selected);if(!l)return;l.x=+$("xInput").value;l.y=+$("yInput").value;l.scale=+$("scaleInput").value;l.start=+$("startInput").value;l.duration=+$("durationInput").value;l.volume=+$("clipVolume").value;l.chroma=$("chromaOn").checked;l.chromaColor=$("chromaColor").value;l.chromaTolerance=+$("chromaTolerance").value;duration=calcDuration();renderAll()}
function renderAll(){duration=calcDuration();render();renderMedia();renderTrackHeads();renderRuler();renderTracks();$("scrubber").max=duration;$("scrubber").value=current;$("timeLabel").textContent=`${fmt(current)} / ${fmt(duration)}`;$("durStatus").textContent=`Duration: ${fmt(duration)}`}
function loop(){if(playing){let m=master();if(m&&active(m)){let a=assetOf(m);if(a?.el)current=m.start+Math.max(0,(a.el.currentTime||0)-(m.trim||0));else current+=1/60}else current+=1/60;if(current>=duration){current=duration;pause()}sync(false)}render();$("scrubber").value=current;$("timeLabel").textContent=`${fmt(current)} / ${fmt(duration)}`;drawWaveform();requestAnimationFrame(loop)}
function drawWaveform(){let c=$("waveformCanvas");if(!c)return;let g=c.getContext("2d"),w=c.width,h=c.height;g.clearRect(0,0,w,h);g.fillStyle="#06111f";g.fillRect(0,0,w,h);g.strokeStyle="#0ea5e9";g.beginPath();for(let x=0;x<w;x++){let amp=Math.sin(x*.08+current)*Math.sin(x*.023)*.45+.5,y=h/2+(amp-.5)*h*.8;if(x===0)g.moveTo(x,y);else g.lineTo(x,y)}g.stroke()}

async function recordWebM(){let stream=canvas.captureStream(30),chunks=[],old=current,was=playing;seek(0);play();let rec=new MediaRecorder(stream,{mimeType:MediaRecorder.isTypeSupported("video/webm;codecs=vp9")?"video/webm;codecs=vp9":"video/webm"});rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};let done=new Promise(r=>rec.onstop=()=>r(new Blob(chunks,{type:"video/webm"})));rec.start(250);setTimeout(()=>rec.stop(),Math.max(1,duration)*1000);let blob=await done;pause();seek(old);if(was)play();return blob}
function download(blob,name){let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000)}
async function getFF(){if(location.protocol==="file:")throw Error("MP4/MP3 needs localhost. Run start_server.bat");let {FFmpeg}=window.FFmpegWASM;let ff=new FFmpeg();await ff.load();return ff}
async function exportWebM(){download(await recordWebM(),"studioflow_notext.webm")}
async function exportMP4(){try{let webm=await recordWebM(),ff=await getFF();await ff.writeFile("in.webm",new Uint8Array(await webm.arrayBuffer()));await ff.exec(["-i","in.webm","-c:v","libx264","-pix_fmt","yuv420p","-preset","veryfast","-crf","23","-movflags","+faststart","out.mp4"]);let data=await ff.readFile("out.mp4");download(new Blob([data.buffer],{type:"video/mp4"}),"studioflow_notext.mp4")}catch(e){alert(e.message+"\\nExporting WebM fallback.");exportWebM()}}
async function exportMP3(){try{let webm=await recordWebM(),ff=await getFF();await ff.writeFile("in.webm",new Uint8Array(await webm.arrayBuffer()));await ff.exec(["-i","in.webm","-vn","-acodec","libmp3lame","-b:a","192k","out.mp3"]);let data=await ff.readFile("out.mp3");download(new Blob([data.buffer],{type:"audio/mpeg"}),"studioflow_notext.mp3")}catch(e){alert("MP3 export failed: "+e.message)}}
function saveProject(){saveManifest();download(new Blob([JSON.stringify({assets:assets.map(a=>({id:a.id,dbId:a.dbId,name:a.name,kind:a.kind,duration:a.duration,w:a.w,h:a.h,type:a.type})),layers,current,duration},null,2)],{type:"application/json"}),"project.studioflow")}

function bind(){
  $("fileInput").onchange=e=>importFiles(e.target.files);
  let dz=$("dropZone");dz.onclick=()=>$("fileInput").click();dz.ondragover=e=>{e.preventDefault();dz.style.borderColor="#8b5cf6"};dz.ondragleave=()=>dz.style.borderColor="#34506e";dz.ondrop=e=>{e.preventDefault();dz.style.borderColor="#34506e";importFiles(e.dataTransfer.files)};
  document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tabs button").forEach(x=>x.classList.remove("active"));b.classList.add("active");filter=b.dataset.filter;renderMedia()});
  $("mediaSearch").oninput=renderMedia;$("restoreBin").onclick=restoreBin;$("clearBin").onclick=async()=>{await clearDB();assets=[];layers=[];selected=null;localStorage.removeItem("studioflow_notext_manifest");renderAll()};
  $("play").onclick=play;$("pause").onclick=pause;$("stop").onclick=stop;$("back").onclick=()=>seek(current-5);$("forward").onclick=()=>seek(current+5);$("speed").onchange=e=>{speed=+e.target.value;sync(true)};$("volume").oninput=()=>sync(true);$("scrubber").oninput=e=>seek(+e.target.value);
  $("split").onclick=split;$("trimIn").onclick=trimIn;$("trimOut").onclick=trimOut;$("duplicate").onclick=duplicate;$("deleteSelected").onclick=()=>{pushUndo();layers=layers.filter(l=>l.id!==selected);selected=null;renderAll()};$("bringFront").onclick=()=>{let l=layers.find(x=>x.id===selected);if(l){l.z=999;renderAll()}};$("sendBack").onclick=()=>{let l=layers.find(x=>x.id===selected);if(l){l.z=0;renderAll()}};$("zoomFit").onclick=renderAll;
  $("separateAudio").onclick=separateAudio;$("saveProject").onclick=saveProject;$("exportWebM").onclick=exportWebM;$("exportMP4").onclick=exportMP4;$("exportMP3").onclick=exportMP3;$("sideExportWebM").onclick=exportWebM;$("sideExportMP4").onclick=exportMP4;$("sideExportMP3").onclick=exportMP3;
  ["xInput","yInput","scaleInput","startInput","durationInput","clipVolume","chromaOn","chromaColor","chromaTolerance"].forEach(id=>$(id).oninput=applyInspector);
  ["mixA1","mixA2","mixA3"].forEach((id,idx)=>$(id).oninput=()=>{[5,6,7].forEach((row,i)=>{if(i===idx)for(const l of layers.filter(x=>x.kind==="audio"&&x.row===row))l.volume=+$(id).value})});
  renderAll();requestAnimationFrame(loop);
}
document.addEventListener("DOMContentLoaded",bind);
})();

/* v7.5 Professional Layout + Delete Clips / Effects */
(function(){
  const Q = id => document.getElementById(id);

  function selectedLayer(){
    return layers.find(l => l.id === selected) || null;
  }

  function saveIfPossible(){
    try{ saveManifest(); }catch(e){}
  }

  function deleteSelectedClip(){
    if(!selected) return;
    if(!confirm("Delete selected clip?")) return;
    pushUndo?.();
    layers = layers.filter(l => l.id !== selected);
    selected = null;
    duration = calcDuration();
    renderAll();
    saveIfPossible();
  }

  function deleteSelectedLinkedClips(){
    const l = selectedLayer();
    if(!l) return;
    pushUndo?.();

    if(l.linkedGroup){
      if(!confirm("Delete linked split video/audio clips?")) return;
      layers = layers.filter(x => x.linkedGroup !== l.linkedGroup && x.id !== l.id);
    }else{
      if(!confirm("Delete selected clip?")) return;
      layers = layers.filter(x => x.id !== l.id);
    }

    selected = null;
    duration = calcDuration();
    renderAll();
    saveIfPossible();
  }

  function clearVideoClips(){
    if(!confirm("Delete all video/image clips?")) return;
    pushUndo?.();
    layers = layers.filter(l => l.kind !== "video" && l.kind !== "image");
    selected = null;
    duration = calcDuration();
    renderAll();
    saveIfPossible();
  }

  function clearAudioClips(){
    if(!confirm("Delete all audio clips?")) return;
    pushUndo?.();
    layers = layers.filter(l => l.kind !== "audio");
    for(const l of layers){
      if(l.kind === "video"){
        l.muted = false;
        l.linkedGroup = null;
        l.splitSource = false;
      }
    }
    selected = null;
    duration = calcDuration();
    renderAll();
    saveIfPossible();
  }

  function clearAllClips(){
    if(!confirm("Delete all timeline clips? Media Bin will remain.")) return;
    pushUndo?.();
    layers = [];
    selected = null;
    duration = calcDuration();
    stop?.();
    renderAll();
    saveIfPossible();
  }

  function deleteClipEffects(){
    const l = selectedLayer();
    if(!l) return;
    pushUndo?.();

    l.chroma = false;
    l.chromaColor = "#00ff00";
    l.chromaTolerance = 70;
    l.transition = "none";
    l.lut = "none";
    l.effects = [];
    l.keyframes = [];
    l.proxy = false;

    if(Q("chromaOn")) Q("chromaOn").checked = false;
    if(Q("chromaColor")) Q("chromaColor").value = "#00ff00";
    if(Q("chromaTolerance")) Q("chromaTolerance").value = 70;

    renderAll();
    saveIfPossible();
  }

  function clearAllEffects(){
    if(!confirm("Delete all effects from all clips?")) return;
    pushUndo?.();
    for(const l of layers){
      l.chroma = false;
      l.chromaColor = "#00ff00";
      l.chromaTolerance = 70;
      l.transition = "none";
      l.lut = "none";
      l.effects = [];
      l.keyframes = [];
      l.proxy = false;
    }
    renderAll();
    saveIfPossible();
  }

  function trimInPro(){
    const l = selectedLayer();
    if(!l || current <= l.start || current >= l.start + l.duration) return;
    pushUndo?.();
    const delta = current - l.start;
    l.start = current;
    l.duration = Math.max(.5, l.duration - delta);
    if(l.kind === "video" || l.kind === "audio") l.trim = Math.max(0, (l.trim || 0) + delta);
    duration = calcDuration();
    renderAll();
    saveIfPossible();
  }

  function trimOutPro(){
    const l = selectedLayer();
    if(!l || current <= l.start || current >= l.start + l.duration) return;
    pushUndo?.();
    l.duration = Math.max(.5, current - l.start);
    duration = calcDuration();
    renderAll();
    saveIfPossible();
  }

  function bindV75(){
    if(Q("deleteSelected")) Q("deleteSelected").onclick = deleteSelectedClip;
    if(Q("deleteSelectedClips")) Q("deleteSelectedClips").onclick = deleteSelectedLinkedClips;
    if(Q("deleteEffects")) Q("deleteEffects").onclick = deleteClipEffects;
    if(Q("clearVideoClips")) Q("clearVideoClips").onclick = clearVideoClips;
    if(Q("clearAudioClips")) Q("clearAudioClips").onclick = clearAudioClips;
    if(Q("clearAllClips")) Q("clearAllClips").onclick = clearAllClips;
    if(Q("clearAllEffects")) Q("clearAllEffects").onclick = clearAllEffects;
    if(Q("trimIn")) Q("trimIn").onclick = trimInPro;
    if(Q("trimOut")) Q("trimOut").onclick = trimOutPro;
  }

  const oldRenderTracksV75 = renderTracks;
  renderTracks = function(){
    oldRenderTracksV75();
    document.querySelectorAll(".clip").forEach(el => {
      const label = el.textContent || "";
      if(label.includes("Separated Audio")) el.classList.add("split-audio");
    });
  };

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", bindV75);
  }else{
    bindV75();
  }
  setTimeout(bindV75, 500);
  setTimeout(bindV75, 1500);
})();
