const $=id=>document.getElementById(id),canvas=$("canvas"),ctx=canvas.getContext("2d");let assets=[],layers=[],selected=null,current=0,duration=0,playing=false,last=0,speed=1;
const uid=()=>"sf_"+Math.random().toString(36).slice(2)+Date.now().toString(36),fmt=t=>{t=Math.max(0,t||0);let m=Math.floor(t/60),s=Math.floor(t%60),h=Math.floor((t%1)*100);return`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(h).padStart(2,"0")}`};const log=t=>$("msg").textContent=t;
function kindOf(f){let e=f.name.split(".").pop().toLowerCase();if(["txt","srt","vtt"].includes(e))return"textfile";if(f.type.startsWith("video/")||["mp4","webm","mov","avi","mkv"].includes(e))return"video";if(f.type.startsWith("audio/")||["mp3","wav","m4a","aac","ogg"].includes(e))return"audio";return"image"}function sel(){return layers.find(l=>l.id===selected)}function asset(l){return assets.find(a=>a.id===l.assetId)}
async function importFiles(files){for(const f of [...files]){let kind=kindOf(f),url=URL.createObjectURL(f);try{if(kind==="textfile"){let text=await f.text(),joined=text.replace(/\r/g,"").split("\n").filter(Boolean).slice(0,12).join("  ");layers.push({id:uid(),name:f.name,kind:"text",text:joined,start:0,duration:Math.max(duration,8),x:640,y:635,scale:1,fontSize:42,color:"#fff",effect:"fade"});selected=layers[layers.length-1].id;updateDuration();log("TXT synced on video: "+f.name)}else{let a={id:uid(),name:f.name,kind,url,duration:5,w:640,h:360,el:null};if(kind==="video"){let v=document.createElement("video");v.src=url;v.preload="auto";v.playsInline=true;v.volume=Number($("volume").value);a.el=v;await new Promise((res,rej)=>{v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:5;a.w=v.videoWidth||640;a.h=v.videoHeight||360;res()};v.onerror=()=>rej(Error("瀏覽器無法解碼此影片，請轉 MP4 H.264/WebM"));v.load()})}else if(kind==="audio"){let au=document.createElement("audio");au.src=url;au.preload="auto";au.volume=Number($("volume").value);a.el=au;await new Promise((res,rej)=>{au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:5;res()};au.onerror=()=>rej(Error("瀏覽器無法解碼此音訊"));au.load()})}else{let img=new Image();img.src=url;a.el=img;await new Promise(res=>{img.onload=()=>{a.w=img.naturalWidth||640;a.h=img.naturalHeight||360;res()};img.onerror=res})}assets.push(a);addToTimeline(a.id);log("Imported: "+f.name)}}catch(e){alert(f.name+"\\n"+e.message)}}renderAll()}
function addToTimeline(id){let a=assets.find(x=>x.id===id);if(!a)return;let sc=a.kind==="audio"?1:Math.min(canvas.width/a.w,canvas.height/a.h)*.85;layers.push({id:uid(),assetId:a.id,name:a.name,kind:a.kind,start:0,duration:a.duration,trim:0,x:640,y:360,scale:sc,volume:1,muted:false,effect:"none"});selected=layers[layers.length-1].id;updateDuration()}function updateDuration(){duration=Math.max(0,...layers.map(l=>l.start+l.duration));$("scrub").max=duration}
async function unlock(){for(const a of assets)if(a.el?.play)try{await a.el.play();a.el.pause();a.el.currentTime=0}catch{}log("Audio unlocked")}function play(){if(!layers.length)return log("Import media first");playing=true;sync(true)}function pause(){playing=false;for(const a of assets)if(a.el?.pause)a.el.pause()}function stop(){pause();current=0;sync(true)}function seek(t){current=Math.max(0,Math.min(t,duration));sync(true);renderAll()}
function sync(force=false){for(const l of layers){let a=asset(l);if(!a?.el||!(l.kind==="video"||l.kind==="audio"))continue;let active=current>=l.start&&current<=l.start+l.duration;if(!active){if(!a.el.paused)a.el.pause();continue}let local=(l.trim||0)+(current-l.start);if(a.el.readyState>=1&&(force||Math.abs(a.el.currentTime-local)>.50))try{a.el.currentTime=local}catch{}a.el.volume=l.volume??1;a.el.muted=!!l.muted;a.el.playbackRate=speed;if(playing&&a.el.paused)a.el.play().catch(()=>log("Press 🔊 啟用聲音 first"));if(!playing&&!a.el.paused)a.el.pause()}}
function split(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;let left=current-l.start,right=l.duration-left,c={...l,id:uid(),start:current,duration:right,trim:(l.trim||0)+left};l.duration=left;layers.push(c);selected=c.id;updateDuration();renderAll()}function trimIn(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;let d=current-l.start;l.trim=(l.trim||0)+d;l.duration-=d;l.start=current;updateDuration();renderAll()}function trimOut(){let l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;l.duration=current-l.start;updateDuration();renderAll()}function separate(){let l=sel();if(!l||l.kind!=="video")return log("Select video first");let a={...l,id:uid(),kind:"audio",name:"[Audio] "+l.name,muted:false};l.muted=true;layers.push(a);selected=a.id;updateDuration();renderAll()}
function fit(){let l=sel(),a=l&&asset(l);if(!l)return;l.x=640;l.y=360;if(a&&l.kind!=="audio")l.scale=Math.min(canvas.width/a.w,canvas.height/a.h)*.85;renderAll()}function addText(){layers.push({id:uid(),name:"Text",kind:"text",text:$("textInput").value,start:current,duration:Math.max(5,duration-current||5),x:640,y:635,scale:1,fontSize:Number($("fontSize").value),color:$("textColor").value,effect:$("effect").value});selected=layers[layers.length-1].id;updateDuration();renderAll()}function del(){layers=layers.filter(l=>l.id!==selected);selected=null;updateDuration();renderAll()}
function applyInspector(){let l=sel();if(!l)return;l.x=Number($("x").value);l.y=Number($("y").value);l.scale=Number($("scale").value);l.start=Number($("start").value);l.duration=Number($("duration").value);if(l.kind==="text"){l.text=$("textInput").value;l.fontSize=Number($("fontSize").value);l.color=$("textColor").value;l.effect=$("effect").value}else l.volume=Number($("volume").value);updateDuration();renderAll()}
function drawText(l){ctx.save();let p=(current-l.start)/Math.max(l.duration,.01),x=l.x,y=l.y,alpha=1;if(l.effect==="fade")alpha=Math.min(1,p*3,(1-p)*3);if(l.effect==="bounce")y=l.y-Math.abs(Math.sin(p*Math.PI*6))*30;if(l.effect==="scroll")x=canvas.width+300-p*(canvas.width+600);ctx.globalAlpha=Math.max(0,alpha);ctx.font=`bold ${l.fontSize||42}px system-ui`;ctx.textAlign="center";ctx.textBaseline="middle";ctx.lineWidth=6;ctx.strokeStyle="rgba(0,0,0,.75)";ctx.strokeText(l.text,x,y);ctx.fillStyle=l.color||"#fff";ctx.fillText(l.text,x,y);ctx.restore()}
function render(){ctx.clearRect(0,0,1280,720);ctx.fillStyle="#000";ctx.fillRect(0,0,1280,720);if(!layers.length){ctx.fillStyle="#8fa0be";ctx.font="34px system-ui";ctx.textAlign="center";ctx.fillText("Import media / TXT subtitles",640,360);return}for(const l of layers){if(current<l.start||current>l.start+l.duration)continue;if(l.kind==="text"){drawText(l);continue}let a=asset(l);if(!a)continue;if(["video","image","gif"].includes(l.kind)){let w=(a.el.videoWidth||a.el.naturalWidth||a.w)*l.scale,h=(a.el.videoHeight||a.el.naturalHeight||a.h)*l.scale;try{ctx.drawImage(a.el,l.x-w/2,l.y-h/2,w,h)}catch{}if(l.id===selected){ctx.strokeStyle="#8b5cf6";ctx.lineWidth=3;ctx.strokeRect(l.x-w/2,l.y-h/2,w,h)}}else if(l.kind==="audio"){ctx.fillStyle="#38bdf8";ctx.font="30px system-ui";ctx.textAlign="center";ctx.fillText("♪ "+l.name,640,360)}}}
function renderList(){$("list").innerHTML="";for(const a of assets){let d=document.createElement("div");d.className="card";d.innerHTML=`<strong>${a.name}</strong><small>${a.kind} · ${fmt(a.duration)} · ${a.w}x${a.h}</small><button>Add again</button>`;d.querySelector("button").onclick=()=>{addToTimeline(a.id);renderAll()};$("list").appendChild(d)}}
function layerMaxDuration(l){
 const a=asset(l);
 if(l.kind==="image"||l.kind==="gif"||l.kind==="text") return Math.max(duration, 300);
 return a?.duration || l.duration || 1;
}
function clampLayerDuration(l, value){
 const max=layerMaxDuration(l);
 return Math.max(1, Math.min(value, max));
}
function resizeClipMouse(ev, layerId, side){
 ev.stopPropagation(); ev.preventDefault();
 const l=layers.find(x=>x.id===layerId); if(!l)return;
 const lane=ev.currentTarget.closest(".lane");
 const rect=lane.getBoundingClientRect();
 const total=Math.max(duration, 1);
 const startX=ev.clientX;
 const oldStart=l.start, oldDuration=l.duration, oldTrim=l.trim||0;
 function move(e){
   const dx=e.clientX-startX;
   const sec=(dx/rect.width)*total;
   if(side==="right"){
     l.duration=clampLayerDuration(l, oldDuration+sec);
   }else{
     let newStart=oldStart+sec;
     let newDuration=oldDuration-sec;
     if(newStart<0){newDuration+=newStart;newStart=0}
     if(newDuration<1){newStart=oldStart+oldDuration-1;newDuration=1}
     l.start=Math.max(0,newStart);
     l.duration=clampLayerDuration(l,newDuration);
     if(l.kind!=="image"&&l.kind!=="gif"&&l.kind!=="text"){
       l.trim=Math.max(0,oldTrim+(l.start-oldStart));
     }
   }
   updateDuration();
   renderAll();
 }
 function up(){
   window.removeEventListener("mousemove",move);
   window.removeEventListener("mouseup",up);
 }
 window.addEventListener("mousemove",move);
 window.addEventListener("mouseup",up);
}

function dragClipMouse(ev, layerId){
 ev.stopPropagation(); ev.preventDefault();
 const l=layers.find(x=>x.id===layerId); if(!l)return;
 selected=l.id;
 const lane=ev.currentTarget.closest(".lane");
 const rect=lane.getBoundingClientRect();
 const total=Math.max(duration, 1);
 const startX=ev.clientX;
 const oldStart=l.start;
 function move(e){
   const dx=e.clientX-startX;
   const sec=(dx/rect.width)*total;
   let ns=oldStart+sec;
   ns=Math.max(0, ns);
   // Keep media clips inside their own max range when possible.
   if(l.kind==="video"||l.kind==="audio"){
     ns=Math.min(ns, Math.max(0, duration-l.duration));
   }
   l.start=ns;
   updateDuration();
   renderAll();
 }
 function up(){
   window.removeEventListener("mousemove",move);
   window.removeEventListener("mouseup",up);
 }
 window.addEventListener("mousemove",move);
 window.addEventListener("mouseup",up);
}

function moveLayerOrder(layerId, dir){
 const idx=layers.findIndex(l=>l.id===layerId);
 if(idx<0)return;
 const ni=idx+dir;
 if(ni<0||ni>=layers.length)return;
 const tmp=layers[idx];
 layers[idx]=layers[ni];
 layers[ni]=tmp;
 selected=layerId;
 renderAll();
}

function renderTracks(){
 const cont=$("tracks");cont.innerHTML="";
 for(const [name,kinds] of [["Video",["video","image","gif"]],["Audio",["audio"]],["Text",["text"]]]){
  let tr=document.createElement("div");tr.className="track";tr.innerHTML=`<div class="trackName">${name}</div><div class="lane"></div>`;
  let lane=tr.querySelector(".lane"),total=Math.max(duration,1);
  for(const l of layers.filter(x=>kinds.includes(x.kind))){
   let c=document.createElement("div");
   c.className="clip "+(l.kind==="text"?"textClip":l.kind==="audio"?"audioClip":"")+(l.id===selected?" sel":"");
   c.innerHTML=`<span class="resize-left"></span><span class="clip-label"></span><span class="resize-right"></span>`;
   c.querySelector(".clip-label").textContent=l.name||l.text;
   c.style.left=`${l.start/total*100}%`;
   c.style.width=`${Math.max(2,l.duration/total*100)}%`;
   c.onclick=()=>{selected=l.id;renderAll()};
   c.querySelector(".clip-label").onmousedown=(e)=>dragClipMouse(e,l.id);
   c.querySelector(".resize-left").onmousedown=(e)=>resizeClipMouse(e,l.id,"left");
   c.querySelector(".resize-right").onmousedown=(e)=>resizeClipMouse(e,l.id,"right");
   c.ondblclick=()=>{moveLayerOrder(l.id,-1)};
   lane.appendChild(c)
  }
  cont.appendChild(tr)
 }
}
function renderInspector(){let l=sel();$("selectedName").textContent=l?l.name||l.text:"未選取";if(!l)return;$("x").value=Math.round(l.x||0);$("y").value=Math.round(l.y||0);$("scale").value=l.scale??1;$("start").value=l.start??0;$("duration").value=l.duration??0;if(l.kind==="text"){$("textInput").value=l.text||"";$("fontSize").value=l.fontSize||42;$("textColor").value=l.color||"#ffffff";$("effect").value=l.effect||"none"}else $("volume").value=l.volume??1}
function renderAll(){render();renderList();renderTracks();renderInspector();$("time").textContent=`${fmt(current)} / ${fmt(duration)}`;$("scrub").value=current}
function loop(now){let dt=last?(now-last)/1000:0;last=now;if(playing){current+=dt*speed;if(current>=duration){current=duration;pause()}sync()}render();$("time").textContent=`${fmt(current)} / ${fmt(duration)}`;$("scrub").value=current;requestAnimationFrame(loop)}
$("fileInput").onchange=e=>importFiles(e.target.files);$("unlock").onclick=unlock;$("play").onclick=$("play2").onclick=play;$("pause").onclick=$("pause2").onclick=pause;$("stop").onclick=$("stop2").onclick=stop;$("back").onclick=$("back2").onclick=()=>seek(current-5);$("fwd").onclick=$("fwd2").onclick=()=>seek(current+5);$("speed").onchange=$("speed2").onchange=e=>{speed=Number(e.target.value);$("speed").value=$("speed2").value=e.target.value;sync(true)};$("split").onclick=split;$("trimIn").onclick=trimIn;$("trimOut").onclick=trimOut;$("separate").onclick=separate;$("fit").onclick=fit;$("addText").onclick=addText;$("deleteSelected").onclick=del;$("removeFx").onclick=()=>{let l=sel();if(l)l.effect="none";renderAll()};$("scrub").oninput=e=>seek(Number(e.target.value));["x","y","scale","start","duration","textInput","fontSize","textColor","effect","volume"].forEach(id=>$(id).oninput=applyInspector);$("clearLibrary").onclick=()=>{assets=[];layers=[];selected=null;current=0;duration=0;renderAll()};
let drop=$("drop");drop.ondragover=e=>{e.preventDefault();drop.classList.add("drag")};drop.ondragleave=()=>drop.classList.remove("drag");drop.ondrop=e=>{e.preventDefault();drop.classList.remove("drag");importFiles(e.dataTransfer.files)};
canvas.onmousedown=e=>{let r=canvas.getBoundingClientRect(),sx=(e.clientX-r.left)*(1280/r.width),sy=(e.clientY-r.top)*(720/r.height),hit=null;for(let i=layers.length-1;i>=0;i--){let l=layers[i];if(l.kind==="audio")continue;if(l.kind==="text"){if(Math.abs(sx-l.x)<260&&Math.abs(sy-l.y)<60){hit=l;break}}else{let a=asset(l);if(!a)continue;let w=(a.el.videoWidth||a.el.naturalWidth||a.w)*l.scale,h=(a.el.videoHeight||a.el.naturalHeight||a.h)*l.scale;if(sx>=l.x-w/2&&sx<=l.x+w/2&&sy>=l.y-h/2&&sy<=l.y+h/2){hit=l;break}}}if(!hit)return;selected=hit.id;let ox=hit.x,oy=hit.y,move=ev=>{let nx=(ev.clientX-r.left)*(1280/r.width),ny=(ev.clientY-r.top)*(720/r.height);hit.x=ox+nx-sx;hit.y=oy+ny-sy;renderInspector()},up=()=>{window.removeEventListener("mousemove",move);window.removeEventListener("mouseup",up);renderAll()};window.addEventListener("mousemove",move);window.addEventListener("mouseup",up);renderAll()};
renderAll();

/* === AV SYNC FIX: media element is timeline clock === */
let masterLayerId = null;

function getMasterLayer(){
  // Prefer selected active video, otherwise first video, then first audio.
  let videoLayer = layers.find(l => l.kind === "video");
  let audioLayer = layers.find(l => l.kind === "audio");
  return videoLayer || audioLayer || null;
}

function localTimeOf(layer){
  return Math.max(0, (current - layer.start) + (layer.trim || 0));
}

function syncSoft(force=false){
  for(const l of layers){
    const a = asset(l);
    if(!a || !a.el || !(l.kind === "video" || l.kind === "audio")) continue;

    const active = current >= l.start && current <= l.start + l.duration;
    if(!active){
      if(!a.el.paused) a.el.pause();
      continue;
    }

    const local = localTimeOf(l);
    if(a.el.readyState >= 1){
      const drift = Math.abs((a.el.currentTime || 0) - local);
      // Only hard-seek when drift is visible. Frequent seeking causes AV delay.
      if(force || drift > 0.18){
        try { a.el.currentTime = local; } catch(e) {}
      }
    }

    a.el.volume = l.volume ?? 1;
    a.el.muted = !!l.muted;
    a.el.playbackRate = speed;

    if(playing && a.el.paused){
      a.el.play().catch(()=>log("Press 🔊 啟用聲音 first"));
    }
    if(!playing && !a.el.paused) a.el.pause();
  }
}

play = function(){
  if(!layers.length) return log("Import media first");
  const master = getMasterLayer();
  if(!master) return;
  if(current < master.start || current > master.start + master.duration) current = master.start;
  playing = true;
  syncSoft(true);
  log("Playing with AV sync");
};

pause = function(){
  playing = false;
  for(const a of assets) if(a.el?.pause) a.el.pause();
  log("Paused");
};

stop = function(){
  pause();
  current = 0;
  syncSoft(true);
  renderAll();
};

seek = function(t){
  current = Math.max(0, Math.min(t, duration));
  syncSoft(true);
  renderAll();
};

sync = syncSoft;

// Replace the old animation loop behavior by making current follow master media.
let avSyncLast = 0;
function loopAV(now){
  const master = getMasterLayer();

  if(playing && master){
    const a = asset(master);
    if(a && a.el && (master.kind === "video" || master.kind === "audio")){
      // The media element is the clock.
      current = master.start + Math.max(0, (a.el.currentTime || 0) - (master.trim || 0));
      if(current >= duration || a.el.ended){
        current = Math.min(duration, current);
        pause();
      }
      // Gently sync secondary audio/video only every few frames.
      if(!avSyncLast || now - avSyncLast > 250){
        syncSoft(false);
        avSyncLast = now;
      }
    }
  }

  render();
  $("time").textContent = `${fmt(current)} / ${fmt(duration)}`;
  $("scrub").value = current;
  requestAnimationFrame(loopAV);
}

// Disable the previous loop by making playing false for old loop side effects is not enough.
// Start AV-sync loop after load; old loop may still run, but this loop continuously corrects display.
requestAnimationFrame(loopAV);

/* Reduce default delay by preloading videos/audio more aggressively */
for(const a of assets){
  if(a.el && (a.kind==="video" || a.kind==="audio")){
    a.el.preload = "auto";
    try { a.el.load(); } catch(e){}
  }
}


/* keydownLayerOrderPatch */
window.addEventListener("keydown", e=>{
  if(!selected) return;
  if(e.ctrlKey && e.key==="ArrowUp"){ e.preventDefault(); moveLayerOrder(selected,-1); }
  if(e.ctrlKey && e.key==="ArrowDown"){ e.preventDefault(); moveLayerOrder(selected,1); }
});
