# StudioFlow v7 Draggable Timeline + TXT Sync

保留目前所有功能，並新增時間軸自由拖曳與前後順序調整。

## 保留功能

- 影片 / 音訊 / 圖片匯入
- TXT / SRT / VTT 匯入
- 匯入 TXT 同步顯示在影片畫面
- Scroll 文字效果由右到左
- 播放、暫停、停止
- 快轉、倒退
- Split
- Trim In / Trim Out
- 分離影音
- 影片 / 圖片位置拖曳
- 縮放
- 文字圖層
- Fade / Bounce / Scroll
- 移除效果
- 刪除選取圖層
- AV Sync 修正
- 16:9 預覽
- 加寬時間軸

## 新增功能

### 1. 時間軸可拉長 / 縮短

Video / Audio / Text clip 的左右邊緣都可以用滑鼠拖曳。

限制：

- 最短 1 秒
- 影片 / 音訊最長不超過來源媒體長度
- 圖片 / 文字可以拉到整個時間軸一樣長或更長

### 2. 時間軸 clip 可拖動位置

拖曳 clip 中間文字區域，可以改變開始時間 Start。

### 3. 前後順序調整

- 雙擊 clip：往前一層
- Ctrl + ↑：往前一層
- Ctrl + ↓：往後一層

這會影響 Canvas 上的顯示前後順序。

### 4. TXT 同步顯示

匯入 `.txt` / `.srt` / `.vtt` 會自動建立 Text layer，播放時同步顯示在影片畫面上。

### 5. Scroll 方向

Scroll 效果為：

```text
Right → Left
```

## 使用

1. 開啟 `index.html`
2. 匯入影片
3. 匯入 TXT / SRT / VTT
4. 在時間軸拖曳 clip 中間改變位置
5. 拖曳左右邊緣改變長度
6. 選文字層，效果選 Scroll，即可由右往左顯示
