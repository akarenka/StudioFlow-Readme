
from __future__ import annotations

import json
import mimetypes
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.utils import secure_filename

try:
    import moviepy
    from moviepy import (VideoFileClip, AudioFileClip, TextClip, CompositeVideoClip,
                     CompositeAudioClip, concatenate_videoclips, vfx, afx)
except Exception as exc:
    moviepy = None
    VideoFileClip = None
    AudioFileClip = None
    TextClip = None
    CompositeVideoClip = None
    CompositeAudioClip = None
    concatenate_videoclips = None
    vfx = None
    afx = None
    MOVIEPY_IMPORT_ERROR = str(exc)
else:
    MOVIEPY_IMPORT_ERROR = ""

try:
    import imageio_ffmpeg
except Exception:
    imageio_ffmpeg = None

ROOT = Path(__file__).resolve().parent.parent
WORKSPACE = ROOT / "workspace"
UPLOADS = WORKSPACE / "Uploads"
COPIES = WORKSPACE / "Copies"
EXPORTS = WORKSPACE / "Exports"
TEMP = WORKSPACE / "Temp"

for folder in (UPLOADS, COPIES, EXPORTS, TEMP):
    folder.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {
    ".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v",
    ".mp3", ".wav", ".aac", ".m4a", ".ogg", ".flac",
    ".jpg", ".jpeg", ".tif", ".tiff", ".gif", ".png"
}

app = Flask(__name__, static_folder=str(ROOT), static_url_path="")


def ffmpeg_executable() -> str:
    if imageio_ffmpeg is not None:
        try:
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            pass
    return "ffmpeg"


def safe_name(name: str, fallback: str = "file") -> str:
    cleaned = secure_filename(name or fallback)
    return cleaned or fallback


def unique_path(folder: Path, filename: str) -> Path:
    filename = safe_name(filename)
    path = folder / filename
    stem, suffix = path.stem, path.suffix
    counter = 1
    while path.exists():
        path = folder / f"{stem}_{counter}{suffix}"
        counter += 1
    return path


def resolve_media(name: str) -> Path:
    safe = safe_name(name)
    for folder in (UPLOADS, COPIES, EXPORTS):
        candidate = folder / safe
        if candidate.exists() and candidate.is_file():
            return candidate
    raise FileNotFoundError(f"Media file not found: {safe}")


def kind_for(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in {".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v"}:
        return "video"
    if ext in {".mp3", ".wav", ".aac", ".m4a", ".ogg", ".flac"}:
        return "audio"
    return "image"


def size_text(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def run_ffmpeg(args: list[str]) -> None:
    command = [ffmpeg_executable(), *args]
    completed = subprocess.run(
        command,
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        shell=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr[-4000:] or "FFmpeg failed")


@app.get("/")
def index():
    return send_from_directory(ROOT, "index.html")


@app.get("/api/health")
def health():
    ffmpeg_path = ffmpeg_executable()
    return jsonify({
        "ok": True,
        "moviepy": getattr(moviepy, "__version__", "not installed") if moviepy else f"error: {MOVIEPY_IMPORT_ERROR}",
        "ffmpeg": ffmpeg_path,
    })


@app.post("/api/media/upload")
def upload_media():
    incoming = request.files.getlist("files")
    if not incoming:
        return jsonify({"error": "No files supplied."}), 400

    saved: list[dict[str, Any]] = []
    for file in incoming:
        original = safe_name(file.filename, "media")
        ext = Path(original).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            return jsonify({"error": f"Unsupported file type: {ext}"}), 400

        upload_path = unique_path(UPLOADS, original)
        file.save(upload_path)

        copy_path = unique_path(COPIES, upload_path.name)
        shutil.copy2(upload_path, copy_path)

        saved.append({
            "name": upload_path.name,
            "copy": copy_path.name,
            "kind": kind_for(upload_path),
            "size": upload_path.stat().st_size,
        })

    return jsonify({"ok": True, "files": saved})


@app.get("/api/media")
def list_media():
    files = []
    for folder_name, folder in (("Uploads", UPLOADS), ("Copies", COPIES), ("Exports", EXPORTS)):
        for path in sorted(folder.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            if path.is_file():
                files.append({
                    "name": path.name,
                    "folder": folder_name,
                    "kind": kind_for(path),
                    "size": path.stat().st_size,
                    "size_text": size_text(path.stat().st_size),
                })
    return jsonify({"files": files})


@app.post("/api/moviepy/compose")
def moviepy_compose():
    if VideoFileClip is None:
        return jsonify({"error": f"MoviePy unavailable: {MOVIEPY_IMPORT_ERROR}"}), 500

    data = request.get_json(force=True)
    format_name = str(data.get("format", "mp4")).lower()
    if format_name not in {"mp4", "gif"}:
        return jsonify({"error": "Format must be mp4 or gif."}), 400

    clip1_path = resolve_media(data.get("clip1", ""))
    clip2_path = resolve_media(data.get("clip2", ""))

    c1_start = float(data.get("clip1_start", 0))
    c1_end = float(data.get("clip1_end", 3))
    c2_start = float(data.get("clip2_start", 5))
    c2_end = float(data.get("clip2_end", 10))

    if c1_end <= c1_start or c2_end <= c2_start:
        return jsonify({"error": "End time must be greater than start time."}), 400

    output_base = safe_name(data.get("output_name", "output"), "output")
    output_path = unique_path(EXPORTS, f"{Path(output_base).stem}.{format_name}")

    clip1 = clip2 = part1 = part2 = final_clip = gif_clip = None
    try:
        clip1 = VideoFileClip(str(clip1_path))
        clip2 = VideoFileClip(str(clip2_path))

        part1 = clip1.subclipped(c1_start, min(c1_end, clip1.duration))
        part2 = clip2.subclipped(c2_start, min(c2_end, clip2.duration))

        if bool(data.get("black_and_white_clip2", True)):
            part2 = part2.with_effects([vfx.BlackAndWhite()])

        final_clip = concatenate_videoclips([part1, part2], method="compose")

        if format_name == "mp4":
            final_clip.write_videofile(
                str(output_path),
                fps=24,
                codec="libx264",
                audio_codec="aac",
                ffmpeg_params=["-movflags", "+faststart"],
                logger="bar",
            )
        else:
            gif_clip = final_clip.resized(width=360)
            gif_clip.write_gif(str(output_path), fps=10, logger="bar")
    finally:
        for clip in (gif_clip, final_clip, part2, part1, clip2, clip1):
            try:
                if clip is not None:
                    clip.close()
            except Exception:
                pass

    return jsonify({
        "ok": True,
        "output": output_path.name,
        "download_url": f"/downloads/{output_path.name}",
    })



def moviepy_position(value: str):
    positions = {
        "top": ("center", 40),
        "center": ("center", "center"),
        "bottom": ("center", lambda t: 0),
    }
    return positions.get(value, ("center", "center"))


@app.post("/api/moviepy/advanced-compose")
def advanced_moviepy_compose():
    if VideoFileClip is None:
        return jsonify({"error": f"MoviePy unavailable: {MOVIEPY_IMPORT_ERROR}"}), 500

    data = request.get_json(force=True)
    output_format = str(data.get("format", "mp4")).lower()
    if output_format not in {"mp4", "gif"}:
        return jsonify({"error": "Format must be mp4 or gif."}), 400

    clip1_path = resolve_media(data.get("clip1", ""))
    clip2_path = resolve_media(data.get("clip2", ""))
    c1_start = float(data.get("clip1_start", 0))
    c1_end = float(data.get("clip1_end", 3))
    c2_start = float(data.get("clip2_start", 5))
    c2_end = float(data.get("clip2_end", 10))
    transition = str(data.get("transition", "none"))
    transition_duration = max(0.0, min(5.0, float(data.get("transition_duration", 0.8))))
    fps = max(1, min(120, int(data.get("output_fps", 24))))
    preset = str(data.get("encoder_preset", "veryfast"))
    if preset not in {"ultrafast", "veryfast", "fast", "medium"}:
        preset = "veryfast"

    output_base = safe_name(data.get("output_name", "output"), "output")
    temp_movie = unique_path(TEMP, f"{Path(output_base).stem}_moviepy_temp.mp4")
    final_output = unique_path(EXPORTS, f"{Path(output_base).stem}.{output_format}")

    opened = []
    try:
        clip1 = VideoFileClip(str(clip1_path))
        clip2 = VideoFileClip(str(clip2_path))
        opened.extend([clip1, clip2])

        part1 = clip1.subclipped(c1_start, min(c1_end, clip1.duration))
        part2 = clip2.subclipped(c2_start, min(c2_end, clip2.duration))
        opened.extend([part1, part2])

        if bool(data.get("black_and_white_clip2", True)):
            part2 = part2.with_effects([vfx.BlackAndWhite()])

        if transition == "crossfade" and transition_duration > 0:
            # Negative padding overlaps the clips; CrossFadeIn creates the transition.
            part2 = part2.with_effects([vfx.CrossFadeIn(transition_duration)])
            final_clip = concatenate_videoclips(
                [part1, part2],
                method="compose",
                padding=-transition_duration,
            )
        elif transition == "fade-black" and transition_duration > 0:
            part1 = part1.with_effects([vfx.FadeOut(transition_duration)])
            part2 = part2.with_effects([vfx.FadeIn(transition_duration)])
            final_clip = concatenate_videoclips([part1, part2], method="compose")
        else:
            final_clip = concatenate_videoclips([part1, part2], method="compose")
        opened.append(final_clip)

        overlay_text = str(data.get("overlay_text", "")).strip()
        if overlay_text:
            text_start = max(0.0, float(data.get("text_start", 0)))
            text_duration = max(0.1, float(data.get("text_duration", 3)))
            text_size = max(12, min(200, int(data.get("text_size", 48))))
            text_position = str(data.get("text_position", "bottom"))

            text_clip = TextClip(
                text=overlay_text,
                font_size=text_size,
                color="white",
                stroke_color="black",
                stroke_width=2,
                method="caption",
                size=(max(320, int(final_clip.w * 0.9)), None),
                duration=min(text_duration, max(0.1, final_clip.duration - text_start)),
            ).with_start(text_start)

            if text_position == "top":
                text_clip = text_clip.with_position(("center", 40))
            elif text_position == "bottom":
                text_clip = text_clip.with_position(("center", final_clip.h - text_clip.h - 40))
            else:
                text_clip = text_clip.with_position(("center", "center"))

            opened.append(text_clip)
            final_clip = CompositeVideoClip([final_clip, text_clip], size=final_clip.size)
            opened.append(final_clip)

        audio_layers = []
        if final_clip.audio is not None:
            audio_layers.append(final_clip.audio)

        for item in data.get("audio_clips", [])[:3]:
            filename = str(item.get("filename", "")).strip()
            if not filename:
                continue
            audio_path = resolve_media(filename)
            audio = AudioFileClip(str(audio_path))
            opened.append(audio)
            start = max(0.0, float(item.get("start", 0)))
            volume = max(0.0, min(3.0, float(item.get("volume", 1))))
            if volume != 1:
                audio = audio.with_effects([afx.MultiplyVolume(volume)])
            audio = audio.with_start(start)
            opened.append(audio)
            audio_layers.append(audio)

        if audio_layers:
            mixed_audio = CompositeAudioClip(audio_layers)
            opened.append(mixed_audio)
            final_clip = final_clip.with_audio(mixed_audio)
            opened.append(final_clip)

        # MoviePy performs timeline/text/transition/audio calculations.
        # It writes an intermediate mezzanine file; final packaging is direct FFmpeg.
        final_clip.write_videofile(
            str(temp_movie),
            fps=fps,
            codec="libx264",
            audio_codec="aac",
            preset="ultrafast",
            ffmpeg_params=["-crf", "18"],
            logger="bar",
        )

        if output_format == "mp4":
            run_ffmpeg([
                "-y",
                "-i", str(temp_movie),
                "-c:v", "libx264",
                "-preset", preset,
                "-crf", "23",
                "-pix_fmt", "yuv420p",
                "-c:a", "aac",
                "-b:a", "192k",
                "-movflags", "+faststart",
                str(final_output),
            ])
            encoder = f"FFmpeg libx264/{preset} + AAC"
        else:
            palette = unique_path(TEMP, f"{Path(output_base).stem}_palette.png")
            try:
                run_ffmpeg([
                    "-y",
                    "-i", str(temp_movie),
                    "-vf", "fps=10,scale=480:-1:flags=lanczos,palettegen=stats_mode=diff",
                    str(palette),
                ])
                run_ffmpeg([
                    "-y",
                    "-i", str(temp_movie),
                    "-i", str(palette),
                    "-filter_complex",
                    "fps=10,scale=480:-1:flags=lanczos[x];[x][1:v]paletteuse=dither=sierra2_4a",
                    "-loop", "0",
                    str(final_output),
                ])
            finally:
                palette.unlink(missing_ok=True)
            encoder = "FFmpeg palettegen + paletteuse"

        completed_copy = TEMP / "Completed"
        completed_copy.mkdir(parents=True, exist_ok=True)
        shutil.copy2(final_output, unique_path(completed_copy, final_output.name))

        return jsonify({
            "ok": True,
            "output": final_output.name,
            "encoder": encoder,
            "download_url": f"/downloads/{final_output.name}",
        })
    finally:
        for obj in reversed(opened):
            try:
                obj.close()
            except Exception:
                pass
        temp_movie.unlink(missing_ok=True)


@app.post("/api/ffmpeg/fast-cut")
def fast_cut():
    data = request.get_json(force=True)
    source = resolve_media(data.get("source", ""))
    start = str(data.get("start", "00:00:00"))
    end = str(data.get("end", "00:00:05"))
    output = unique_path(EXPORTS, safe_name(data.get("output", "cut1.mp4"), "cut1.mp4"))

    run_ffmpeg([
        "-y",
        "-ss", start,
        "-to", end,
        "-i", str(source),
        "-c", "copy",
        str(output),
    ])

    return jsonify({
        "ok": True,
        "output": output.name,
        "download_url": f"/downloads/{output.name}",
    })


@app.post("/api/ffmpeg/high-quality-gif")
def high_quality_gif():
    data = request.get_json(force=True)
    source = resolve_media(data.get("source", ""))
    width = max(64, min(1920, int(data.get("width", 480))))
    fps = max(1, min(60, int(data.get("fps", 10))))
    output = unique_path(EXPORTS, safe_name(data.get("output", "output_high_q.gif"), "output_high_q.gif"))
    palette = TEMP / f"palette_{os.getpid()}_{output.stem}.png"

    try:
        run_ffmpeg([
            "-y",
            "-i", str(source),
            "-vf", f"fps={fps},scale={width}:-1:flags=lanczos,palettegen",
            str(palette),
        ])
        run_ffmpeg([
            "-y",
            "-i", str(source),
            "-i", str(palette),
            "-filter_complex", f"fps={fps},scale={width}:-1:flags=lanczos[x];[x][1:v]paletteuse",
            str(output),
        ])
    finally:
        palette.unlink(missing_ok=True)

    return jsonify({
        "ok": True,
        "output": output.name,
        "download_url": f"/downloads/{output.name}",
    })


@app.get("/downloads/<path:filename>")
def download(filename: str):
    return send_from_directory(EXPORTS, safe_name(filename), as_attachment=True)


if __name__ == "__main__":
    print("StudioFlow Pro v7.6 MoviePy Backend")
    print("Open http://127.0.0.1:8000")
    app.run(host="127.0.0.1", port=8000, debug=False, threaded=True)
