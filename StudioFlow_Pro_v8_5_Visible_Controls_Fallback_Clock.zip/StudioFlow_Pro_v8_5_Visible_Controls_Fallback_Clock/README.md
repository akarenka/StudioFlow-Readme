# StudioFlow Pro v8.5 — Visible Controls + Fallback Clock

v8.5 保留 v8.4 的全部功能，針對「完全沒有動」加入兩層播放保險。

## 永遠可見的播放控制

Preview 畫面內固定顯示：

- ▶ Play
- Ⅱ Pause
- ■ Stop
- ↺ Restart
- Current Time / Duration

Preview 中央也有大型 ▶ 按鈕。

因此即使 Timeline 或 Inspector 版面高度改變，播放鍵也不會被遮住。

## 獨立播放時鐘

新增每 33ms 執行一次的播放時鐘：

- 持續更新 current time
- 持續驅動 Video 1～5
- 持續驅動 Audio 1～5
- 更新 Preview Canvas
- 更新紅色播放頭
- 更新藍色進度條
- 更新時間數字

即使原本的 requestAnimationFrame 被其他面板錯誤影響，Fallback Clock 仍會繼續運作。

## 快捷鍵

- Space：播放／暫停
- Preview 中央 ▶：播放

## 保留功能

- 10 軌 Video 1～5 / Audio 1～5
- Separate Audio
- Split Clip / Split AV
- Unlink AV
- 手動拖曳紅色播放頭
- 雙擊素材原檔預覽
- Preview 內拖曳圖片、GIF、TIF、文字
- Audio Volume / Mute / Solo
- 單獨刪除 Clip / Effects
- MoviePy / FFmpeg
- MP4 / GIF / MP3 / WebM
- Uploads / Copies / Exports / Temp
