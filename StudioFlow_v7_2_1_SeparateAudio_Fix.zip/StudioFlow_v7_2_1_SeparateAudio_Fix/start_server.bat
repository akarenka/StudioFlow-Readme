@echo off
title StudioFlow v7.2 Compose Engine Integrated
echo Open http://localhost:8000
python -m http.server 8000
pause
