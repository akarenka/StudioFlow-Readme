# StudioFlow v7.2 Compose Engine Integrated

此版本保留目前 StudioFlow v7.1.1 / TextTop / FFmpeg / 多軌功能，並新增你提供的 v7.2 影音合成引擎頁面。

## 新增頁面

```text
v7_2_compose_engine.html
```

功能：

- 匯入影片
- Canvas 即時預覽
- 疊加文字
- 文字效果：
  - 粗體白字
  - 黑色描邊
  - 黑色陰影
  - Fade
  - Bounce
  - Scroll
- 匯出 WebM
- 使用 FFmpeg.wasm 轉 MP4
- 如果 FFmpeg 失敗，會自動下載 WebM fallback

## 使用

請執行：

```text
start_server.bat
```

再開啟：

```text
http://localhost:8000
```

主編輯器仍使用：

```text
index.html
```

v7.2 合成引擎使用：

```text
v7_2_compose_engine.html
```

