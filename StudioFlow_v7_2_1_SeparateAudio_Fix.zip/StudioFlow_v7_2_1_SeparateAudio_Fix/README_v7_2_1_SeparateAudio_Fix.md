# StudioFlow v7.2.1 Separate Audio Fix

此版本保留目前所有功能與 v7.2 Shadow / Outline Engine，修正主編輯器的影音分離按鈕沒有反應問題。

## 修正內容

- Separate Audio 按鈕重新實裝
- 如果沒有正確選取 Video Clip，會自動找到第一個 Video Clip
- 新增獨立 Audio Asset
- 新增 Audio Clip 到 Audio 軌
- Video 原音自動靜音
- Audio Clip 與 Video 播放同步
- 可完整播放到時間線結束
- 保留 FFmpeg 匯出

## 使用方式

1. 匯入影片。
2. 點選 Video Clip，或直接按 Separate Audio。
3. Audio 軌會出現 `[Separated Audio] ...`。
4. 原 Video 會靜音，Audio Clip 會負責播放聲音。

## 保留功能

- Video×5 / Audio×3 / Text×3
- Timeline
- Clip Move / Resize
- Snap / Ripple
- Trim / Split
- Text Overlay / Shadow / Outline
- v7.2 Compose Engine
- FFmpeg Export
