Optional local ffmpeg-core.js / ffmpeg-core.wasm / ffmpeg-core.worker.js
