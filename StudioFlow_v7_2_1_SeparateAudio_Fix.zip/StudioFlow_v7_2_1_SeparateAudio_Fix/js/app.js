(() => {
"use strict";
const $=id=>document.getElementById(id);
const canvas=$("canvas");
const ctx=canvas.getContext("2d");

let assets=[];
let layers=[];
let selected=null;
let current=0;
let duration=0;
let playing=false;
let speed=1;

const tracks={
  video:["Video 1","Video 2","Video 3","Video 4","Video 5"],
  audio:["Audio 1","Audio 2","Audio 3"],
  text:["Text 1","Text 2","Text 3"]
};

function pub(){
  window.assets=assets;
  window.layers=layers;
  window.selected=selected;
  window.current=current;
  window.duration=duration;
  window.playing=playing;
}

function uid(){return"sf_"+Math.random().toString(36).slice(2)+Date.now().toString(36)}
function log(m){const el=$("log");if(el)el.textContent=m;console.log("[StudioFlow v7.2.1]",m)}
function fmt(t){t=Math.max(0,t||0);return`${String(Math.floor(t/60)).padStart(2,"0")}:${String(Math.floor(t%60)).padStart(2,"0")}.${String(Math.floor((t%1)*100)).padStart(2,"0")}`}
function snap(t){return $("snapToggle")?.checked?Math.round(t*10)/10:t}
function sel(){return layers.find(l=>l.id===selected)||null}
function asset(l){return assets.find(a=>a.id===l.assetId)||null}
function kindOf(f){
  const ext=f.name.split(".").pop().toLowerCase();
  if(["txt","srt","vtt"].includes(ext))return"textfile";
  if(f.type.startsWith("video/")||["mp4","webm","mov","mkv"].includes(ext))return"video";
  if(f.type.startsWith("audio/")||["mp3","wav","m4a","aac","ogg"].includes(ext))return"audio";
  return"image";
}
function updateDuration(){
  duration=Math.max(0,...layers.map(l=>(Number(l.start)||0)+(Number(l.duration)||0)));
  if($("scrubber"))$("scrubber").max=duration;
  pub();
}
async function importFiles(files){
  for(const file of Array.from(files||[])){
    const kind=kindOf(file);
    const url=URL.createObjectURL(file);
    try{
      if(kind==="textfile"){
        const text=(await file.text()).replace(/\r/g,"").split("\n").filter(Boolean).slice(0,20).join("  ");
        addTextLayer(text||file.name,file.name);
        continue;
      }
      const a={id:uid(),name:file.name,kind,url,duration:5,w:640,h:360,el:null};
      if(kind==="video"){
        const v=document.createElement("video");
        v.src=url;v.preload="auto";v.playsInline=true;v.volume=Number($("volume")?.value||1);
        a.el=v;
        await new Promise((res,rej)=>{
          v.onloadedmetadata=()=>{a.duration=isFinite(v.duration)?v.duration:5;a.w=v.videoWidth||640;a.h=v.videoHeight||360;res()};
          v.onerror=()=>rej(Error("瀏覽器無法解碼此影片"));
          v.load();
        });
      }else if(kind==="audio"){
        const au=document.createElement("audio");
        au.src=url;au.preload="auto";au.volume=Number($("volume")?.value||1);
        a.el=au;
        await new Promise((res,rej)=>{
          au.onloadedmetadata=()=>{a.duration=isFinite(au.duration)?au.duration:5;res()};
          au.onerror=()=>rej(Error("瀏覽器無法解碼音訊"));
          au.load();
        });
      }else{
        const img=new Image();
        img.src=url;a.el=img;
        await new Promise(res=>{img.onload=()=>{a.w=img.naturalWidth||640;a.h=img.naturalHeight||360;res()};img.onerror=res});
      }
      assets.push(a);
      addLayerFromAsset(a);
      log("Imported: "+file.name);
    }catch(e){alert(file.name+"\n"+e.message)}
  }
  renderAll();
}
function addLayerFromAsset(a){
  const scale=a.kind==="audio"?1:Math.min(canvas.width/a.w,canvas.height/a.h)*.85;
  layers.push({id:uid(),assetId:a.id,name:a.name,kind:a.kind,start:0,duration:a.duration,trim:0,x:640,y:360,scale,volume:1,muted:false,trackIndex:0,linkedGroup:null,effect:"none"});
  selected=layers.at(-1).id;
  updateDuration();
}
function addTextLayer(text,name="Text"){
  const start=Number(current||0);
  layers.push({
    id:uid(),name,kind:"text",text:text||$("textInput")?.value||"文字",
    start,duration:Math.max(5,duration>start?duration-start:8),
    x:640,y:120,scale:1,
    fontFamily:$("fontFamily")?.value||"system-ui",
    fontSize:Number($("fontSize")?.value||56),
    color:$("textColor")?.value||"#ffffff",
    outlineSize:Number($("outlineSize")?.value||10),
    shadow:true,
    effect:$("effect")?.value||"none",
    scrollDir:$("scrollDir")?.value||"rtl",
    trackIndex:0
  });
  selected=layers.at(-1).id;
  current=start;
  updateDuration();
  renderAll();
  log("Text added on top layer.");
}
async function unlockAudio(){
  for(const a of assets){
    if(a.el?.play){
      try{await a.el.play();a.el.pause();a.el.currentTime=0}catch{}
    }
  }
  log("Audio unlocked.");
}

/* -------- Separate Audio v7.2.1 robust core -------- */
function findVideoForSeparation(){
  const s=sel();
  if(s && s.kind==="video") return s;
  const selectedAssetLayer = layers.find(l=>l.id===selected && l.kind==="video");
  if(selectedAssetLayer) return selectedAssetLayer;
  return layers.find(l=>l.kind==="video") || null;
}
function hasSeparatedAudio(videoLayer){
  return !!(videoLayer && videoLayer.linkedGroup && layers.some(l=>l.kind==="audio" && l.linkedGroup===videoLayer.linkedGroup));
}
function createAudioAssetFromVideo(videoLayer){
  const src=asset(videoLayer);
  if(!src) return null;

  /* Use a new HTMLVideoElement to decode the audio track from MP4/WebM reliably.
     It is independent from the video preview element, so playback will not fight over currentTime. */
  const el=document.createElement("video");
  el.src=src.url;
  el.preload="auto";
  el.playsInline=true;
  el.muted=false;
  el.volume=Number($("volume")?.value||1);
  el.playbackRate=Number(speed||1);

  const a={
    id:uid(),
    name:"[Separated Audio Asset] "+src.name,
    kind:"audio",
    url:src.url,
    duration:src.duration||videoLayer.duration||1,
    w:0,
    h:0,
    el,
    sourceVideoAssetId:src.id
  };
  assets.push(a);
  return a;
}
function separateAudio(){
  const videoLayer=findVideoForSeparation();
  if(!videoLayer){
    alert("找不到 Video Clip。請先匯入影片或選取影片時間線。");
    return;
  }

  if(hasSeparatedAudio(videoLayer)){
    videoLayer.muted=true;
    selected=layers.find(l=>l.kind==="audio" && l.linkedGroup===videoLayer.linkedGroup)?.id || videoLayer.id;
    sync(true);
    renderAll();
    alert("此 Video 已經分離過音訊，已選取 Audio Clip。");
    return;
  }

  const audioAsset=createAudioAssetFromVideo(videoLayer);
  if(!audioAsset){
    alert("Separate Audio 失敗：找不到影片素材。");
    return;
  }

  const group=uid();
  videoLayer.linkedGroup=group;
  videoLayer.muted=true;

  const audioLayer={
    id:uid(),
    assetId:audioAsset.id,
    name:"[Separated Audio] "+videoLayer.name,
    kind:"audio",
    start:Number(videoLayer.start||0),
    duration:Math.max(1,Number(videoLayer.duration||audioAsset.duration||1)),
    trim:Number(videoLayer.trim||0),
    x:640,y:360,scale:1,
    volume:1,
    muted:false,
    trackIndex:0,
    linkedGroup:group,
    separatedFrom:videoLayer.id
  };

  layers.push(audioLayer);
  selected=audioLayer.id;
  updateDuration();
  sync(true);
  renderAll();
  log("Separate Audio OK: 已新增 Audio Clip，Video 已靜音。");
}
/* -------------------------------------------------- */

function localTime(l){return Math.max(0,current-Number(l.start||0)+Number(l.trim||0))}
function isLayerActive(l){return current>=Number(l.start||0)&&current<=Number(l.start||0)+Math.max(1,Number(l.duration||0))}
function sync(force=false){
  const vol=Number($("volume")?.value||1);
  const rate=Number(speed||1);
  for(const l of layers){
    const a=asset(l);
    if(!a?.el || !(l.kind==="video"||l.kind==="audio")) continue;
    const active=isLayerActive(l);
    if(!active){
      if(!a.el.paused)a.el.pause();
      continue;
    }
    if(l.kind==="video" && hasSeparatedAudio(l)) l.muted=true;

    const target=localTime(l);
    const drift=Math.abs((a.el.currentTime||0)-target);
    if(a.el.readyState>=1 && (force || drift>.45)){
      try{a.el.currentTime=target}catch{}
    }

    try{a.el.playbackRate=rate}catch{}
    a.el.volume=l.kind==="audio"?vol*Number(l.volume??1):vol;
    a.el.muted=!!l.muted;

    if(playing && a.el.paused){
      a.el.play().catch(()=>log("請先按 Enable Audio。"));
    }
    if(!playing && !a.el.paused)a.el.pause();
  }
}
function masterLayer(){return layers.find(l=>l.kind==="video")||layers.find(l=>l.kind==="audio")||layers.find(l=>l.kind==="text")||null}
function play(){if(!layers.length)return log("請先匯入媒體。");playing=true;pub();sync(true)}
function pause(){playing=false;pub();for(const a of assets)if(a.el?.pause)a.el.pause()}
function stop(){pause();current=0;pub();sync(true);renderAll()}
function seek(t){current=Math.max(0,Math.min(Number(t)||0,duration||0));pub();sync(true);renderAll()}
function split(){
  const l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;
  const left=current-l.start,right=l.duration-left;
  const copy={...l,id:uid(),start:current,duration:right,trim:(l.trim||0)+left};
  l.duration=left;layers.push(copy);selected=copy.id;updateDuration();renderAll();
}
function trimIn(){
  const l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;
  const d=current-l.start;l.trim=(l.trim||0)+d;l.duration-=d;l.start=current;updateDuration();renderAll();
}
function trimOut(){
  const l=sel();if(!l||current<=l.start||current>=l.start+l.duration)return;
  l.duration=current-l.start;updateDuration();renderAll();
}
function fit(){
  const l=sel();if(!l)return;
  const a=asset(l);l.x=640;l.y=l.kind==="text"?120:360;
  if(a&&l.kind!=="audio")l.scale=Math.min(canvas.width/a.w,canvas.height/a.h)*.85;
  renderAll();
}
function applyInspector(){
  const l=sel();if(!l)return;
  l.x=Number($("xInput")?.value||l.x||0);
  l.y=Number($("yInput")?.value||l.y||0);
  l.scale=Number($("scaleInput")?.value||l.scale||1);
  l.start=Number($("startInput")?.value||l.start||0);
  l.duration=Math.max(1,Number($("durationInput")?.value||l.duration||1));

  if(l.kind==="text"){
    l.text=$("textInput")?.value||l.text||"文字";
    l.fontFamily=$("fontFamily")?.value||l.fontFamily||"system-ui";
    l.fontSize=Number($("fontSize")?.value||l.fontSize||56);
    l.color=$("textColor")?.value||l.color||"#fff";
    l.outlineSize=Number($("outlineSize")?.value||l.outlineSize||10);
    l.shadow=$("shadowOn")?.checked??true;
    l.effect=$("effect")?.value||l.effect||"none";
    l.scrollDir=$("scrollDir")?.value||l.scrollDir||"rtl";
  }else{
    l.volume=Number($("volume")?.value||l.volume||1);
  }
  updateDuration();renderAll();
}
function textPos(l){
  const p=Math.max(0,Math.min(1,(current-l.start)/Math.max(l.duration,.01)));
  let x=l.x,y=l.y,alpha=1;
  if(l.effect==="fade")alpha=Math.min(1,p*3,(1-p)*3);
  if(l.effect==="bounce")y=l.y-Math.abs(Math.sin(p*Math.PI*6))*30;
  if(l.effect==="scroll")x=l.scrollDir==="ltr"?-360+p*(canvas.width+720):canvas.width+360-p*(canvas.width+720);
  return{x,y,alpha};
}
function drawText(l){
  const p=textPos(l);
  ctx.save();
  ctx.globalAlpha=Math.max(0,p.alpha);
  ctx.font=`900 ${l.fontSize||56}px ${l.fontFamily||"system-ui"}`;
  ctx.textAlign="center";ctx.textBaseline="middle";ctx.lineJoin="round";
  ctx.shadowColor="rgba(0,0,0,.9)";
  ctx.shadowBlur=10;ctx.shadowOffsetX=4;ctx.shadowOffsetY=4;
  ctx.lineWidth=Math.max(8,l.outlineSize||10);
  ctx.strokeStyle="rgba(0,0,0,.9)";
  ctx.strokeText(l.text||"文字",p.x,p.y);
  ctx.shadowColor="transparent";
  ctx.lineWidth=2;
  ctx.strokeStyle="rgba(255,255,255,.45)";
  ctx.strokeText(l.text||"文字",p.x,p.y);
  ctx.fillStyle=l.color||"#fff";
  ctx.fillText(l.text||"文字",p.x,p.y);
  if(l.id===selected){
    const bw=Math.max(180,(l.text||"文字").length*(l.fontSize||56)*.72);
    const bh=(l.fontSize||56)*1.9;
    ctx.strokeStyle="#f59e0b";
    ctx.lineWidth=3;
    ctx.strokeRect(l.x-bw/2,l.y-bh/2,bw,bh);
  }
  ctx.restore();
}
function render(){
  ctx.clearRect(0,0,1280,720);
  ctx.fillStyle="#000";ctx.fillRect(0,0,1280,720);
  if(!layers.length){
    ctx.fillStyle="#8fa0be";ctx.font="34px system-ui";ctx.textAlign="center";
    ctx.fillText("Import media / TXT subtitles",640,360);return;
  }
  for(const l of layers){
    if(current<l.start||current>l.start+l.duration)continue;
    if(l.kind==="audio"||l.kind==="text")continue;
    const a=asset(l);if(!a)continue;
    const w=(a.el.videoWidth||a.el.naturalWidth||a.w||640)*(l.scale||1);
    const h=(a.el.videoHeight||a.el.naturalHeight||a.h||360)*(l.scale||1);
    try{ctx.drawImage(a.el,l.x-w/2,l.y-h/2,w,h)}catch{}
    if(l.id===selected){
      ctx.strokeStyle="#8b5cf6";ctx.lineWidth=3;ctx.strokeRect(l.x-w/2,l.y-h/2,w,h);
    }
  }
  for(const l of layers){
    if(l.kind==="text" && current>=l.start && current<=l.start+l.duration) drawText(l);
  }
}
function renderMedia(){
  const box=$("mediaList");if(!box)return;box.innerHTML="";
  for(const a of assets){
    const d=document.createElement("div");d.className="card";
    d.innerHTML=`<strong>${a.name}</strong><small>${a.kind} · ${fmt(a.duration)} · ${a.w}x${a.h}</small><button>Add again</button>`;
    d.querySelector("button").onclick=()=>{addLayerFromAsset(a);renderAll()};
    box.appendChild(d);
  }
}
function groupFor(k){return k==="audio"?"audio":k==="text"?"text":"video"}
function groupKinds(g){return g==="audio"?["audio"]:g==="text"?["text"]:["video","image","gif"]}
function maxDur(l){const a=asset(l);return["image","gif","text"].includes(l.kind)?Math.max(duration,300):(a?.duration||l.duration||1)}
function rippleFrom(layer,delta){
  if(!$("rippleToggle")?.checked||!delta)return;
  const g=groupFor(layer.kind);
  for(const l of layers){
    if(l.id!==layer.id && groupFor(l.kind)===g && l.trackIndex===layer.trackIndex && l.start>=layer.start){
      l.start=Math.max(0,l.start+delta);
    }
  }
}
function resizeClip(e,id,side){
  e.preventDefault();e.stopPropagation();
  const l=layers.find(x=>x.id===id),lane=e.currentTarget.closest(".lane");if(!l||!lane)return;
  const rect=lane.getBoundingClientRect(),total=Math.max(duration,1),sx=e.clientX,os=l.start,od=l.duration,ot=l.trim||0;
  function move(ev){
    const sec=(ev.clientX-sx)/rect.width*total;
    if(side==="right")l.duration=Math.max(1,Math.min(od+sec,maxDur(l)));
    else{
      let ns=os+sec,nd=od-sec;
      if(ns<0){nd+=ns;ns=0}
      if(nd<1){ns=os+od-1;nd=1}
      l.start=snap(Math.max(0,ns));
      l.duration=Math.max(1,Math.min(nd,maxDur(l)));
      if(!["image","gif","text"].includes(l.kind))l.trim=Math.max(0,ot+(l.start-os));
    }
    updateDuration();renderAll();
  }
  function up(){removeEventListener("mousemove",move);removeEventListener("mouseup",up)}
  addEventListener("mousemove",move);addEventListener("mouseup",up);
}
function dragClip(e,id){
  e.preventDefault();e.stopPropagation();
  const l=layers.find(x=>x.id===id),lane=e.currentTarget.closest(".lane");if(!l||!lane)return;
  selected=id;
  const g=groupFor(l.kind),names=tracks[g],rect=lane.getBoundingClientRect(),total=Math.max(duration,1),sx=e.clientX,sy=e.clientY,os=l.start,ot=l.trackIndex||0;
  function move(ev){
    const ns=snap(Math.max(0,os+(ev.clientX-sx)/rect.width*total));
    const delta=ns-l.start;
    l.start=ns;
    l.trackIndex=Math.max(0,Math.min(names.length-1,ot+Math.round((ev.clientY-sy)/34)));
    rippleFrom(l,delta);
    updateDuration();renderAll();
  }
  function up(){removeEventListener("mousemove",move);removeEventListener("mouseup",up);renderAll()}
  addEventListener("mousemove",move);addEventListener("mouseup",up);
}
function renderTracks(){
  const cont=$("tracks");if(!cont)return;cont.innerHTML="";
  for(const g of ["video","audio","text"]){
    const names=tracks[g],kinds=groupKinds(g);
    names.forEach((name,idx)=>{
      const tr=document.createElement("div");tr.className="track";
      tr.innerHTML=`<div class="track-name">${name}</div><div class="lane" data-group="${g}" data-track="${idx}"></div>`;
      const lane=tr.querySelector(".lane"),total=Math.max(duration,1);
      for(const l of layers.filter(x=>kinds.includes(x.kind)&&(x.trackIndex??0)===idx)){
        const c=document.createElement("div");
        c.className="clip "+(l.kind==="text"?"text":l.kind==="audio"?"audio":"")+(l.id===selected?" selected":"")+(l.linkedGroup?" linked":"");
        c.innerHTML=`<span class="resize-left"></span><span class="clip-label"></span><span class="resize-right"></span>`;
        c.querySelector(".clip-label").textContent=l.name||l.text;
        c.style.left=`${l.start/total*100}%`;
        c.style.width=`${Math.max(2,l.duration/total*100)}%`;
        c.onclick=()=>{selected=l.id;pub();renderAll()};
        c.querySelector(".clip-label").onmousedown=ev=>dragClip(ev,l.id);
        c.querySelector(".resize-left").onmousedown=ev=>resizeClip(ev,l.id,"left");
        c.querySelector(".resize-right").onmousedown=ev=>resizeClip(ev,l.id,"right");
        lane.appendChild(c);
      }
      cont.appendChild(tr);
    });
  }
}
function renderInspector(){
  const l=sel();if($("selectedName"))$("selectedName").textContent=l?(l.name||l.text):"未選取";
  if(!l)return;
  if($("xInput"))$("xInput").value=Math.round(l.x||0);
  if($("yInput"))$("yInput").value=Math.round(l.y||0);
  if($("scaleInput"))$("scaleInput").value=l.scale??1;
  if($("startInput"))$("startInput").value=l.start??0;
  if($("durationInput"))$("durationInput").value=l.duration??0;
  if(l.kind==="text"){
    if($("textInput"))$("textInput").value=l.text||"";
    if($("fontFamily"))$("fontFamily").value=l.fontFamily||"system-ui";
    if($("fontSize"))$("fontSize").value=l.fontSize||56;
    if($("textColor"))$("textColor").value=l.color||"#ffffff";
    if($("outlineSize"))$("outlineSize").value=l.outlineSize||10;
    if($("shadowOn"))$("shadowOn").checked=l.shadow??true;
    if($("effect"))$("effect").value=l.effect||"none";
    if($("scrollDir"))$("scrollDir").value=l.scrollDir||"rtl";
  }
}
function renderAll(){
  pub();render();renderMedia();renderTracks();renderInspector();
  if($("timeLabel"))$("timeLabel").textContent=`${fmt(current)} / ${fmt(duration)}`;
  if($("scrubber"))$("scrubber").value=current;
}
function loop(){
  const m=masterLayer();
  if(playing&&m){
    const a=asset(m);
    if(a?.el&&(m.kind==="video"||m.kind==="audio")){
      current=m.start+Math.max(0,(a.el.currentTime||0)-(m.trim||0));
    }else current+=1/60;
    if(current>=duration){current=duration;pause()}
    sync(false);
  }
  render();
  if($("timeLabel"))$("timeLabel").textContent=`${fmt(current)} / ${fmt(duration)}`;
  if($("scrubber"))$("scrubber").value=current;
  requestAnimationFrame(loop);
}
function saveProject(){
  const blob=new Blob([JSON.stringify({version:"v7.2.1-separate-audio-fix",assets:assets.map(a=>({id:a.id,name:a.name,kind:a.kind,duration:a.duration,w:a.w,h:a.h})),layers},null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="project.studioflow";a.click();
}
async function openProjectFile(file){
  try{
    const data=JSON.parse(await file.text());
    if(Array.isArray(data.layers)){
      layers=data.layers;selected=null;current=0;updateDuration();renderAll();
      alert("Project opened. 請重新匯入原始媒體以重新連結素材。");
    }
  }catch(e){alert("Open failed: "+e.message)}
}
function downloadBlob(blob,name){
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);
}
async function recordWebM(){
  if(!layers.length)throw Error("請先匯入素材");
  const seconds=Math.max(1,duration||1),old=current,was=playing,chunks=[];
  seek(0);play();
  const stream=canvas.captureStream(30);
  let mime="video/webm;codecs=vp9";if(!MediaRecorder.isTypeSupported(mime))mime="video/webm";
  const rec=new MediaRecorder(stream,{mimeType:mime});
  rec.ondataavailable=e=>{if(e.data&&e.data.size)chunks.push(e.data)};
  const done=new Promise(res=>rec.onstop=()=>res(new Blob(chunks,{type:"video/webm"})));
  rec.start(250);
  setTimeout(()=>rec.stop(),seconds*1000);
  const blob=await done;
  pause();seek(old);if(was)play();
  return blob;
}
async function getFFmpeg(){
  if(location.protocol==="file:")throw Error("FFmpeg conversion needs localhost. Run start_server.bat and open http://localhost:8000. WebM export can still work.");
  if(!window.FFmpegWASM||!window.FFmpegUtil)throw Error("FFmpeg.wasm scripts are not available.");
  const {FFmpeg}=window.FFmpegWASM;
  const {toBlobURL}=window.FFmpegUtil;
  const ffmpeg=new FFmpeg();
  ffmpeg.on("log",({message})=>{if($("exportStatus"))$("exportStatus").textContent=message.slice(0,160)});
  ffmpeg.on("progress",({progress})=>{if($("exportProgress"))$("exportProgress").value=progress*100;if($("exportStatus"))$("exportStatus").textContent="FFmpeg: "+Math.round(progress*100)+"%"});
  try{
    await ffmpeg.load({coreURL:"./ffmpeg/ffmpeg-core.js",wasmURL:"./ffmpeg/ffmpeg-core.wasm",workerURL:"./ffmpeg/ffmpeg-core.worker.js"});
  }catch(e){
    const b="https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd";
    await ffmpeg.load({coreURL:await toBlobURL(`${b}/ffmpeg-core.js`,"text/javascript"),wasmURL:await toBlobURL(`${b}/ffmpeg-core.wasm`,"application/wasm")});
  }
  return ffmpeg;
}
async function convert(webm,fmt){
  const f=await getFFmpeg();
  await f.writeFile("in.webm",new Uint8Array(await webm.arrayBuffer()));
  const map={
    mp4:{args:["-i","in.webm","-c:v","libx264","-pix_fmt","yuv420p","-preset","veryfast","-crf","23","-movflags","+faststart","out.mp4"],file:"out.mp4",mime:"video/mp4",name:"studioflow.mp4"},
    mp3:{args:["-i","in.webm","-vn","-acodec","libmp3lame","-b:a","192k","out.mp3"],file:"out.mp3",mime:"audio/mpeg",name:"studioflow.mp3"},
    wav:{args:["-i","in.webm","-vn","-acodec","pcm_s16le","-ar","44100","-ac","2","out.wav"],file:"out.wav",mime:"audio/wav",name:"studioflow.wav"},
    gif:{args:["-i","in.webm","-vf","fps=12,scale=960:-1:flags=lanczos","-loop","0","out.gif"],file:"out.gif",mime:"image/gif",name:"studioflow.gif"}
  };
  const item=map[fmt];if(!item)return{blob:webm,name:"studioflow.webm"};
  await f.exec(item.args);
  const d=await f.readFile(item.file);
  return{blob:new Blob([d.buffer],{type:item.mime}),name:item.name};
}
async function exportAll(){
  try{
    const fmt=$("exportFormat")?.value||"webm";
    if($("exportStatus"))$("exportStatus").textContent="Recording full timeline...";
    const webm=await recordWebM();
    if(fmt==="webm"){downloadBlob(webm,"studioflow.webm");if($("exportStatus"))$("exportStatus").textContent="WebM exported";return}
    try{
      const out=await convert(webm,fmt);
      downloadBlob(out.blob,out.name);
      if($("exportStatus"))$("exportStatus").textContent=fmt.toUpperCase()+" exported";
    }catch(e){
      alert("FFmpeg 轉檔失敗：\n"+e.message+"\n\n已改為下載 WebM。");
      downloadBlob(webm,"studioflow_fallback.webm");
    }
  }catch(e){alert("Export failed:\n"+e.message)}
}
function bind(){
  if($("fileInput"))$("fileInput").onchange=e=>importFiles(e.target.files);
  if($("openProject"))$("openProject").onchange=e=>{const f=e.target.files[0];if(f)openProjectFile(f)};
  if($("unlockAudio"))$("unlockAudio").onclick=unlockAudio;
  if($("newProject"))$("newProject").onclick=()=>{assets=[];layers=[];selected=null;current=0;updateDuration();renderAll()};
  if($("saveProject"))$("saveProject").onclick=saveProject;
  if($("play"))$("play").onclick=play;
  if($("pause"))$("pause").onclick=pause;
  if($("stop"))$("stop").onclick=stop;
  if($("back"))$("back").onclick=()=>seek(current-5);
  if($("forward"))$("forward").onclick=()=>seek(current+5);
  if($("speed"))$("speed").onchange=e=>{speed=Number(e.target.value);sync(true)};
  if($("volume"))$("volume").oninput=()=>sync(true);
  if($("scrubber"))$("scrubber").oninput=e=>seek(Number(e.target.value));
  if($("split"))$("split").onclick=split;
  if($("trimIn"))$("trimIn").onclick=trimIn;
  if($("trimOut"))$("trimOut").onclick=trimOut;
  if($("separateAudio"))$("separateAudio").onclick=separateAudio;
  if($("linkAV"))$("linkAV").onclick=()=>{const l=sel();if(!l?.linkedGroup)return alert("請選取已分離的影片或音訊。");for(const x of layers.filter(x=>x.linkedGroup===l.linkedGroup)){x.start=l.start;x.duration=l.duration;x.trim=l.trim||0}updateDuration();renderAll()};
  if($("muteVideoAudio"))$("muteVideoAudio").onclick=()=>{const l=sel()||findVideoForSeparation();if(l&&l.kind==="video"){l.muted=true;renderAll()}};
  if($("unmuteVideoAudio"))$("unmuteVideoAudio").onclick=()=>{const l=sel()||findVideoForSeparation();if(l&&l.kind==="video"&&!hasSeparatedAudio(l)){l.muted=false;renderAll()}};
  if($("fit"))$("fit").onclick=fit;
  if($("addText"))$("addText").onclick=()=>addTextLayer($("textInput")?.value||"文字");
  if($("textTop"))$("textTop").onclick=()=>{const l=sel();if(l&&l.kind==="text"){l.x=640;l.y=120;renderAll()}};
  if($("textBottom"))$("textBottom").onclick=()=>{const l=sel();if(l&&l.kind==="text"){l.x=640;l.y=650;renderAll()}};
  if($("removeClipEffect"))$("removeClipEffect").onclick=()=>{const l=sel();if(l){l.effect="none";renderAll()}};
  if($("deleteSelected"))$("deleteSelected").onclick=()=>{layers=layers.filter(l=>l.id!==selected);selected=null;updateDuration();renderAll()};
  if($("deleteAllText"))$("deleteAllText").onclick=()=>{layers=layers.filter(l=>l.kind!=="text");selected=null;updateDuration();renderAll()};
  if($("deleteAllEffects"))$("deleteAllEffects").onclick=()=>{for(const l of layers)l.effect="none";renderAll()};
  if($("clearTimeline"))$("clearTimeline").onclick=()=>{layers=[];selected=null;current=0;updateDuration();renderAll()};
  if($("exportButton"))$("exportButton").onclick=exportAll;
  ["xInput","yInput","scaleInput","startInput","durationInput","textInput","fontFamily","fontSize","textColor","outlineSize","shadowOn","effect","scrollDir"].forEach(id=>{const el=$(id);if(el)el.oninput=applyInspector});
  const drop=$("dropZone");
  if(drop){
    drop.ondragover=e=>{e.preventDefault();drop.classList.add("drag")};
    drop.ondragleave=()=>drop.classList.remove("drag");
    drop.ondrop=e=>{e.preventDefault();drop.classList.remove("drag");importFiles(e.dataTransfer.files)};
  }
  canvas.onmousedown=e=>{
    const r=canvas.getBoundingClientRect(),sx=(e.clientX-r.left)*(1280/r.width),sy=(e.clientY-r.top)*(720/r.height);
    let hit=null;
    for(let i=layers.length-1;i>=0;i--){
      const l=layers[i];if(l.kind!=="text")continue;
      const bw=Math.max(180,(l.text||"文字").length*(l.fontSize||56)*.72),bh=(l.fontSize||56)*1.9;
      if(sx>=l.x-bw/2&&sx<=l.x+bw/2&&sy>=l.y-bh/2&&sy<=l.y+bh/2){hit=l;break}
    }
    if(!hit){
      for(let i=layers.length-1;i>=0;i--){
        const l=layers[i];if(l.kind==="audio"||l.kind==="text")continue;
        const a=asset(l);if(!a)continue;
        const w=(a.el.videoWidth||a.el.naturalWidth||a.w||640)*(l.scale||1),h=(a.el.videoHeight||a.el.naturalHeight||a.h||360)*(l.scale||1);
        if(sx>=l.x-w/2&&sx<=l.x+w/2&&sy>=l.y-h/2&&sy<=l.y+h/2){hit=l;break}
      }
    }
    if(!hit)return;
    selected=hit.id;
    const ox=hit.x,oy=hit.y;
    function move(ev){
      const nx=(ev.clientX-r.left)*(1280/r.width),ny=(ev.clientY-r.top)*(720/r.height);
      hit.x=ox+nx-sx;hit.y=oy+ny-sy;renderAll();
    }
    function up(){removeEventListener("mousemove",move);removeEventListener("mouseup",up);renderAll()}
    addEventListener("mousemove",move);addEventListener("mouseup",up);renderAll();
  };
  renderAll();
  requestAnimationFrame(loop);
  log("StudioFlow v7.2.1 Separate Audio Fix ready.");
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bind);else bind();
})();