# StudioFlow v7.1 FFmpegWASM TextTop AudioSplit Run Fix

此版本針對你指定的：

`StudioFlow_v7.1_FFmpegWASM_TextTop_Fix`

修正以下問題：

## 修正 1：Music / Audio split 後不能完整播放

- Separate Audio 會建立獨立 audio media element
- Video 原音自動靜音
- Audio Clip 可完整播放到時間軸結尾
- 不再每幀強制 seek，避免音樂中斷、卡住、提前停止
- Play / Pause / Stop / Seek / Speed / Volume 同步

## 修正 2：實裝 run 增加文字功能與效果

- Add Text 會立即顯示
- 文字永遠在 Video / Image / Effects 最上層
- 文字效果像截圖：
  - 粗體白字
  - 黑色描邊
  - 黑色陰影
  - 橘色選取框
- 支援 Scroll / Fade / Bounce
- 支援拖曳文字位置

## 保留功能

- FFmpeg 匯出
- Timeline
- Inspector
- Video×5 / Audio×3 / Text×3
- Clip Move / Resize
- Snap / Ripple
- Trim / Split
- Save / Open Project
