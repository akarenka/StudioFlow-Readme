# StudioFlow v7.2 Shadow / Outline Compose Engine

此版本保留目前所有功能，另外新增一個合成引擎頁面：

```text
v7_2_shadow_outline_engine.html
```

## 新增功能

- 匯入影片
- Canvas 即時播放
- 輸入疊加文字
- 文字效果：
  - 無特效
  - 陰影效果
  - 邊框效果
  - 陰影 + 邊框
- 快速匯出 WebM
- FFmpeg.wasm 轉出 MP4
- 若 FFmpeg 失敗，自動下載 WebM fallback

## 使用方式

建議執行：

```text
start_server.bat
```

然後開啟：

```text
http://localhost:8000/v7_2_shadow_outline_engine.html
```

主編輯器仍然是：

```text
http://localhost:8000/index.html
```
