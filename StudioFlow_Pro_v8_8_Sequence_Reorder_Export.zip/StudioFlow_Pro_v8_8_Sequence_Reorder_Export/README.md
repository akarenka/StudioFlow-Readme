# StudioFlow Pro v8.8 — Sequence Reorder + Export

此版本保留 v8.7 所有功能，修正 Split 後影音跳段或無法播放。

## 修正播放

- 每一個 Split 後的 Video / Audio Clip 使用獨立媒體播放元素
- 多個 Clip 不再共用同一個 `currentTime`
- Trim offset、Clip start 與 duration 分別同步
- 播放順序依 Timeline 的 start、row、z 排列
- Video 與 Separate Audio 不再互相搶時間造成跳段

## Clip 移動與互換

- 原有拖曳移動仍保留
- 將一個 Clip 拖到另一個同類 Clip 上，可互換位置
- `⇆ Left` 與 `Right ⇆` 可和前後 Clip 互換
- `Pack Sequence` 可依每一軌目前順序自動緊密排列
- 已連結的 Video / Audio 會一起移動

## 重組後匯出

新增真正依 Timeline 內容匯出：

- MP4：H.264 + AAC
- GIF：Palettegen + Paletteuse
- MP3：Audio 1～5 混音

匯出會處理：

- Split
- Trim In / Trim Out
- Clip Move
- Clip Swap
- Timeline start
- Video 1～5 疊加順序
- Audio 1～5 開始時間、Trim、Volume、Mute
- Preview 中的 X / Y / Scale

完成檔保存到：

```text
workspace/Exports/
workspace/Temp/Completed/
```

請以 `install_and_start.bat` 啟動，後端 FFmpeg 才能執行重組匯出。
